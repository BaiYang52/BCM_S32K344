package com.vector.cfg.project.evs.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * This will be the API for the selection of a variant inside of a EVS.arxml file.
 *
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IImportVariantApi {

}
