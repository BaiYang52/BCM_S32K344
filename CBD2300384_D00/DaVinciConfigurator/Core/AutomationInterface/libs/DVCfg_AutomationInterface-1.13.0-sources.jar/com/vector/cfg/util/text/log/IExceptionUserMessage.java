package com.vector.cfg.util.text.log;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * Classes can implement this interface to provide a message for the user in a user readable manner. E.g. {@link Exception}s could implement the interface to mark, that the
 * {@link Exception} is presentable to the user, with a correct user readable text, without the need of the stacktrace content.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by PublishedApi clients.
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExceptionUserMessage extends IUserMessage {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    default IMixedText getUserMessage() {
        return MixedText.fromConstantString(getMessage());
    }

    /**
     * See {@link Throwable#getMessage()}.
     *
     * @return the message
     */
    @PublishedMethod
    String getMessage();
}
