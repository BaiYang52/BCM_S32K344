package com.vector.cfg.util.text.mixedtext.parts;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.internal.format.FormatConstants;
import com.vector.cfg.util.text.mixedtext.IFormatSpec;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMixedTextObjectPart extends IMixedTextPart {

    /**
     * Returns the format.
     *
     * @return the format, or if the format was <code>null</code>, {@link FormatConstants#EMPTY_FORMAT}
     */
    @KeepSecretFromPublishedApi
    @Nonnull
    String getFormat();

    /**
     * Gets the object.
     *
     * @return the object, or if the object was null, {@link FormatConstants#NULL}
     */
    @PublishedMethod
    @Nonnull
    Object getObject();

    @PublishedMethod
    @Override
    @Nonnull
    IMixedTextObjectPart createNewFormattedPart(IFormatSpec newSpec);
}
