package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucRefDefinition extends IEcucAbstractRef {

    /**
     * returns an optional holding the target definition. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    Optional<IEcucContainerDefinition> getTargetDefinition();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIReferenceParamDef getDef();

}
