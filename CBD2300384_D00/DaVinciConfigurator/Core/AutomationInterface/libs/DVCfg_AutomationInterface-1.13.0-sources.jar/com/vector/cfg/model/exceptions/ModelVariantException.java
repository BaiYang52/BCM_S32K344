package com.vector.cfg.model.exceptions;

import javax.annotation.Nullable;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.asr.view.api.IModelViewBaseManager;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.Debugables;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This is the base class of all model exceptions dealing with variance aspects.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelVariantException extends ModelException {
    private static final ILogger logger = Logger.INSTANCE.createLogger(ModelVariantException.class);

    private static final long serialVersionUID = 4998699039518800620L;

    private final MIObject source;

    private final IModelView activeModelViewDuringException;

    private final String sourceMsg;

    /**
     * Constructor.
     *
     * @param message
     */
    @KeepSecretFromPublishedApi
    public ModelVariantException(String message, @Nullable MIObject source) {
        this(message, source, null);
    }

    /**
     * Constructor.
     *
     * @param message
     * @param innerEx
     */
    @KeepSecretFromPublishedApi
    public ModelVariantException(String message, @Nullable MIObject source, @Nullable Throwable innerEx) {
        super(message, innerEx);
        this.source = source;

        IModelView modelView = null;
        if (source != null) {
            try {
                modelView = source.getProjectContext().getService(IModelViewBaseManager.class).getCurrentlyActiveView();
            } catch (final RuntimeException ex) {
                logger.error(ex);
            }
        }
        activeModelViewDuringException = modelView;
        this.sourceMsg = buildSourceMessage();
    }

    @Override
    @PublishedMethod
    public String getMessage() {
        final StringBuilder builder = new StringBuilder();
        builder.append(super.getMessage());

        builder.append(sourceMsg);
        return builder.toString();

    }

    /**
     * @param builder
     */
    private String buildSourceMessage() {
        final StringBuilder builder = new StringBuilder();
        if (source != null) {
            builder.append(" Source: ");
            builder.append(Debugables.toDebugString(source));
        }
        return builder.toString();
    }

    @PublishedMethod
    public Optional<MIObject> getSource() {
        return Optional.fromNullable(source);
    }

    /**
     * Returns the model view (if available) which was active when the exception was created.
     *
     * @return
     */
    @PublishedMethod
    public Optional<IModelView> getActiveModelViewDuringException() {
        return Optional.fromNullable(activeModelViewDuringException);
    }

}
