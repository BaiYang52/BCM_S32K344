package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.model.sysdesc.api.port.IPortInterface;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IPortInterfaceSelection"><!--Label:IPortInterfaceSelection-->{@link IPortInterfaceSelection} represents a selection of {@link IPortInterface}s and the
 * possible operations on these port interfaces.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IPortInterfaceSelection {

    /**
     * <p>
     * <div class="extdoc" id="createPrototype"><!--Label:IPortInterfaceSelection.createPrototype-->{@link #createPrototype(Closure)} creates a PortPrototype on the ecu
     * composition of the FlatExtract for each selected port interface. If the naming is not specified, the names of the created delegation ports are derived from the selected
     * port interfaces. The direction of the ports has to be specified.</div>
     * </p>
     *
     * <p>
     * The port interface selection will produce trace, info and warning logs. To see them, activate the 'com.vector.cfg.dom.runtimesys.groovy.api.IPortInterfaceSelection'
     * logger with the appropriate log level.
     * </p>
     *
     * @return A list of the newly created delegation component ports.
     */
    @PublishedMethod
    List<IComponentPort> createPrototype(@Nonnull @VDelegatesToWithClosureParam(IDelegationPortCreator.class) Closure<?> createPrototypeCode);

    /**
     * <div class="extdoc" id="getPortInterfaces"><!--Label:IPortInterfaceSelection.getPortInterfaces-->{@link #getPortInterfaces()} allows access to the single port interfaces
     * in the {@link IPortInterfaceSelection}.</div>
     *
     * @return The collection of selected port interfaces.
     */
    @PublishedMethod
    Collection<IPortInterface> getPortInterfaces();

}
