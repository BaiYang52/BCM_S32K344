package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.runtimesys.groovy.internal.api.TaskMappingSuccessorClosure;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ITaskMappingSuccessorChain"><!--ITaskMappingSuccessorChain-->{@link ITaskMappingSuccessorChain} stores the successors defined for a task
 * mapping.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMappingSuccessorChain {

    /**
     * <div class="extdoc" id="successor"><!--Label:ITaskMappingSuccessorChain.successor-->{@link #successor(Closure)} allows to select a successor for the previously selected task
     * mapping of the sequence. The sequence can be continued by another {@link #successor(Closure)} or {@link #directSuccessor(Closure)} call. To start a new sequence call
     * {@link ITaskMappingSuccessorDefinition#forTaskMapping(Closure)}.</div>
     *
     * @param code The code to select the successor task mapping.
     * @return {@code this} {@link ITaskMappingSuccessorChain} which allows to select further successor task mappings for the by the parameter closure selected task mapping.
     */
    @PublishedMethod
    ITaskMappingSuccessorChain successor(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="directSuccessor"><!--Label:ITaskMappingSuccessorChain.directSuccessor-->{@link #directSuccessor(Closure)} allows to select a direct successor for the
     * previously selected task mapping of the sequence. The sequence can be continued by another {@link #successor(Closure)} or {@link #directSuccessor(Closure)} call. To start a
     * new sequence call {@link ITaskMappingSuccessorDefinition#forTaskMapping(Closure)}.</div>
     *
     * @param code The code to select the direct successor task mapping.
     * @return {@code this} {@link ITaskMappingSuccessorChain} which allows to select further successor task mappings for the by the parameter closure selected task mapping.
     */
    @PublishedMethod
    ITaskMappingSuccessorChain directSuccessor(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    // -----------------------------------------------

    @KeepSecretFromPublishedApi
    List<TaskMappingSuccessorClosure> getSuccessorClosures();

    @KeepSecretFromPublishedApi
    Closure<?> getSelectStartTaskMappingCode();
}
