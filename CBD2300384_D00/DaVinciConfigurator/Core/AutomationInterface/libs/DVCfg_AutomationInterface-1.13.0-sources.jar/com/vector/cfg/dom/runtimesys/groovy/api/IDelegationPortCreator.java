package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.EDirection;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="IDelegationPortCreator"><!--Label:IDelegationPortCreator-->{@link IDelegationPortCreator} provides an Api to control some aspects, e.g. the naming or
 * the direction, of newly created delegation ports. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDelegationPortCreator {

    /**
     * <div class="extdoc" id="name">{@link #name(Closure)} computes a name for the delegation port prototypes that should be created for port interfaces, which are provided by
     * the used selection API. </div>
     *
     * @param code A closure that returns a string with a name for the delegation port that should be created.
     */
    @PublishedMethod
    void name(@ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.port.IPortInterface") @Nonnull Closure<String> code);

    /**
     * <div class="extdoc" id="count">{@link #count(int)} defines how many delegation port prototypes should be created for each selected port interface. The default is 1.
     * </div>
     *
     * @param count The number of port prototypes which should be created.
     */
    @PublishedMethod
    void count(int count);

    /**
     * <div class="extdoc" id="direction">{@link #direction(EDirection)} defines the direction of the port prototype that should be created. {@link EDirection#Tx} will create
     * provided ports, {@link EDirection#Rx} will create required ports. Delegation provided-required ports are not supported.</div>
     *
     * @param direction The direction of port prototypes which should be created.
     */
    @PublishedMethod
    void direction(EDirection direction);

    /**
     * <div class="extdoc" id="useDefaultDirection">{@link #useDefaultDirection()} defines the direction of the port prototype that should be created. The default direction is
     * the direction of the selected port in previous steps.<br>
     * Note: This method cannot be used within the port interface selection API. In that case there is no port to derive the direction from, so <code>null</code> is used as
     * default direction. Also calling both {@link #direction(EDirection)} and {@link #useDefaultDirection()} at the same time is not allowed.</div>
     *
     * @throws SelectionException if both {@link #direction(EDirection)} and {@link #useDefaultDirection()} are called.
     * @throws SelectionException if called in the context of {@link IPortInterfaceSelection} API.
     */
    @PublishedMethod
    void useDefaultDirection();

    /**
     * <div class="extdoc" id="nameFromOriginPort">{@link #nameFromOriginPort(Closure)} computes a name for the delegation port prototypes that should be created for origin
     * ports, which are provided by the used {@link IOriginComponentPortSelection}.</div>
     *
     * @param code A closure that returns a string with a name for the delegation port that should be created.
     *
     * @throws SelectionException if not called in the context of an {@link IOriginComponentPortSelection} API.
     * @throws SelectionException if both {@link #nameFromOriginPort(Closure)} and {@link #name(Closure)} are called.
     */
    @PublishedMethod
    void nameFromOriginPort(@ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.origin.IOriginComponentPort") @Nonnull Closure<String> code);

    /**
     * <div class="extdoc" id="nameFromComponentPort">{@link #nameFromComponentPort(Closure)} computes a name for the delegation port prototypes that should be created for
     * component ports, which are provided by the used {@link IComponentPortSelection}.</div>
     *
     * @param code A closure that returns a string with a name for the delegation port that should be created.
     *
     * @throws SelectionException if not called in the context of an {@link IComponentPortSelection} API.
     * @throws SelectionException if both {@link #nameFromComponentPort(Closure)} and {@link #name(Closure)} are called.
     */
    @PublishedMethod
    void nameFromComponentPort(@ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.port.IComponentPort") @Nonnull Closure<String> code);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    Closure<String> getComputeNameCode();

    @KeepSecretFromPublishedApi
    int getCount();

    @KeepSecretFromPublishedApi
    EDirection getDirection();

    @KeepSecretFromPublishedApi
    boolean isUseDefaultDirection();

    @KeepSecretFromPublishedApi
    Closure<String> getComputeNameFromOriginPortCode();

    @KeepSecretFromPublishedApi
    Closure<String> getComputeNameFromComponentPortCode();
}
