package com.vector.cfg.util;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The IDebugable Interface. This interface defines a basic set of methods to be implemented by an object in order to improve debugging capabilities with eclipse.
 *
 * <p>
 * To use this interface: Configure your debugger as following:<br>
 * Eclipse: Window -> Preferences -> Java -> Debug -> Detail Formatters Insert a new Type with com.vector.cfg.util.IDebugable and insert the code snippet
 *
 * <pre>
 * <code>
 * if (this == null) return "null";
 * return this.toDebugString();
 * </code>
 * </pre>
 *
 * .
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @see Debugables
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDebugable {

    /**
     * Method similar to ToString method but intended to create and display a string for debugging purposes.
     * <p>
     * NOTE: This method is created, because the {@link Object#toString()} method is used at several different locations. This method instead allows to create a debug string of
     * the item for error logging or debugging.
     * </p>
     *
     * @return the debug string
     *
     */
    @PublishedMethod
    String toDebugString();

}