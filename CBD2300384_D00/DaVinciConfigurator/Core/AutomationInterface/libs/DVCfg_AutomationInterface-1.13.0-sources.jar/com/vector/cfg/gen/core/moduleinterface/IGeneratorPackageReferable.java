package com.vector.cfg.gen.core.moduleinterface;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidator;

/**
 * A common base of object which can reference a GeneratorPackage, like a Validator or a GenerationProcessor
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @see IValidator
 * @see IGenerationProcessor
 *
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGeneratorPackageReferable {

    /**
     * Gets the corresponding GeneratorPackage.
     *
     * @return The GeneratorPackage corresponding to that object
     */
    @PublishedMethod
    IGeneratorPackage getGeneratorPackage();

}
