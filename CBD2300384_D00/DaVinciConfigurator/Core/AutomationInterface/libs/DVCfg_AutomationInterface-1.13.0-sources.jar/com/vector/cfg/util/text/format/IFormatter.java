package com.vector.cfg.util.text.format;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Provides support for custom formatting of the value of an object.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IFormatter<T> {

    /**
     * Converts the value of a specified object to an equivalent string representation using specified format and a specific {@link IFormatProvider} formatting
     * information.
     *
     * @param arg The Object which is formatted
     * @param formatPattern The formatting pattern to control the format
     * @return The string representation of the formatted object.
     */
    @PublishedMethod
    String format(T arg, String formatPattern);

}
