package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.IClientServerDataMapping;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;
import com.vector.cfg.model.sysdesc.api.com.ISignalGroupInstance;
import com.vector.cfg.model.sysdesc.api.com.ISignalInstance;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ISignalInstanceSelection"><!--Label:ISignalInstanceSelection-->{@link ISignalInstanceSelection} represents a selection of
 * {@link IAbstractSignalInstance}s ({@link ISignalInstance} and {@link ISignalGroupInstance}) and the possible operations on these signal instances.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:ISignalInstanceSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of signal instances
     * according the data mapping assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target
     * communication elements can be defined and code to evaluate and change the auto-mapper results can be provided.
     * <p>
     * {@link #autoMapTo(Closure)} will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.ISignalInstanceSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate matches.
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:ISignalInstanceSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of {@link IAbstractSignalInstance}s
     * ({@link ISignalInstance} or {@link ISignalGroupInstance}) according the data mapping assistant default rules. Therefore the selection of possible target communication
     * elements is computed and tried to match to the selected signal instances.</div>
     *
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMap();

    /**
     * <div class="extdoc" id="getSignalInstances"><!--Label:ISignalInstanceSelection.getSignalInstances-->{@link #getSignalInstances()} allows access to the single signal
     * instances in the {@link ISignalInstanceSelection}.</div>
     *
     * @return The collection of selected signal instances.
     */
    @PublishedMethod
    <T extends IAbstractSignalInstance> Collection<T> getSignalInstances();

    /**
     * <div class="extdoc" id="unmap"><!--Label:ISignalInstanceSelection.unmap-->{@link #unmap()} unmaps the selected signal instances from all mapped communication elements. In
     * case that not all data mappings of the selected signal instances shall be removed the mapped communication elements can be narrowed down using
     * {@link #unmapFrom(Closure)}. <br>
     *
     * <p>
     * For SenderReceiverToSignalGroupMappings (complex mappings) it is already enough to select the signal group or one of the group signals, all mappings belonging to the
     * complex mapping will be removed. In other words removing the root mapping also removes the child mappings, removing a child mapping also removes the root mapping and the
     * other child mappings of the same root.
     * </p>
     *
     * </div>
     *
     * @return A collection of {@link IUnmappedComElementAndSignalResult}s representing the {@link IAbstractSignalInstance} and {@link ICommunicationElement} of each removed
     * {@link IDataMapping}. <br>
     * For {@link IClientServerDataMapping}s the returned {@link IUnmappedComElementAndSignalResult} contains all details about the call signal mapping as well as the return
     * signal mapping. <br>
     * For SenderReceiverToSignalGroupMappings (complex data mappings) the returned {@link IUnmappedComElementAndSignalResult} contains also all details about the removed child
     * data mappings. <br>
     */
    @PublishedMethod
    Collection<IUnmappedComElementAndSignalResult> unmap();

    /**
     * <div class="extdoc" id="unmapFrom"><!--Label:ISignalInstanceSelection.unmapFrom-->{@link #unmapFrom()} unmaps the selected {@link IAbstractSignalInstance}s of this
     * selection from the mapped {@link ICommunicationElement}s. In opposite to {@link #unmap()} this method allows additional evaluation of the {@link ICommunicationElement}s
     * for which the {@link IDataMapping}s to the selected communication elements will be removed. <br>
     *
     * <p>
     * For SenderReceiverToSignalGroupMappings (complex mappings) it is already enough to select the signal group or one of the group signals, all mappings belonging to the
     * complex mapping will be removed. In other words removing the root mapping also removes the child mappings, removing a child mapping also removes the root mapping and the
     * other child mappings of the same root.
     * </p>
     * </div>
     *
     * @return A collection of {@link IUnmappedComElementAndSignalResult}s representing the {@link IAbstractSignalInstance} and {@link ICommunicationElement} of each removed
     * {@link IDataMapping}. <br>
     * For {@link IClientServerDataMapping}s the returned {@link IUnmappedComElementAndSignalResult} contains all details about the call signal mapping as well as the return
     * signal mapping. <br>
     * For SenderReceiverToSignalGroupMappings (complex data mappings) the returned {@link IUnmappedComElementAndSignalResult} contains also all details about the removed child
     * data mappings. <br>
     */
    @PublishedMethod
    Collection<IUnmappedComElementAndSignalResult> unmapFrom(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceUnmapper.class) Closure<?> code);

}
