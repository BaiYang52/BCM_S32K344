package com.vector.cfg.workflow.diff.groovy.projectcompare.compare.result;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.result.IMergeResult;

/**
 * <div class="extdoc" id="ICompareResult"><!--ICompareResult-->
 *
 * <img src="{@docRoot} /../_doc/UML/ICompareResult/CompareResultStructure.png" alt= "The structure of a comparison result" id="CompareResultStructure" data-latex-style=
 * "scale=0.6" />
 *
 * <pre>
 * <!--PlantUML: CompareResultStructure
 *
 * interface {@link ICompareResult} {
 *  +getDifferences()
 * }
 *
 * interface {@link IDifference} {
 *  +getIdentifier()
 *  +getDifferenceType()
 *  +getOrigin()
 * }
 *
 * {@link ICompareResult} "1" *-- "0..*" {@link IDifference}
 * -->
 * </pre>
 *
 * {@link IMergeResult} is the entry point for the automatic merge result to retrieve the not resolved differences and the path to the report file. <b>Note</b> that the
 * structure of the report is not stable and may change when another version of the DaVinci Configurator Classic is used. This API instead is kept stable.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICompareResult {

    /**
     * <div class="extdoc" id="getDifferences">The method {@link #getDifferences()} is used to get all found differences.
     *
     * </div>
     *
     * @return all found differences.
     */
    @PublishedMethod
    List<IDifference> getDifferences();
}
