package com.vector.cfg.dom.modemgt.groovy.bswm;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IBswMAutoConfigurationFeature} provides read-access to a BswM auto configuration feature.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationFeature extends IBswMAutoConfigurationElement {

    /**
     * {@link #isActivated()} returns {@code true} if the BswM auto configuration feature is activated.
     *
     * @return {@code true} if the BswM auto configuration feature is activated
     */
    @PublishedMethod
    boolean isActivated();

    /**
     * {@link #getSubFeatures()} returns all of this feature's sub-features.
     *
     * @return all of this feature's sub-features (result may be empty)
     */
    @PublishedMethod
    List<IBswMAutoConfigurationFeature> getSubFeatures();

    /**
     * {@link #getParameters()} returns all of this feature's parameters.
     *
     * @return all of this feature's parameters (result may be empty)
     */
    @PublishedMethod
    List<IBswMAutoConfigurationParameter> getParameters();

}
