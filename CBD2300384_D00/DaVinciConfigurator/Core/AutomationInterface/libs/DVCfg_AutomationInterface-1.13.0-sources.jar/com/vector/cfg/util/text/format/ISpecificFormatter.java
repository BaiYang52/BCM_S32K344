package com.vector.cfg.util.text.format;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ISpecificFormatter<T> extends IFormatter<T> {

    @PublishedMethod
    ISpecificFormatterProvider.EFormatType getType();

}
