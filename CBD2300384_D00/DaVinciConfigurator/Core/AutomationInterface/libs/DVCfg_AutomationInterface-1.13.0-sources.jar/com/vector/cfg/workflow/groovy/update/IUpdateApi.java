package com.vector.cfg.workflow.groovy.update;

import java.nio.file.Path;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.update.input.IInputFilesEntryPoint;

import groovy.lang.Closure;

/**
 * The Interface IUpdateApi.
 *
 * * <div class="extdoc" id="IUpdateApi">
 * <h2>IUpdateApi</h2> <!--Label:IUpdateApi-->
 * <p>
 * The {@link IUpdateApi} is the automation interface for the modification of update workflows.
 *
 * <pre>
<code class="Java" id="description">

 * scriptTask("DelegateApproach", APPLICATION) {
 *     code {
 *         workflow {
 *             update(Paths.get("MyProject.dpa"),  {
 *                 ...
 *             })
 *         }
 *     }
 * }
</code>
 * </pre>
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUpdateApi extends IInputFilesEntryPoint {

    /**
     * The Enum EUpdateMode, see {@link IUpdateSettingsApi#setUpdateMode(EUpdateMode)}.
     *
     * @see IUpdateSettingsApi
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    enum EUpdateMode {
        /**
         * Performs an update on the Ecuc-File only and ignores the Developer workspace.
         */
        ECUC_ONLY(false),

        /**
         * Performs an update only with the Legacy Diagnostic Data.
         */
        LEGACY_DIAG_ONLY(false),

        /**
         * Performs an update on the Ecuc-File and the Developer workspace.
         */
        ECUC_AND_DEV_WS(true);

        private final boolean doCompleteUpdate;

        EUpdateMode(boolean doCompleteUpdate) {
            this.doCompleteUpdate = doCompleteUpdate;
        }

        @KeepSecretFromPublishedApi
        public boolean isDoCompleteUpdate() {
            return doCompleteUpdate;
        }
    }

    /**
     * The Interface {@link IUpdateSettingsApi} provides API to configure common update settings.
     *
     * <p>
     * Usage example to set some update settings:
     *
     * <pre>
     * <code class="Java" id="description">
     * update(Paths.get("MyProject.dpa")){
     *   updateSettings{
     *     updateMode = ECUC_ONLY
     *     uuidUsageInStandardConfigurationEnabled = false
     *   }
     * }
     *
     * </code>
     * </pre>
     * </p>
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IUpdateSettingsApi {

        /**
         * Sets the update mode.
         * <p>
         * The UpdateMode ecucAndDcfWorkspace is selected by default.
         * </p>
         *
         */
        @PublishedMethod
        void updateMode(EUpdateMode updateMode);

        /**
         * Sets the update mode.
         * <p>
         * The UpdateMode ecucAndDcfWorkspace is selected by default.
         * </p>
         *
         * <div class="extdoc" id="setUpdateMode">
         * <h5>Update Mode</h5> Use {@link setUpdateMode} or {@link updateMode} to set the update mode. <br>
         * <ul>
         * <li>{@link EUpdateMode.ECUC_ONLY}</li>
         * <li>{@link EUpdateMode.LEGACY_DIAG_ONLY}
         * <li>{@link EUpdateMode.ECUC_AND_DEVELOPER_WORKSPACE}</li>
         * </ul>
         * </div>
         */
        @PublishedMethod
        void setUpdateMode(EUpdateMode updateMode);

        /**
         * Performs an update on the Ecuc-File only and ignores the Developer workspace.
         */
        @PublishedField
        EUpdateMode ECUC_ONLY = EUpdateMode.ECUC_ONLY;

        /**
         * Performs an update only with the Legacy Diagnostic Data.
         */
        @PublishedField
        EUpdateMode LEGACY_DIAG_ONLY = EUpdateMode.LEGACY_DIAG_ONLY;

        /**
         * Performs an update on the Ecuc-File and the Developer workspace.
         */
        @PublishedField
        EUpdateMode ECUC_AND_DEVELOPER_WORKSPACE = EUpdateMode.ECUC_AND_DEV_WS;

        /**
         * Set the UUID Usage in System Description. Project update will identify objects of the system description based on their UUID.
         *
         * @param value {@code true} UUIDs will be considered. Otherwise {@code false}
         */
        @PublishedMethod
        void setUuidUsageInSystemDescriptionEnabled(boolean value);

        /**
         * Set the UUID Usage in System Description. Project update will identify objects of the system description based on their UUID.
         *
         * <div class="extdoc" id="uuidUsageInSystemDescriptionEnabled">
         * <h5>UUID Usage in System Description Enabled</h5> Use {@link #uuidUsageInSystemDescriptionEnabled} or {@link setUuidUsageInSystemDescriptionEnabled} to set the UUID
         * Usage in System Description setting. Project update will identify objects of the system description based on their UUID.</div>
         *
         *
         * @param value {@code true} UUIDs will be considered. Otherwise {@code false}
         */
        @PublishedMethod
        void uuidUsageInSystemDescriptionEnabled(boolean value);

        /**
         * Returns the value of the UUID Usage in System Description setting.
         *
         * <div class="extdoc" id="isUuidUsageInSystemDescriptionEnabled">
         * <h5>Is UUID Usage in System Description Enabled</h5> Use {@link #isUuidUsageInSystemDescriptionEnabled} to get the value of the UUID Usage in System Description
         * setting. </div>
         *
         * @returns {@code true / false}
         */
        @PublishedMethod
        boolean isUuidUsageInSystemDescriptionEnabled();

        /**
         * Set the UUID Usage in Standard Configuration. Project update will identify objects of the standard configuration based on their UUID.
         *
         * @param value {@code true} UUIDs will be considered. Otherwise {@code false}
         */
        @PublishedMethod
        void setUuidUsageInStandardConfigurationEnabled(boolean value);

        /**
         * Set the UUID Usage in Standard Configuration. Project update will identify objects of the standard configuration based on their UUID.
         * <div class="extdoc" id="uuidUsageInStandardConfigurationEnabled">
         * <h5>UUID Usage in Standard Configuration Enabled</h5> Use {@link #uuidUsageInStandardConfigurationEnabled} or {@link #setUuidUsageInStandardConfigurationEnabled} to
         * set the UUID Usage in Standard Configuration setting. Project update will identify objects of the standard configuration based on their UUID. </div>
         *
         * @param value {@code true} UUIDs will be considered. Otherwise {@code false}
         */
        @PublishedMethod
        void uuidUsageInStandardConfigurationEnabled(boolean value);

        /**
         * Returns the value of the UUID Usage in Standard Configuration setting. <div class="extdoc" id="isUuidUsageInStandardConfigurationEnabled">
         * <h5>Is UUID Usage in Standard Configuration Enabled</h5> Use {@link #isUuidUsageInStandardConfigurationEnabled} to get the value of the UUID Usage in Standard
         * Configuration setting. </div>
         *
         * @return {@code true / false}
         */
        @PublishedMethod
        boolean isUuidUsageInStandardConfigurationEnabled();

        /**
         * Execute sys desc modification script.
         *
         * <div class="extdoc" id="executeSysDescModificationScript">
         * <h5>Execute System Description Modification Script</h5> {@link #executeSysDescModificationScript(String)} Sets the script to execute during the update workflow.
         * </div>
         *
         * @param scriptPath the script path
         */
        @PublishedMethod
        void executeSysDescModificationScript(String scriptPath);

        /**
         * Disable sys desc modification script.
         *
         * <div class="extdoc" id="disableSysDescModificationScript">
         * <h5>Disable System Description Modification Script</h5> {@link #disableSysDescModificationScript()} Disables the execution of the script during the update workflow.
         * </div>
         */
        @PublishedMethod
        void disableSysDescModificationScript();

        /**
         * Use {@link #getReport()} to specify the update report settings.
         *
         * <div class="extdoc" id="getReport"><!--Label:IUpdateReportApiEntryPoint.getReport-->Use {@link #getReport()} or {@link #report(Closure)} to specify the update report
         * settings. </div>
         */
        @PublishedMethod
        IUpdateReportApi getReport();

        /**
         * Use {@link #report(Closure)} to specify the update report settings in a scope-like way.
         *
         * @param code code providing the report project settings
         * @see #getReport()
         */
        @PublishedMethod
        <T> T report(@VDelegatesToWithClosureParam(IUpdateReportApi.class) Closure<T> code);

        /**
         * Checks if an legacy diagnostic only update is executable with the given project. <div class="extdoc" id="isLegacyDiagOnlyUpdateExecutable">
         * <h5>Is Legacy Diagnostic only Update executable</h5> Use {@link #isLegacyDiagOnlyUpdateExecutable} to get the information if an Update with only the Legacy Diagnostic
         * files is executable. If this check returns {@code true} the {@link EupdateMode} can be set to {@link EUpdateMode#LEGACY_DIAG_ONLY}. </div>
         *
         * @return {@code true / false}
         */
        @PublishedMethod
        boolean isLegacyDiagOnlyUpdateExecutable();

        /**
         * Checks if an Ecuc and Developer workspace update is executable with the given project. <div class="extdoc" id="isEcucAndDevWsUpdateExecutable">
         * <h5>Is Ecuc and Developer Workspace Update executable</h5> Use {@link #isEcucAndDevWsUpdateExecutable} to get the information if an Ecuc and Developer Workspace
         * Update is executable. If this check returns {@code true} the {@link EupdateMode} can be set to {@link EUpdateMode#ECUC_AND_DEV_WS}. </div>
         *
         * @return {@code true / false}
         */
        @PublishedMethod
        boolean isEcucAndDevWsUpdateExecutable();

        /**
         * Checks if an update for only the Ecuc is executable with the given project. <div class="extdoc" id="isEcucOnlyUpdateExecutable">
         * <h5>Is Ecuc only Update executable</h5> Use {@link #isEcucAndDevWsUpdateExecutable} to get the information if an Ecuc only Update is executable. If this check returns
         * {@code true} the {@link EupdateMode} can be set to {@link EUpdateMode#ECUC_ONLY}. </div>
         *
         * @return {@code true / false}
         */
        @PublishedMethod
        boolean isEcucOnlyUpdateExecutable();
    }

    /**
     * <b>Note: this interface is not yet implemented.</b>
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IVariantConfigurationApi {

    }

    /**
     * <b>Note: this method is not yet implemented.</b>
     *
     * selects a variant for the input files. The list of input files can be modified at the delegated {@link IVariantConfigurationApi}.
     *
     * @param code the code
     * @return the optional result of the code closure
     */
    @PublishedMethod
    void variantConfiguration(@VDelegatesToWithClosureParam(IVariantConfigurationApi.class) Closure<?> code);

    /**
     * <b>Note: this method is not yet implemented.</b>
     *
     * getter for all available variants.
     *
     * @return List of {@link IVariantConfigurationApi}
     */
    @PublishedMethod
    IVariantConfigurationApi getVariantConfiguration();

    /**
     * Returns the {@link Path} to the Dpa file of this Project as absolute path.
     *
     * @return the project path to the Dpa file
     */
    @PublishedMethod
    Path getDpaProjectFilePath();

    /**
     * Configuration of common update settings.
     *
     * <p>
     * Usage example to set some update settings:
     *
     * <pre>
     * <code class="Java" id="description">
     * update(Paths.get("MyProject.dpa")){
     *   updateSettings{
     *     updateMode = ECUC_ONLY
     *     uuidUsageInStandardConfigurationEnabled = false
     *   }
     * }
     *
     * </code>
     * </pre>
     * </p>
     *
     * <div class="extdoc" id="CommonUpdateSettings"><!--Label:updateSettings-->The {@link #updateSettings()} is the entry point for accessing and modification of the update
     * settings. </div>
     *
     */
    @PublishedMethod
    void updateSettings(@VDelegatesToWithClosureParam(IUpdateSettingsApi.class) Closure<?> code);

}