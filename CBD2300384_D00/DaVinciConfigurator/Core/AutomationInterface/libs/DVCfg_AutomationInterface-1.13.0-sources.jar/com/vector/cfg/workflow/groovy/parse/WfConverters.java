package com.vector.cfg.workflow.groovy.parse;

import java.util.function.Function;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;

/**
 * {@link WfConverters} class provides static {@link Function}s to convert different object into each other.
 *
 * <div class="extdoc" id="Converters">
 *
 * <p>
 * The automation interface is typed strongly. In some cases, however, e.g. when specifying file locations, it is desirable to allow for a range of possibly parameter types.
 * This is achieved by accepting parameters of type {@link Object} and converting the given parameters to the desired type. {@link WfConverters} provides general purpose
 * {@link Function}s performing value conversions used throughout the automation interface.
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class WfConverters {

    @PublishedMethod
    private WfConverters() {
    }

    /**
     * <div class="extdoc" id="TO_SHORT_NAME_PATH_CONVERTER">
     *
     * <p>
     * {@link WfConverters#TO_SHORT_NAME_PATH_CONVERTER} attempts to convert arbitrary {@link Object}s to short name path {@link String}s. The following conversions are
     * implemented:
     * <ul>
     * <li>For {@code null} or {@link String} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link MIReferrable}s are converted using {@link AsrPath#create(MIReferrable)}.</li>
     * <li>{@link IWfReferrable}s are converted using {@link IWfReferrable#getAutosarPath()}.</li>
     * <li>All other {@link Object}s are converted by converting the {@link String} obtained from {@link Object#toString()}.</li>
     * </ul>
     * For thrown {@link Exception}s see the used functions described above.
     * </p>
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, String> TO_SHORT_NAME_PATH_CONVERTER = object -> {

        if (object == null || object instanceof String) {
            return (String) object;
        }

        if (object instanceof MIReferrable) {
            return AsrPath.create((MIReferrable) object).getAutosarPathString();
        }

        if (object instanceof IWfReferrable) {
            return ((IWfReferrable) object).getAutosarPath();
        }

        return object.toString();

    };

}
