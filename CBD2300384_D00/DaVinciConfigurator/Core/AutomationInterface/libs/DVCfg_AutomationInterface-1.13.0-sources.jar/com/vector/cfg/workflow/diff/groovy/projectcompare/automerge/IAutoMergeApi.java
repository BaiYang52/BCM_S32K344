package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IAutoMergeApi"><!--IAutoMergeApi-->{@link IAutoMergeApi} is the entry point for the automatic merge API. It offers interfaces for the configuration
 * and execution of the whole workflow.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAutoMergeApi {

    /**
     * Allows accessing the {@link IConfigureApi} like a property.
     *
     * @return the {@link IConfigureApi}
     */
    @PublishedMethod
    IConfigureApi getConfigure();

    /**
     * Allows accessing the {@link IConfigureApi} in a scope-like way.
     *
     * @param code the code (a {@link Closure}) working with the {@link IConfigureApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T configure(@VDelegatesToWithClosureParam(IConfigureApi.class) Closure<T> code);

}
