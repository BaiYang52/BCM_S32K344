/**
 * DaVinci Configurator logging API for text formatting and display.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.text.log;