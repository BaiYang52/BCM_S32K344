package com.vector.cfg.workflow.groovy.update.input;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.util.annotations.DeferredExecution;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.update.input.IExtractApiBase.IEcuInstanceSelectionApi;
import com.vector.cfg.workflow.groovy.update.input.IExtractApiBase.IUpdateEcuInstance;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * Modifies the list of communication input files.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationApi {

    /**
     * modifies the list of communication extracts.
     *
     * @param code the code {@link Closure} working with {@link ICommunicationExtractApi}.
     * @return the result of the code {@link Closure}
     */
    @PublishedMethod
    <T> T extract(@VDelegatesToWithClosureParam(ICommunicationExtractApi.class) Closure<T> code);

    /**
     * modifies the list of communication extracts.
     *
     * @return the {@link ICommunicationExtractApi}.
     */
    @PublishedMethod
    ICommunicationExtractApi getExtract();

    /**
     * <b>Note: this method is not yet implemented.</b>
     *
     * modifies the list of legacy communication input files.
     *
     * @param code the code {@link Closure} working with {@link ICommunicationLegacyApi}.
     * @return the result of the code {@link Closure}
     */
    @PublishedMethod
    <T> T legacy(@VDelegatesToWithClosureParam(ICommunicationLegacyApi.class) Closure<T> code);

    /**
     * <b>Note: this method is not yet implemented.</b>
     *
     * modifies the list of legacy communication input files.
     *
     * @return the {@link ICommunicationExtractApi}
     */
    @PublishedMethod
    ICommunicationLegacyApi getLegacy();

    /**
     * Modifies the list of communication extracts and selects the ecuInstance.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface ICommunicationExtractApi extends IExtractApiBase {

    }

    /**
     * Modifies the diagnostic legacy input files list and selects the ecuInstance and variant.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface ICommunicationLegacyApi {
        /**
         * modifies the list of legacy input files.
         *
         * <p>
         * <b>Note: This closure is deferred executed in the same thread as the script.</b>
         * </p>
         *
         * Example:
         *
         * <pre>
         * <code> legacyFiles{
         *          // clear the list of legacy files
         *          it.clear()
         *          // adds a legacy file
         *          it.add(legacyFilePath)
         *          }
         * </code>
         * </pre>
         */

        @PublishedMethod
        void legacyFiles(
                @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @DelegatesTo(target = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>", strategy = Closure.DELEGATE_FIRST) @ClosureParams(value = FromString.class, options = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>") Closure<?> code);

        /**
         * See {@link ICommunicationLegacyApi#legacyFiles(Closure)} for more information.
         *
         * @param code
         */
        @PublishedMethod
        void legacyFiles(
                @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Consumer<List<IPersistablePath>> code);

        /**
         * selects the ecuInstance of the legacy files to import.
         *
         * <p>
         * <b>Note: This closure is deferred executed in the same thread as the script.</b>
         * </p>
         *
         *
         * <pre>
         * <code>
        ecuInstanceSelection{
            ecuInstance = availableEcuInstances[0]
        }
         * </code>
         * </pre>
         *
         * @param code
         */
        @PublishedMethod
        void ecuInstanceSelection(
                @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @VDelegatesToWithClosureParam(IEcuInstanceSelectionApi.class) Closure<IUpdateEcuInstance> code);

        /**
         * See {@link IExtractApiBase#ecuInstanceSelection(Closure)} for more information.
         *
         * @param code
         */
        @PublishedMethod
        void ecuInstanceSelection(
                @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Function<IEcuInstanceSelectionApi, IUpdateEcuInstance> code);
    }
}