package com.vector.cfg.dom.runtimesys.groovy.api;

import java.nio.file.Path;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link ITimingExtensionsUpdateApi} provides the possibility to merge changes of timing extensions performed by the TA Tool Suite back into the Cfg5 workspace.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITimingExtensionsUpdateApi {

    /**
     * Merges the timing extension changes in the given files into the Cfg5 model.
     *
     * @param filePath file paths for the TA Tool Suite timing extension exports (arxml files).
     */
    @PublishedMethod
    void updateTimingExtensions(Path... filePath);

}
