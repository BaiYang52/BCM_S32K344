package com.vector.cfg.model.state;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interfaces specifies the common basis for the ECUC related CeStates.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucStatePublished extends ICeStatePublished {

    /**
     * Checks for pre configuration value.
     *
     * @return <code>true</code> if the pre-configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasPreConfigurationValue();

    /**
     * Checks for initial value.
     *
     * @return <code>true</code> if the initial configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasInitialValue();

    /**
     * Is there a corresponding entry in the recommended configuration for this object OR a default value in the definition. The values are not evaluated. NOTE: RecConfiguration as
     * well as ClassRecConfiguration will be checked.
     *
     * @return <code>true</code> if the recommended configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasRecommendedValue();

    /**
     * Checks whether there is a corresponding entry in the recommended configuration for this object.<br/>
     * NOTE: The values are not evaluated, ClassRecConfiguration will not be checked.
     *
     * @param considerDefault determines whether the default configurations should be considered as well.
     * @return <code>true</code> if there is recommended configuration (or default configuration in case of considerDefault), <code>false</code> otherwise.
     */
    @KeepSecretFromPublishedApi
    boolean hasRecommendedValue(boolean considerDefault);

    /**
     * Gets the pre configuration value.
     *
     * @return the value specified by the pre-configuration.
     */
    @PublishedMethod
    MIObject getPreConfigurationValue();

    /**
     * Gets the initial value.
     *
     * @return the value specified by the initial configuration.
     */
    @PublishedMethod
    MIObject getInitialValue();

    /**
     * Gets the soft derived CE.
     *
     * @return the CE specified by the soft derived configuration.
     */
    @PublishedMethod
    MIObject getSoftDerivedCe();

    /**
     * Gets the recommended value.
     *
     * @return the value specified by the recommended configuration.
     */
    @PublishedMethod
    MIObject getRecommendedValue();

    /**
     * This method allows checking if the supervised object (module configuration, container or parameter) will be changeable in the post-build phase. Be aware that the semantic of
     * this method adds model consistency checks like the pre-configuration check. If an object is pre-configured it will not be changeable in the post-build phase in either case.
     *
     * This method has been implemented to support CRC calculation of model content which is not post-build data. It will be used in the ECUM generator.
     *
     * @return true, if is change allowed in post build phase
     */
    @PublishedMethod
    boolean isChangeAllowedInPostBuildPhase();

    /**
     * This method allows checking if the supervised object (module configuration, container or parameter) will be deletable in the post-build phase. Be aware that the semantic of
     * this method adds model consistency checks like the pre-configuration check. If an object is pre-configured it will not be deletable in the post-build phase in either case.
     *
     * This method has been implemented to support CRC calculation of model content which is not post-build data. It will be used in the ECUM generator.
     *
     * @return true, if is deletion allowed in post build phase
     */
    @PublishedMethod
    boolean isDeletionAllowedInPostBuildPhase();

    /**
     * Checks for published information.
     *
     * @return <code>true</code> if the parameters definition specifies PUBLISHED-INFORMATION (for all configuration variants).
     */
    @PublishedMethod
    boolean hasPublishedInformation();

    /**
     * Checks if is published information.
     *
     * @return <code>true</code> if {@link #hasPublishedInformation()} returns true and the parameter value is the default value as specified by the definition.
     */
    @PublishedMethod
    boolean isPublishedInformation();

    /**
     * @returns the origin from where the CE was derivated.
     */
    @KeepSecretFromPublishedApi
    ECeOrigin getDerivationOrigin();

    /**
     * Checks for initial value with SoftDerived annotation.
     *
     * @return <code>true</code> if the initial configuration specifies a value for the CE with a SoftDerived annotation.
     */
    @KeepSecretFromPublishedApi
    boolean hasSoftDerivedValue();

}