/**
 * Modification of the input files list. <div class="extdoc" id="InputFiles"><!--UpdateWorkflow-->Modification of the input files list.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.groovy.update.input;