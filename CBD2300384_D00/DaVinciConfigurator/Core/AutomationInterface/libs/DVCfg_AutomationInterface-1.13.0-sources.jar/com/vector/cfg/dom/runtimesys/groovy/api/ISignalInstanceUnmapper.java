package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ISignalInstanceUnmapper"><!--Label:ISignalInstanceUnmapper-->{@link ISignalInstanceUnmapper} provides an Api to control and evaluate the unmapping of
 * {@link IAbstractSignalInstance}s from their mapped {@link ICommunicationElement}s. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceUnmapper {

    /**
     * <div class="extdoc" id="selectTargetCommunicationElements"><!--Label:ISignalInstanceUnmapper.selectTargetCommunicationElements-->
     * {@link #selectTargetCommunicationElements(Closure)} allows to define predicates to narrow down the target communciation elements to be unmapped from the previously
     * selected signal instances.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetCommunicationElements(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:ISignalInstanceUnmapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the results
     * of the signal instances which are about to be unmapped from communication elements.
     * <p>
     * For each selected signal instance the provided closure is called: Parameters are the current handled signal instance and a list of all mapped communication elements
     * (respecting the {@link #selectTargetCommunicationElements(Closure)} predicates). The return value must be a list of communication elements which are mapped to the current
     * handled signal instance.
     * </p>
     * </div>
     *
     * @param code The code to evaluate mapped communication elements which should be unmapped from the previously selected signal instances.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance,java.util.List<com.vector.cfg.model.sysdesc.api.com.ICommunicationElement>") @Nonnull Closure<List<ICommunicationElement>> code);

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetCommunicationElementsCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<List<ICommunicationElement>>> getEvaluateMatchesCode();

}
