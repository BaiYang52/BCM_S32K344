package com.vector.cfg.util.scripting.groovy;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;

/**
 * {@link VDelegatesToWithClosureParam} defines the parameter and the {@link DelegatesTo} of the annotated {@link Closure}. The {@link Class} types specify the parameter and the
 * delegation target of the closure. {@link VDelegatesToWithClosureParam} provides type information for the Groovy type system and IDE support.
 *
 * <p>
 * The usage of {@link VDelegatesToWithClosureParam} is especially good to replace the annotations {@link DelegatesTo} and {@link VClassClosureParams} annotations and the usage
 * of ClosureCalls class.
 * </p>
 *
 * <p>
 * Details: the {@link VDelegatesToWithClosureParam} is converted during PublishedApi compile time to {@link VClassClosureParams} value with one class and a {@link DelegatesTo}
 * annotation with class and strategy.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see Closure
 * @see DelegatesTo
 * @see VClassClosureParams
 * @see ClosureParams
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.CLASS)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Documented
public @interface VDelegatesToWithClosureParam {

    /**
     * The type of the {@link DelegatesTo} and {@link VClassClosureParams} annotations.
     *
     * @return the class[]
     */
    @PublishedMethod
    Class<?> value();

    /**
     * The {@link Closure#setResolveStrategy(int)}.
     *
     * @return the Closure resolve strategy
     */
    int strategy() default Closure.DELEGATE_FIRST;

}
