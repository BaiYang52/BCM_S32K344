package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.internal.contribution.helper.solvingactions.SetValue;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucEnumDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFloatDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucIntegerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucStringDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationLiteralDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets a parameter to its default value.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedFilter(MsrPlatform.class)
public class SetDefaultValueNonPublished<NUM_TEXT_TYPE extends MIParameterValue> extends SetValue<NUM_TEXT_TYPE> {
    /**
     * Constructor for SetDefaultValueInternal.
     *
     * @param parameter
     * @param value
     * @param isPublishedInformation
     */
    public SetDefaultValueNonPublished(NUM_TEXT_TYPE parameter, Object value, boolean isPublishedInformation) {
        super(parameter, value, isPublishedInformation);
        setTargetValueInfo(MixedText.newBuilder().append("default value").flushResult());
    }

    public static SetDefaultValue<?> create(MIParameterValue parameter) {
        return uncheckedCast(internalCreate(parameter, false));
    }

    public static SetDefaultValueNonPublished<?> createForPublishedInformation(MIParameterValue parameter) {
        return uncheckedCast(internalCreate(parameter, true));
    }

    /**
     * Returns specific SetDefaultValue object: API is unspecific for code sharing but nevertheless we want to avoid that non-consistency-internal it will be possible to change
     * values of published information.
     *
     * @param parameter
     * @param isPublishedInformation
     * @return
     */
    private static Object internalCreate(MIParameterValue parameter, boolean isPublishedInformation) {
        Object ret = null;
        try {
            final MIConfigParameter configParameter = parameter.getDefinitionRef().getRefTarget();
            final IEcucDefinitionAccess definitionAccess = ModelUtil.getProjectContext(configParameter).getService(IEcucDefinitionAccess.class);
            final IEcucParameterDefinition def = definitionAccess.def(configParameter);
            if (def instanceof IEcucBooleanDefinition) {
                final Optional<Boolean> defaultValue = ((IEcucBooleanDefinition) def).getDefault();
                if (defaultValue.isPresent()) {
                    ret = isPublishedInformation ? new SetDefaultValueNonPublished<>((MINumericalValue) parameter, defaultValue.get(), true)
                            : new SetDefaultValue<>((MINumericalValue) parameter, defaultValue.get());
                }
            } else if (def instanceof IEcucFloatDefinition) {
                final Optional<BigDecimal> defaultValue = ((IEcucFloatDefinition) def).getDefault();
                if (defaultValue.isPresent()) {
                    ret = isPublishedInformation ? new SetDefaultValueNonPublished<>((MINumericalValue) parameter, defaultValue.get(), true)
                            : new SetDefaultValue<>((MINumericalValue) parameter, defaultValue.get());
                }
            } else if (def instanceof IEcucIntegerDefinition) {
                final Optional<BigInteger> defaultValue = ((IEcucIntegerDefinition) def).getDefault();
                if (defaultValue.isPresent()) {
                    ret = isPublishedInformation ? new SetDefaultValueNonPublished<>((MINumericalValue) parameter, defaultValue.get(), true)
                            : new SetDefaultValue<>((MINumericalValue) parameter, defaultValue.get());
                }
            } else if (def instanceof IEcucEnumDefinition) {
                final Optional<MIEnumerationLiteralDef> defaultValue = ((IEcucEnumDefinition) def).getDefault();
                if (defaultValue.isPresent()) {
                    ret = isPublishedInformation ? new SetDefaultValueNonPublished<>((MITextualValue) parameter, defaultValue.get(), true)
                            : new SetDefaultValue<>((MITextualValue) parameter, defaultValue.get().getName());
                }
            } else if (def instanceof IEcucStringDefinition) {
                final Optional<String> defaultValue = ((IEcucStringDefinition) def).getDefault();
                if (defaultValue.isPresent()) {
                    ret = isPublishedInformation ? new SetDefaultValueNonPublished<>((MITextualValue) parameter, defaultValue.get(), true)
                            : new SetDefaultValue<>((MITextualValue) parameter, defaultValue.get());
                }
            }
        } catch (final Throwable e) {
            ret = null;
        }
        return ret;
    }
}
