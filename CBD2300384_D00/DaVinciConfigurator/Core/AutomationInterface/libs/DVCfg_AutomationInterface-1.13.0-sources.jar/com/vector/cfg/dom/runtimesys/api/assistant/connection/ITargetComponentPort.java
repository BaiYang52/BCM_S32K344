package com.vector.cfg.dom.runtimesys.api.assistant.connection;

import java.util.Optional;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;

/**
 * {@link ITargetComponentPort} is a specialization of {@link IComponentPort} and represents a potential target component port for a connection.
 * <p>
 * A target port comprises of <br/>
 * <li>a compatibility index for the connection to a source component port.
 * <li>an optional port interface mapping which will be used when connecting the component port to a source component port.</li>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITargetComponentPort extends IComponentPort {

    /**
     *
     * @return true if this target component port includes a port interface mapping.
     */
    @PublishedMethod
    boolean hasPortInterfaceMapping();

    /**
     *
     * @return The name of the included port interface mapping when present.
     */
    @PublishedMethod
    Optional<String> getPortInterfaceMappingName();

    /**
     *
     * @return The autosar path of the included port interface mapping when present.
     */
    @PublishedMethod
    Optional<String> getPortInterfaceMappingAutosarPath();

    /**
     *
     * @return The mdf object representing the included port interface mapping when present.
     */
    @PublishedMethod
    Optional<MIIdentifiable> getPortInterfaceMappingMdfObject();

    /**
     * The compatibility index is a non-normalized value computed for the name compatibility of a port and its elements.
     *
     * @return A compatibility index >= 0 when valid, < 0 when not computed.
     */
    @PublishedMethod
    int getCompatibilityIndex();

}
