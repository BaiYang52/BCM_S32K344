package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <div class="extdoc" id="PublishedFilter"> The {@link PublishedFilter} allows to filter classes, method and field (now called element) with a filter predicate of type
 * {@link PublishedFilterValue}. Multiple filters are combined with <code>AND</code> logic. The filter predicate defines where the element shall be <b>visible</b>.
 *
 * <p>
 * This can be used for example to filter a certain element only usable in the MSR platform (AUTOSAR classic).
 * </p>
 *
 * <p>
 * Usage example:
 *
 * <pre>
 * <code class="Java" id="PublishedFilter annotation example">
 * &#64;PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
 * public interface MyInterface {
 *
 *   &#64;PublishedMethod
 *   &#64;PublishedFilter(AMsrPlatform.class)
 *   void methodForAMsr(); // The method is only visible in AMSR.
 *
 *   &#64;PublishedMethod
 *   &#64;PublishedFilter(MsrPlatform.class)
 *   void methodForMsr(); // The method is only visible in MSR.
 * }
 * </code>
 * </pre>
 *
 * </p>
 * </div>
 * <p>
 * The {@link PublishedFilter} annotation <b>shall not be used by clients</b> using the published API. This is only for the export and tracking of the published API. So a client
 * shall not annotate any class or interface with the {@link PublishedApi} annotation.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.TYPE, ElementType.FIELD })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Repeatable(PublishedFilterContainer.class)
public @interface PublishedFilter {
    /**
     *
     * @return the filter predicate.
     */
    Class<? extends PublishedFilterValue> value();
}
