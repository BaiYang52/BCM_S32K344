package com.vector.cfg.model.cedescriptor.aspect;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptorAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidator;
import com.vector.cfg.model.cedescriptor.validator.impl.MdfMetaClassAspectValidator;
import com.vector.cfg.model.mdf.MIObject;

/**
 * {@code IMdfMetaClassAspect} defines the meta class of an {@link MIObject}. E.g. for an {@code MIPPortPrototype}, its corresponding meta class is
 * {@code MIPPortPrototype.class}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@AspectValidator(MdfMetaClassAspectValidator.class)
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMdfMetaClassAspect<T extends MIObject> extends IDescriptorAspect {

    @PublishedMethod
    Class<T> getMetaClass();
}
