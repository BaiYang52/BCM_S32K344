package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataCommunicationElement;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ICommunicationElementSelector} Api allows the definition of predicates for communication element selection.
 * <p>
 * <div class="extdoc" id="ICommunicationElementSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ReworkThisAtNextBreakingChange("Remove methods using @Override annotation and adapt documentation links")
public interface ICommunicationElementSelector extends IElementSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} Add a custom predicated which matches communication elements for which the given closure results
     * to true.</div>
     *
     * @param code The closure to select communication elements.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(ICommunicationElement.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="unconnected">{@link #unconnected()} matches communication elements whose component port is unconnected.</div>
     */
    @PublishedMethod
    void unconnected();

    /**
     * <div class="extdoc" id="connected">{@link #connected()} matches communication elements whose component port is connected.</div>
     */
    @PublishedMethod
    void connected();

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches communication elements whose are not data-mapped.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches communication elements whose are data-mapped.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches communication elements with the given data element or operation name.</div>
     *
     * @param name A data element, operation or trigger name.
     */
    @PublishedMethod
    void name(String name);

    /**
     * <div class="extdoc" id="names">{@link #names(Collection)} matches communication elements with the given data element or operation names. The order of the names is not
     * relevant in any kind.</div>
     *
     * @param names A collection of data element, operation or trigger names.
     */
    @PublishedMethod
    void names(Collection<String> names);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches communication elements with the given data element or operation name pattern.</div>
     *
     * @param namePattern A data element, operation or trigger name pattern.
     */
    @PublishedMethod
    void name(Pattern namePattern);

    /**
     * <div class="extdoc" id="fullyQualifiedName">{@link #fullyQualifiedName(String)} matches communication elements with the given full qualified communication element name.
     * E.g. 'App1.Port1.DataElement1', 'ECU Composition.DelegationPort2.DataElement2'. See also {@link ICommunicationElement#getFullyQualifiedName()}.</div>
     *
     * @param communicationElementName A full qualified communication element name.
     */
    @PublishedMethod
    void fullyQualifiedName(String communicationElementName);

    /**
     * <div class="extdoc" id="fullyQualifiedNames">{@link #fullyQualifiedNames(Collection)} matches communication elements with the given full qualified communication element
     * names. E.g. 'App1.Port1.DataElement1', 'ECU Composition.DelegationPort2.DataElement2'. See also {@link ICommunicationElement#getFullyQualifiedName()}. The order of the
     * names is not relevant in any kind.</div>
     *
     * @param communicationElementNames A collection of full qualified communication element names.
     */
    @PublishedMethod
    void fullyQualifiedNames(Collection<String> communicationElementNames);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches communication elements with the given data element or operation autosar path.</div>
     *
     * @param asrPath A data element, operation or trigger autosar path.
     */
    @PublishedMethod
    void asrPath(String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches communication elements with the given data element or operation autosar path pattern.</div>
     *
     * @param asrPathPattern A data element, operation or trigger autosar path pattern.
     */
    @PublishedMethod
    void asrPath(Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="port">{@link #port(String)} matches communication elements with the given component port name.</div>
     *
     * @param portName A port name.
     */
    @PublishedMethod
    void port(String portName);

    /**
     * <div class="extdoc" id="ports">{@link #ports(Collection)} matches communication elements with the given component port names. The order of the names is not relevant in
     * any kind.</div>
     *
     * @param portNames A collection of port names.
     */
    @PublishedMethod
    void ports(Collection<String> portNames);

    /**
     * <div class="extdoc" id="portPattern">{@link #port(Pattern)} matches communication elements with the given component port name pattern.</div>
     *
     * @param portNamePattern A component port name pattern.
     */
    @PublishedMethod
    void port(Pattern portNamePattern);

    /**
     * <div class="extdoc" id="portAsrPath">{@link #portAsrPath(String)} matches communication elements with the given component port autosar path.</div>
     *
     * @param portAsrPath A component port autosar path.
     */
    @PublishedMethod
    void portAsrPath(String portAsrPath);

    /**
     * <div class="extdoc" id="portAsrPathPattern">{@link #portAsrPath(Pattern)} matches communication elements with the given component port autosar path pattern.</div>
     *
     * @param portAsrPathPattern A component port autosar path pattern.
     */
    @PublishedMethod
    void portAsrPath(Pattern portAsrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches communication elements with the given component name.</div>
     *
     * @param componentName A component name.
     */
    @PublishedMethod
    void component(String componentName);

    /**
     * <div class="extdoc" id="components">{@link #components(Collection)} matches communication elements with the given component names. The order of the names is not relevant
     * in any kind.</div>
     *
     * @param componentNames A collection of component names.
     */
    @PublishedMethod
    void components(Collection<String> componentNames);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches communication elements with the given component name pattern.</div>
     *
     * @param componentNamePattern A component name pattern.
     */
    @PublishedMethod
    void component(Pattern componentNamePattern);

    /**
     * <div class="extdoc" id="componentAsrPath">{@link #componentAsrPath(String)} matches communication elements with the given component name autosar path.</div>
     *
     * @param componentAsrPath A component name autosar path.
     */
    @PublishedMethod
    void componentAsrPath(String componentAsrPath);

    /**
     * <div class="extdoc" id="componentAsrPathPattern">{@link #componentAsrPath(Pattern)} matches communication elements with the given component name autosar path
     * pattern.</div>
     *
     * @param componentAsrPathPattern A component name autosar path pattern.
     */
    @PublishedMethod
    void componentAsrPath(Pattern componentAsrPathPattern);

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches communication elements whose port has a sender/receiver port interface.</div>
     */
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches communication elements whose port has a client/server port interface.</div>
     */
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches communication elements whose port has a trigger port interface.</div>
     */
    @PublishedMethod
    void trigger();

    /**
     * <div class="extdoc" id="provided">{@link #provided()} matches communication elements whose port is a provided port (p-port).</div>
     */
    @PublishedMethod
    void provided();

    /**
     * <div class="extdoc" id="required">{@link #required()} matches communication elements whose port is a required port (r-port).</div>
     */
    @PublishedMethod
    void required();

    /**
     * <div class="extdoc" id="delegation">{@link #delegation()} matches communication elements whose port is delegation port.</div>
     */
    @PublishedMethod
    void delegation();

    /**
     * <div class="extdoc" id="ownerPortTerminated">{@link #ownerPortTerminated()} matches communication elements whose component port is terminated.</div>
     */
    @PublishedMethod
    void ownerPortTerminated();

    /**
     * <div class="extdoc" id="ownerPortNotTerminated">{@link #ownerPortNotTerminated()} matches communication elements whose component port is not terminated.</div>
     */
    @PublishedMethod
    void ownerPortNotTerminated();

    /**
     * <div class="extdoc" id="put">{@link #put(List)} can be used to set {@link ICommunicationElement}s into the selection. This is the most efficient way to create a selection
     * from existing objects. If further predicates are specified the predicates will be applied only on the communication elements that were given into this {@link #put(List)}
     * method. The iteration order is relevant for getting deterministic results on further usage of the selection API. This method should only be called once.</div>
     *
     * @throws SelectionException if the method is called more than once or if the given communicationElements are null.
     */
    @PublishedMethod
    void put(List<ICommunicationElement> communicationElements);

    /**
     * <div class="extdoc" id="selectFullyExpanded">{@link #selectFullyExpanded()} modifies the behavior of the selection. Using this option you are not only selecting the root
     * communication elements (as you know from the data mapping assistant in GUI), but also the leafs. See {@link IDataCommunicationElement#getLeafsFullExpanded()} for more
     * details.
     *
     * @exception SelectionException if both {@link #selectFullyExpanded()} and {@link #selectFullyExpandedButPrimitiveArraysAsLeafs()} are called. </div>
     */
    @PublishedMethod
    void selectFullyExpanded();

    /**
     * <div class="extdoc" id="selectFullyExpandedButPrimitiveArraysAsLeafs">{@link #selectFullyExpandedButPrimitiveArraysAsLeafs()} modifies the behavior of the selection.
     * Using this option you are not only selecting the root communication elements (as you know from the data mapping assistant in GUI), but also the leafs. Arrays of
     * primitives (e.g. uint8 arrays) will not be expanded. See {@link IDataCommunicationElement#getLeafsFullExpandedExceptPrimitiveArrays()} for more details.<br>
     *
     * @exception SelectionException if both {@link #selectFullyExpanded()} and {@link #selectFullyExpandedButPrimitiveArraysAsLeafs()} are called. </div>
     */
    @PublishedMethod
    void selectFullyExpandedButPrimitiveArraysAsLeafs();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<ICommunicationElement> getSelectedCommunicationElements();

    /**
     *
     * @return The selected communication elements filtered to be suitable for data mapping.
     */
    @KeepSecretFromPublishedApi
    List<com.vector.cfg.model.sysdesc.datamapping.ICommunicationElement> getSelectedCommunicationElementsSuitableForDataMapping();

}
