package com.vector.cfg.model.formula;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IHasFormulaString} defines an element which can return the used formula string.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IHasFormulaString {

    /**
     * Returns the formula string used to parse or represent this instance.
     *
     * <p>
     * Note: This may deviate from the real used formula, if normalizations were applied.
     * </p>
     *
     * @return the formula string
     */
    @PublishedMethod
    String getFormulaString();
}
