package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelVariantUnfilteredException extends ModelVariantException {

    private static final long serialVersionUID = 7435844959296861836L;

    /**
     * Constructor.
     *
     * @param message
     * @param source
     */
    @KeepSecretFromPublishedApi
    public ModelVariantUnfilteredException(String message, MIObject source) {
        this(message, source, null);
    }

    /**
     * Constructor.
     *
     * @param message
     * @param source
     * @param innerEx
     */
    @KeepSecretFromPublishedApi
    public ModelVariantUnfilteredException(String message, MIObject source, Throwable innerEx) {
        super(message, source, innerEx);
    }
}
