/**
 * Extensions to existing Java and Groovy classes for common classes of the JDK or Groovy runtime.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.scripting.groovy.extensions;