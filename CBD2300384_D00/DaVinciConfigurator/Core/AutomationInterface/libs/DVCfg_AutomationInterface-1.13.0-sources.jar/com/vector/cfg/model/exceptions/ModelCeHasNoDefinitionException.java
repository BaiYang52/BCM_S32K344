package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * Thrown to indicate that a {@link MIHasDefinition} object like Container has no corresponding definition.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelCeHasNoDefinitionException extends ModelInconsistencyException {

    private static final long serialVersionUID = -6250273989567268892L;

    private final MIHasDefinition mdfObject;

    /**
     * Constructor.
     *
     * @param mdfObject the MIObject which has no Definition
     */
    @PublishedMethod
    public ModelCeHasNoDefinitionException(MIHasDefinition mdfObject) {
        super("The definition is missing for " + checkMdfObjNonNull(mdfObject).toString() + ".");

        this.mdfObject = mdfObject;
    }

    @PublishedMethod
    public MIHasDefinition getCe() {
        return mdfObject;
    }
}
