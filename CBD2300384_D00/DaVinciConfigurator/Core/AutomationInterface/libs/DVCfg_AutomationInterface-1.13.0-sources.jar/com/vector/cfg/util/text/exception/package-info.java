/**
 * DaVinci Configurator text processing of {@link java.lang.Throwable}s and {@link java.lang.Exception}s.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.text.exception;