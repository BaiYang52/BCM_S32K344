package com.vector.cfg.dom.com.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link CanConfigException} is thrown by the {@link ICommunicationApi} when inconsistencies are found in the Can configuration.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class CanConfigException extends IllegalArgumentException {

    private static final long serialVersionUID = -2801227171642873520L;

    @PublishedMethod
    public CanConfigException(String message) {
        super(message);
    }

    @PublishedMethod
    public CanConfigException(String message, Throwable e) {
        super(message, e);
    }
}
