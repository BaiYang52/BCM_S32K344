package com.vector.cfg.util.text.format;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.davinci.util.base.VImmutableUtil.immutableList;
import static com.vector.davinci.util.base.VUtil.uncheckedCast;
import static com.vector.davinci.util.collections.MoreCollectors.toImmutableList;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

import org.apache.logging.log4j.Level;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.Platform;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.lang.ClassLinearization;
import com.vector.cfg.util.log.ILoggerMessageFormatter;
import com.vector.cfg.util.text.internal.format.FormatConstants;
import com.vector.cfg.util.text.log.IDetailedUserMessage;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.davinci.util.exceptions.VectorBugError;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// @CHECKSTYLE:OFF Enum name formatting is ok, because it is a Singleton
@ThreadSafe
public enum FormattingService implements ISpecificFormatterProvider, ILoggerMessageFormatter {
    // @CHECKSTYLE:ON
    INSTANCE;

    /*
     * DO NOT LOG things with logger level below WARN, this could lead to DeadLocks!
     */
    private static final String NL = System.lineSeparator();

    private static final String CLASS_TO_FORMAT_ATTR = "classToFormat";

    private static final String FORMATTER_CLASS_ATTR = "formatterClass";

    private static final String EXT_PATH_ID = "com.vector.cfg.util.text.formatter";

    private static final String NULL_STR = FormatConstants.NULL;

    /*
     * Do not use the com.vector.util.log.ILogger, because this will lead to a cyclic initialization and dependency problem.
     */
    private static final org.apache.logging.log4j.Logger logger;

    static {
        final org.apache.logging.log4j.Logger log4JLogger = org.apache.logging.log4j.LogManager.getLogger(FormattingService.class);
        com.vector.cfg.util.log.LoggerLevelUtil.setLogLevelLog4J(log4JLogger, Level.ERROR);
        logger = log4JLogger;
    }

    /*
     * Final Member fields
     */
    private static final IFormatter<?> ERROR_CASE_FORMATTER = (IFormatter<Object>) (arg, formatPattern) -> {
        if (arg == null) {
            return NULL_STR;
        }
        return arg.toString();
    };

    private static final List<IFormatter<?>> ERROR_CASE_FORMATTER_LIST = immutableList(ERROR_CASE_FORMATTER);

    private static final List<IFormatter<?>> NO_FORMATTER_FOUND_LIST = immutableList((arg, formatPattern) -> {
        throw new UnsupportedOperationException();
    });

    private final Object initSyncObject = new Object();

    private final ReentrantReadWriteLock classHierarchyResolverLock = new ReentrantReadWriteLock();

    @GuardedBy("classHierarchyResolverLock")
    private final WeakHashMap<Class<?>, List<IConfigurationElement>> classHierarchyResolver = new WeakHashMap<>();

    private final LoadingCache<Class<?>, List<IFormatter<?>>> formatterCache = CacheBuilder.newBuilder().weakKeys().concurrencyLevel(4)
            .build(new CacheLoader<Class<?>, List<IFormatter<?>>>() {

                @Override
                public List<IFormatter<?>> load(final Class<?> key) throws Exception {
                    final List<IFormatter<?>> formatter = createFormatterByClassToFormat(key);
                    if (formatter == null) {
                        return NO_FORMATTER_FOUND_LIST;
                    }
                    return formatter;
                }
            });

    /*
     * Non-final fields
     */
    @GuardedBy("initSyncObject")
    private volatile Map<String, IConfigurationElement> configuredFormatter;

    /*
     * Method Section
     */

    private void ensureInitialized() {
        if (configuredFormatter == null) {
            synchronized (initSyncObject) {
                // The field above is volatile!
                if (configuredFormatter == null) {
                    final Map<String, IConfigurationElement> configuredFormatterLoc = Maps.newHashMap();

                    if (Platform.getExtensionRegistry() != null) {
                        final IConfigurationElement[] config = Platform.getExtensionRegistry().getConfigurationElementsFor(EXT_PATH_ID);

                        for (final IConfigurationElement serviceElement : config) {
                            final String extensionType = serviceElement.getName();
                            if (extensionType.equals("formatter")) {

                                final String formatterClass = serviceElement.getAttribute(FORMATTER_CLASS_ATTR);
                                final String classToFormat = serviceElement.getAttribute(CLASS_TO_FORMAT_ATTR);

                                if (formatterClass == null || formatterClass.isEmpty()) {
                                    throw new IllegalStateException(FORMATTER_CLASS_ATTR + " attribute missing in extension point");
                                } else if (classToFormat == null || classToFormat.isEmpty()) {
                                    throw new IllegalStateException(CLASS_TO_FORMAT_ATTR + " attribute missing in extension point");
                                } else if (configuredFormatterLoc.containsKey(classToFormat)) {
                                    throw new IllegalStateException("There is already a formatter for the class type " + classToFormat);
                                }
                                // it is ok add it to the map

                                configuredFormatterLoc.put(classToFormat, serviceElement);
                            }

                        }
                    }

                    configuredFormatter = ImmutableMap.copyOf(configuredFormatterLoc);
                }
            }
        }
    }

    private List<IFormatter<?>> createFormattersFromEclipseExtension(final List<IConfigurationElement> formatterElements) {

        return formatterElements.stream().map(this::createFormatterFormEclipseExtension).filter(e -> e != null).collect(toImmutableList());
    }

    private IFormatter<?> createFormatterFormEclipseExtension(final IConfigurationElement formatterElement) {

        try {
            final Object formatter = formatterElement.createExecutableExtension(FORMATTER_CLASS_ATTR);
            if (!(formatter instanceof IFormatter<?>)) {
                return null;
            }

            return (IFormatter<?>) formatter;
        } catch (final Exception e) {
            logger.error(e);
            return null;
        }
    }

    @Nullable
    private <T> List<IFormatter<?>> createFormatterByClassToFormat(final Class<T> clazz) {
        return AccessController.doPrivileged((PrivilegedAction<List<IFormatter<?>>>) () -> {
            return createFormatterByClassToFormatPrivileged(clazz);
        });
    }

    @Nullable
    private <T> List<IFormatter<?>> createFormatterByClassToFormatPrivileged(final Class<T> clazz) {
        List<IConfigurationElement> elements;

        final Lock readLock = classHierarchyResolverLock.readLock();
        readLock.lock();
        try {
            if (classHierarchyResolver.containsKey(clazz)) {
                elements = classHierarchyResolver.get(clazz);
                if (elements == null) {
                    // No formatter available
                    return null;
                }

                // OK proceed

            } else {
                // Assign null to enable the search for the passed clazz
                elements = null;
            }
        } finally {
            readLock.unlock();
        }

        if (elements == null) {
            /*
             * Start search for a formatter class
             */
            final Lock writeLock = classHierarchyResolverLock.writeLock();
            writeLock.lock();
            try {
                if (!classHierarchyResolver.containsKey(clazz)) {
                    if (!searchForFormatter(clazz)) {
                        // Nothing found - No formatter available
                        return null;
                    }
                }
                elements = classHierarchyResolver.get(clazz);
                if (elements == null) {
                    // Nothing found
                    return null;
                }
            } finally {
                writeLock.unlock();
            }
        }

        /*
         * ConfigElement of Formatter found => Create new Formatter object
         */
        return createFormattersFromEclipseExtension(elements);
    }

    /**
     * searchForFormatter() must be called in a synchronized (classHierarchyResolverLock -WriteLock) context!
     */
    @GuardedBy("classHierarchyResolverLock - writelock")
    private boolean searchForFormatter(final Class<?> startClazz) {

        if (classHierarchyResolver.containsKey(startClazz)) {
            // Try if the currentClass is already in the Map
            final List<IConfigurationElement> elements = classHierarchyResolver.get(startClazz);
            if (elements != null) {
                return true;
            }

        } else {
            /*
             * No cache entry for the current class exists => Search for a entry
             */
            final List<Class<?>> classList = ClassLinearization.getLinerarClassHierarchy(startClazz);
            final List<IConfigurationElement> res = new ArrayList<>();
            for (final Class<?> currentClass : classList) {
                final IConfigurationElement element = getExactFormatterForClass(currentClass);
                if (element != null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Using Formatter of class " + currentClass.getName() + " to format class " + startClazz.getName());
                    }

                    res.add(element);
                }
            }

            if (!res.isEmpty()) {
                classHierarchyResolver.put(startClazz, ImmutableList.copyOf(res));
                return true;
            }

            // Nothing found
            if (logger.isDebugEnabled()) {
                logger.debug("No Formatter found  to format class " + startClazz.getName());
            }

            classHierarchyResolver.put(startClazz, null);
        }
        return false;
    }

    private IConfigurationElement getExactFormatterForClass(final Class<?> currentClass) {
        // Try to find configured formatter element by the currentClass
        final String name = currentClass.getCanonicalName();
        final IConfigurationElement element = configuredFormatter.get(name);
        if (element != null) {
            return element;
        }

        return null;
    }

    private IFormatter<?> getFormatterByObject(@Nonnull final Object obj, final EFormatType type) {
        Class<?> formatterClassToSearch = checkForStaticFormatterOrder(obj, type);
        if (formatterClassToSearch == null) {
            formatterClassToSearch = obj.getClass();
        }
        return getFormatter(formatterClassToSearch, type);
    }

    private Class<?> checkForStaticFormatterOrder(final Object obj, final EFormatType type) {
        switch (type) {
        case DEBUG:
            return checkForStaticFormatterOrderDebug(obj);
        case USER:
            return checkForStaticFormatterOrderUser(obj);
        default:
            throw new IllegalStateException();
        }
    }

    private Class<?> checkForStaticFormatterOrderUser(final Object obj) {
        /*
         *The UserMessages and MixedText always win when User log is requested.
         */
        if (obj instanceof IDetailedUserMessage) {
            return IDetailedUserMessage.class;
        }
        if (obj instanceof IUserMessage) {
            return IUserMessage.class;
        }
        if (obj instanceof IMixedText) {
            return IMixedText.class;
        }
        return null;
    }

    private Class<?> checkForStaticFormatterOrderDebug(final Object obj) {
        /*
         * IDebugable always overrule the other available Formatter in debug mode.
         */
        if (obj instanceof IDebugable) {
            return IDebugable.class;
        }

        return null;
    }

    /*
     * Public API section
     */
    @PublishedMethod
    @SuppressWarnings("rawtypes")
    @Override
    @Nullable
    public <T> IFormatter<T> getFormatter(final Class<T> clazz, final EFormatType type) {
        checkNotNull(type, "Parameter type is null");
        ensureInitialized();

        for (final IFormatter<T> formatter : getFormatters(clazz)) {
            if (formatter instanceof ISpecificFormatter) {
                final EFormatType formatType = ((ISpecificFormatter) formatter).getType();

                if (type.isTypeCompatible(formatType)) {
                    return formatter;
                }

            } else {
                return formatter;
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    @Nullable
    public <T> IFormatter<T> getFormatter(final Class<T> clazz) {
        checkNotNull(clazz, "Parameter clazz is null");

        ensureInitialized();

        try {
            final List<IFormatter<T>> formatters = getFormatters(clazz);
            if (!formatters.isEmpty()) {
                return formatters.get(0);
            }
            return null;
        } catch (final RuntimeException ex) {
            logger.error(ex);
            return (IFormatter<T>) ERROR_CASE_FORMATTER;
        }
    }

    @KeepSecretFromPublishedApi
    public <T> List<IFormatter<T>> getFormatters(final Class<T> clazz) {
        checkNotNull(clazz, "Parameter clazz is null");

        ensureInitialized();

        try {
            final List<IFormatter<?>> formatters = formatterCache.get(clazz);
            if (formatters == NO_FORMATTER_FOUND_LIST) {
                return immutableList();
            }
            return uncheckedCast(formatters);
        } catch (final ExecutionException ex) {
            logger.error(ex);
            return uncheckedCast(ERROR_CASE_FORMATTER_LIST);
        }
    }

    /**
     * Formats an object by an {@link IFormatter}, if any formatter was registered for this element.
     *
     * <p>
     * If no formatter is present .toString() is called
     * </p>
     *
     * @param obj the obj
     * @return the string
     */
    @PublishedMethod
    public String formatObject(final Object obj) {
        return formatObject(obj, "", EFormatType.USER);
    }

    /**
     * Format object by an {@link IFormatter}, if any formatter was registered for this element.
     *
     * <p>
     * If no formatter is present .toString() is called
     * </p>
     *
     * @param obj    the obj
     * @param format the format
     * @return the string
     */
    @PublishedMethod
    public String formatObject(final Object obj, final String format) {
        return formatObject(obj, format, EFormatType.USER);
    }

    /**
     * Format object by an {@link IFormatter}, if any formatter was registered for this element.
     *
     * <p>
     * If no formatter is present .toString() is called
     * </p>
     *
     * @param obj    the obj
     * @param format the format
     * @return the string
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @PublishedMethod
    public String formatObject(final Object obj, String format, EFormatType formatType) {
        if (obj == null) {
            return NULL_STR;
        }
        if (format == null) {
            format = "";
        }
        if (formatType == null) {
            formatType = EFormatType.USER;
        }

        final IFormatter formatter = getFormatterByObject(obj, formatType);
        if (formatter != null) {
            if (formatter instanceof IFormatterWithFormatType) {
                return ((IFormatterWithFormatType) formatter).format(obj, format, formatType);
            }
            return formatter.format(obj, format);
        }

        return obj.toString();
    }

    /**
     * Formats the passed message by replacing the placeholders, with the passed arguments in {index} style. See {@link IMixedTextBuilder#appendFormat(String, Object...)} for more
     * details.
     *
     *
     * @param message   the message to format
     * @param arguments the arguments.
     * @return the string
     */
    @PublishedMethod
    public String format(final String message, final Object... arguments) {
        return format(message, EFormatType.USER, arguments);
    }

    private String format(final String message, final EFormatType formatType, final Object... arguments) {
        if (message == null) {
            return NULL_STR;
        }
        if (message.isEmpty()) {
            return message;
        }
        final StringBuilder builder = new StringBuilder();

        StringFormatEvaluatorFactory.create(new IStringFormatConsumer() {

            @Override
            public void appendElementWithFormat(final Object obj, final String format) {
                builder.append(formatObject(obj, format, formatType));
            }

            @Override
            public void appendConstantString(final String constantText) {
                builder.append(constantText);

            }

            @Override
            public void appendFormattingToken(final EFormattingToken formattingElement) {
                if (formattingElement == EFormattingToken.NL) {
                    builder.append(NL);
                } else {
                    throw new VectorBugError();
                }
            }
        }, message).formatElements(arguments);

        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String formatDebug(final String message, final Object... arguments) {
        return format(message, EFormatType.DEBUG, arguments);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String formatEndUser(final String message, final Object... arguments) {
        return format(message, EFormatType.USER, arguments);
    }

    /**
     * Format a collection and all elements in the collection via the {@link FormattingService}.
     *
     * @param <T>  the generic type
     * @param coll the coll
     * @return the string
     */
    @PublishedMethod
    public <T> String formatCollection(final Collection<T> coll) {
        if (coll == null) {
            return NULL_STR;
        }

        return formatObject(coll);
    }

    /**
     * Format a collection and all elements in the collection via the {@link FormattingService}.
     *
     * @param <T>       the generic type
     * @param coll      the coll
     * @param separator the separator
     * @return the string
     */
    @PublishedMethod
    public <T> String formatCollection(final Collection<T> coll, final String separator) {
        if (coll == null) {
            return NULL_STR;
        }

        return formatObject(coll, separator);
    }

}
