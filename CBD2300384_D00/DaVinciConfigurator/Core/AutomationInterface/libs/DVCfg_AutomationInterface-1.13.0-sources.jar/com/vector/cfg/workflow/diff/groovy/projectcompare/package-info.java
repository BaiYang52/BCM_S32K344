/**
 * The Automation Interface provides an API for the comparison of DaVinci projects.
 *
 * <div class="extdoc" id="ProjectCompare"><!--ProjectCompare-->The Automation Interface provides an API for the comparison of DaVinci projects. </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.diff.groovy.projectcompare;