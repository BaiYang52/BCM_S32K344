package com.vector.cfg.model.cedescriptor.aspect;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptorAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidator;
import com.vector.cfg.model.cedescriptor.validator.impl.MdfObjectAspectValidator;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@AspectValidator(MdfObjectAspectValidator.class)
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMdfObjectAspect<T extends MIObject> extends IDescriptorAspect {
    @PublishedMethod
    T getObject();
}
