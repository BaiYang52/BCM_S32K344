/**
 * The result of the automatic merges of the DaVinci tools.
 *
 * <div class="extdoc" id="AutoMergeResult"><!--AutoMergeResult-->The result of the automatic merges of the DaVinci tools.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.result;