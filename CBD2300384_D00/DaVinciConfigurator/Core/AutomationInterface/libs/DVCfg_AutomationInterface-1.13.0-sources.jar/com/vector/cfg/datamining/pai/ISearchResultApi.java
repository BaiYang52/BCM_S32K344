package com.vector.cfg.datamining.pai;

import java.util.Collection;
import java.util.function.Predicate;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Strings;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common"> The {@link ISearchResultApi} provides the possibility to make evaluations based on the search results.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface ISearchResultApi {

    /**
     * <div class="extdoc" id="isConditionMet">Use {@link #isConditionMet(Predicate)} to pass a condition to the search result. With this condition a certain expectation can be
     * proven.</div>
     *
     * @param condition the condition
     * @return true, if successful
     */
    @PublishedMethod
    boolean isConditionMet(@Nonnull Predicate<ISearchResultApi> condition);

    /**
     * <div class="extdoc" id="isSize">Use {@link #isSize(ESearchOperator, int)} to pass a condition to compare it with the size of the search result. It can be used to check a
     * certain expectation. The passed operation ({@link ESearchOperator}) defines the condition.</div>
     *
     * @param operator the operator
     * @param value    the value
     * @return true, if successful
     */
    @PublishedMethod
    boolean isSize(@Nonnull ESearchOperator operator, int value);

    /**
     * <div class="extdoc" id="count">Use {@link #size()} to get the result size of the search.</div>
     *
     * @return the search count
     */
    @PublishedMethod
    int size();

    /**
     * <div class="extdoc" id="result">Use {@link #result()} to get a list of the result elements. The list contains ObjectLinks as {@link Strings}. Returns an empty list if no
     * elements are found.</div>
     *
     * @return the collection
     */
    @PublishedMethod
    Collection<String> result();
}
