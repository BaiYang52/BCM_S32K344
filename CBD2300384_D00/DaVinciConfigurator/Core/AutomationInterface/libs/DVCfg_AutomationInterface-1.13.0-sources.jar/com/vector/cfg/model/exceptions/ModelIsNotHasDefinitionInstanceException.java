package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * Thrown to indicate that a {@link MIObject} object is not an instance of {@link MIHasDefinition}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelIsNotHasDefinitionInstanceException extends ModelInconsistencyException {

    private static final long serialVersionUID = -7768658955630969953L;

    private final MIObject obj;

    @PublishedMethod
    public ModelIsNotHasDefinitionInstanceException(MIObject mdfObject) {
        super("The object '" + checkMdfObjNonNull(mdfObject).toString() + "' is not a module configuration, container or parameter. So it cannot hold a definition.");

        this.obj = mdfObject;
    }

    @PublishedMethod
    public MIObject getInstance() {
        return obj;
    }
}
