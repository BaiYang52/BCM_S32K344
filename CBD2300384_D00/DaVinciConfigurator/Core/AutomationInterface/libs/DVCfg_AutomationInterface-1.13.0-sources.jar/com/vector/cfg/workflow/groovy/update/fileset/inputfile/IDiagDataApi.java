package com.vector.cfg.workflow.groovy.update.fileset.inputfile;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IDiagDataApi {

    /**
     * returns all available and allowed variants for this Diagnostic Data input file.
     *
     * <div class="extdoc" id="getAvailableVariants"> Use {@link #getAvailableVariants()} to get all available variants for this diagnostic data input file.</div>
     *
     * @return
     */
    @PublishedMethod
    List<String> getAvailableVariants();

    /**
     * Sets the Diagnostic Variant option.
     *
     * <div class="extdoc" id="setVariant"> Use {@link #setVariant(String)} to set the according variant.</div>
     *
     * @param value
     */
    @PublishedMethod
    void setVariant(String value);

}
