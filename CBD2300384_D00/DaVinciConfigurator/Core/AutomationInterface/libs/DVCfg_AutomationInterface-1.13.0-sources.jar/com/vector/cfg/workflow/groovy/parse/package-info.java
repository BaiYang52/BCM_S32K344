/**
 * The Update Workflow API for parsing a evaluating input files and variants.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.groovy.parse;