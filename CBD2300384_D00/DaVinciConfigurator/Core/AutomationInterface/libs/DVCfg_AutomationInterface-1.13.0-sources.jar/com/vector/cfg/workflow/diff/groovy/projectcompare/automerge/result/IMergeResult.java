package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.result;

import java.nio.file.Path;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.IConfigureApi;

/**
 * <div class="extdoc" id="IMergeResult"><!--IMergeResult-->
 *
 * <img src="{@docRoot} /../_doc/UML/IMergeResult/MergeResultStructure.png" alt= "The structure of a merge result" id="MergeResultStructure" data-latex-style="scale=0.6" />
 *
 * <pre>
 * <!--PlantUML: MergeResultStructure
 *
 * interface {@link IMergeResult} {
 *  +getNotResolvedDifferences()
 *  +getPathToReportFile()
 *  +getPathToHtmlReportFile()
 * }
 *
 * interface {@link IDifference} {
 *  +getIdentifier()
 *  +getNotResolvableReason()
 * }
 *
 * {@link IMergeResult} "1" *-- "0..*" {@link IDifference}
 * -->
 * </pre>
 *
 * {@link IMergeResult} is the entry point for the automatic merge result to retrieve the not resolved differences and the path to the report file. <b>Note</b> that the
 * structure of the report is not stable and may change when another version of the DaVinci Configurator Classic is used. This API instead is kept stable.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IMergeResult {

    /**
     * <div class="extdoc" id="getNotResolvedDifferences">The method {@link #getNotResolvedDifferences()} is used to get all differences which haven't been resolved during the
     * automatic merge workflow.
     *
     * </div>
     *
     * @return all differences which haven't been resolved during the automatic merge workflow.
     */
    @PublishedMethod
    List<IDifference> getNotResolvedDifferences();

    /**
     * <div class="extdoc" id="getPathToReportFile">The method {@link #getPathToReportFile()} is used to get the {@link Path} to the result file of the automatic merge workflow.
     *
     * </div>
     *
     * @return the {@link Path} to the report file.
     */
    @PublishedMethod
    Path getPathToReportFile();

    /**
     * <div class="extdoc" id="getPathToHtmlReportFile">The method {@link #getPathToHtmlReportFile()} is used to get the {@link Path} to the HTML result file of the automatic merge
     * workflow. Note that this report is only created in case {@link IConfigureApi#setCreateMergeResultHtmlReport()} is set to {@code true}.
     *
     * </div>
     *
     * @return the {@link Path} to the HTML report file.
     */
    @PublishedMethod
    Path getPathToHtmlReportFile();

}
