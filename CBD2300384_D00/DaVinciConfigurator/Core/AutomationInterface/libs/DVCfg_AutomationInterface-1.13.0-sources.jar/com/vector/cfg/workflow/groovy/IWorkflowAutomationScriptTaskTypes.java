package com.vector.cfg.workflow.groovy;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.cfg.automation.scripting.base.IScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IProjectScriptTaskType;
import com.vector.cfg.workflow.EWorkflowAutomationScriptTaskTypes;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
//@CHECKSTYLE:OFF Disable no methods in interface warning
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IWorkflowAutomationScriptTaskTypes {

    /**
     * The {@link #DV_ON_SUCCESSFUL_UPDATE_WORKFLOW} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_ON_SUCCESSFUL_UPDATE_WORKFLOW">
     * <h5>Successful update workflow</h5> The type <b>{@link #DV_ON_SUCCESSFUL_UPDATE_WORKFLOW}</b> allows the script to access the loaded project during workflow after a
     * successful update. Every {@link #DV_ON_SUCCESSFUL_UPDATE_WORKFLOW} task is automatically executed, when the update has finished.<br>
     * <br>
     * Because the update workflow is executed in a temporary environment you can access the path to the original project folder by reading the task argument.
     * <p>
     *
     * <pre>
     *  code { path ->
     *       String originalProjectPath = path
     *  }
     * </pre>
     * <p>
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>On successful update workflow</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_ON_SUCCESSFUL_UPDATE_WORKFLOW</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically after successful update workflow</td>
     * </tr>
     * <tr>
     * <th>Required license</th>
     * <td>Development: .WF Execution: CFG PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_ON_SUCCESSFUL_UPDATE_WORKFLOW = EWorkflowAutomationScriptTaskTypes.DV_ON_SUCCESSFUL_UPDATE_WORKFLOW;

    /**
     * The {@link #DV_ON_FILE_PREPROCESSING_RESULT} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_ON_FILE_PREPROCESSING_RESULT">
     * <h5>Result file of the FilePrePocessing</h5> The type <b>{@link #DV_ON_FILE_PREPROCESSING_RESULT}</b> allows the script to modify the result file created in the update
     * workflow by the FilePreProcessing. Every {@link #DV_ON_FILE_PREPROCESSING_RESULT} task is automatically executed at the end of the FilePreprocessing. Scripts with this
     * ScriptTaskType have only access to the SystemExtract model.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>On FilePreProcessing result</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_ON_FILE_PREPROCESSING_RESULT</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically within the update workflow.</td>
     * </tr>
     * <tr>
     * <th>Required license</th>
     * <td>Development: .WF Execution: CFG PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_ON_FILE_PREPROCESSING_RESULT = EWorkflowAutomationScriptTaskTypes.DV_ON_FILE_PREPROCESSING_RESULT;

    /**
     * The {@link #DV_ON_FILE_PREPROCESSING_INPUT_FILE} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_ON_FILE_PREPROCESSING_INPUT_FILE">
     * <h5>FilePreProcessing input file</h5> The type <b>{@link #DV_ON_FILE_PREPROCESSING_INPUT_FILE}</b> allows the script to modify every input file which is used in the
     * update workflow except of ProjectStandardConfiguration and legacy diagnostic files. Legacy communication files (.dbc,...) are converted in the first step and afterwards
     * the result will be used for the script execution. Every {@link #DV_ON_FILE_PREPROCESSING_INPUT_FILE} task is automatically executed within the FilePrePocessing. Scripts
     * with this ScriptTaskType will be executed for all Autosar input files and have only access to the model.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>On Autosar input file</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_ON_FILE_PREPROCESSING_INPUT_FILE</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically within the FilePrePocessing of the update workflow.</td>
     * </tr>
     * <tr>
     * <th>Required license</th>
     * <td>Development: .WF Execution: CFG PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_ON_FILE_PREPROCESSING_INPUT_FILE = EWorkflowAutomationScriptTaskTypes.DV_ON_FILE_PREPROCESSING_INPUT_FILE;
}
