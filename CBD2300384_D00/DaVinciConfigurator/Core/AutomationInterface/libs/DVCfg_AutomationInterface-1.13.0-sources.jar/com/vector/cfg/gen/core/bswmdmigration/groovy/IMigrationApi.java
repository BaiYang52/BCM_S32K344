package com.vector.cfg.gen.core.bswmdmigration.groovy;

import java.nio.file.Path;

import javax.annotation.concurrent.ThreadSafe;

import org.junit.rules.MethodRule;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmigration.groovy.internal.MigrationClassRule;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common"> The {@link IMigrationApi} provides the possibility to verify the created migration rules individual. This will be done by writing a JUnit
 * test. It is mandatory to create a filter for the migration rule you want to test. The filter is the moduleDefRef ({@link DefRef}) and the version ({@link String}).<br>
 * <br>
 * To use the {@link IMigrationApi} it is necessary to specify the location of the .dpa file by using the {@link IMigrationApi#migrateTestsWith()}. Next, use the filter with the
 * {@link IMigrationApi#migrate(DefRef, String, Closure)} to execute the specific migration. After the migration the correct changes can be verified within the migrate(...){ ...
 * } closure. The verification can be done by JUnit Asserts. For the verification it is possible to use the {@link IModelAccess} which is accessible within the migrate
 * closure.<br>
 * <p>
 * <b>Note:</b> Each unit test runs in a separate transaction and can be tested individually. <b>The model will be completely reset for each unit test</b>.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IMigrationApi extends MethodRule {

    /**
     * <div class="extdoc" id="migrate"> Executes the migration with the given filter criterion. </div>
     *
     * @param <T>
     * @param moduleToMigrate
     * @param versionToMigrateTo
     * @param code
     * @return
     */
    @PublishedMethod
    <T> T migrate(DefRef moduleToMigrate, String versionToMigrateTo, @VDelegatesToWithClosureParam(IMigrationRuleVerificationApi.class) Closure<T> code);

    /**
     * <div class="extdoc" id="migrateTestsWith"> Specifies the project for the migrations. </div>
     *
     * @param dpaFileToLoad - The path of the .dpa file
     * @return The IMigrationClassRule.
     */
    @PublishedMethod
    static IMigrationClassRule migrateTestsWith(Path dpaFileToLoad) {

        return new MigrationClassRule(dpaFileToLoad);
    }

}
