package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ICommunicationElementUnmapper"><!--Label:ICommunicationElementUnmapper-->{@link ICommunicationElementUnmapper} provides an Api to control and evaluate
 * the unmapping of {@link ICommunicationElement}s from their mapped {@link IAbstractSignalInstance}s. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationElementUnmapper {

    /**
     * <div class="extdoc" id="selectTargetSignalInstances"><!--Label:ICommunicationElementUnmapper.selectTargetSignalInstances-->{@link #selectTargetSignalInstances(Closure)}
     * allows to define predicates to narrow down the target signal instances to be unmapped from the previously selected communication elements.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetSignalInstances(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:ICommunicationElementUnmapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the
     * results of the communication elements which are about to be unmapped from signal instances.
     * <p>
     * For each selected communication element the provided closure is called: Parameters are the current handled communication element and a list of all mapped signal instances
     * (respecting the {@link #selectTargetSignalInstances(Closure)} predicates). The return value must be a list of signal instances which are mapped to the current handled
     * communication element.
     * </p>
     * </div>
     *
     * @param code The code to evaluate mapped signal instances which should be unmapped from the previously selected communication elements.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.com.ICommunicationElement,java.util.List<com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance>") @Nonnull Closure<List<IAbstractSignalInstance>> code);

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetSignalInstancesCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<List<IAbstractSignalInstance>>> getEvaluateMatchesCode();

}
