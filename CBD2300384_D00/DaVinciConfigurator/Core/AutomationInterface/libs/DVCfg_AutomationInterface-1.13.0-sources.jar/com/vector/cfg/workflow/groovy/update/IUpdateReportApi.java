package com.vector.cfg.workflow.groovy.update;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common">The {@link IUpdateReportApi} is the entry point for accessing and modifying the update workflow report settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUpdateReportApi {

    /**
     * Alias for {@link #setCreateHtmlReport(boolean)}.
     *
     * @param derivative the derivative
     */
    @PublishedMethod
    void createHtmlReport(Boolean value);

    /**
     * Sets the create html report option.
     *
     * <div class="extdoc" id="setCreateHtmlReport">
     * <h5>Create HTML Report</h5> {@link #setCreateHtmlReport(Boolean)} sets the create html report option for the update workflow.</div>
     *
     * @param True if HTML report should be created, false otherwise
     */
    @PublishedMethod
    void setCreateHtmlReport(Boolean value);

    /**
     * Alias for {@link #setCreateXmlFile(boolean)}.
     *
     * @param derivative the derivative
     */
    @PublishedMethod
    void createXmlFile(Boolean value);

    /**
     * Sets the create xml file option.
     *
     * <div class="extdoc" id="setCreateXmlFile">
     * <h5>Create XML file</h5> {@link #setCreateXmlFile(Boolean)} sets the create xml file report option for the update workflow.</div>
     *
     * @param True if XML file should be created, false otherwise
     */
    @PublishedMethod
    void setCreateXmlFile(Boolean value);
}
