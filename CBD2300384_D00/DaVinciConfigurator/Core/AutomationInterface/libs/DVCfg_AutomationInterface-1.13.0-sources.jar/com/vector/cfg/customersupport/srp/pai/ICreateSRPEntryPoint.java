package com.vector.cfg.customersupport.srp.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common"> The {@link #createSupportRequestPackage(Closure)} provides the possibility to create a support request package. It also provides options to
 * configure the creation of the SRP, means to include required project informations.<br>
 * <br>
 * The following example shows the minimal setup to create a SRP.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@PublishedFilter(MsrPlatform.class)
@ThreadSafe
public interface ICreateSRPEntryPoint {

    /**
     * Creates the support request package api.
     *
     * @param <T>  the generic type
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    <T> T createSupportRequestPackage(@VDelegatesToWithClosureParam(ICreateSRPApi.class) Closure<T> code);

}
