package com.vector.cfg.model.access;

import java.util.Collection;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.ar4x.swcomponenttemplate.datatype.datatypes.MIAutosarDataType;
import com.vector.cfg.model.mdf.ar4x.swcomponenttemplate.datatype.datatypes.MIAutosarDataTypeARRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDefARRef;

/**
 * <h3>For Classic AUTOSAR</h3> <div class="extdoc" id="CommonClassic">
 * <h2>IReferenceAccess</h2> <!--LaTeX:\label{sec:IReferenceAccess}--> The {@link IReferenceAccess} is a basic model service which provides methods to simplify reference
 * handling.
 *
 * <ul>
 * <li>{@link #getRefTarget(MIARRef)}: Returns the target object, an AUTOSAR reference points to. This method works for all reference types and therefore returns an object of
 * type MIReferrable. This is the base type all reference target types must implement
 * <li>{@link #getReferenceTarget(MIReferenceValue)}: Returns the target object of a reference-value (ECUC parameter of type MIReferenceValue)</li>
 * <li>{@link #sortReferences(Collection)}: Sorts a collection of AUTOSAR references to guarantee deterministic order for example during code generation (the sort criteria are
 * described in the JavaDoc documentation in the code).</li>
 * <li>{@link #getAllReferencesPointingTo(MIReferrable)}: This is the reverse operation of {@link #getRefTarget(MIARRef)}</li>
 * <li>{@link #getReferenceParametersPointingTo(MIReferrable)}: This is the reverse operation of {@link #getReferenceTarget(MIReferenceValue)}</li>
 * </ul>
 *
 * </div> <div class="extdoc" id="AutosarReferencesClassic" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation;DvCfgDevDocu"> All AUTOSAR reference objects in
 * the MDF model have the base interface {@link MIARRef}.
 * <p>
 * Figure <!--LaTeX:\vref{fig:AutosarContainerDefRef}--> shows this type hierarchy for the definition reference of an ECUC container. <br/>
 * <img src="{@docRoot} /../_doc/UML/IReferenceAccess/AutosarContainerDefRef.png" alt="The ECUC container definition reference" id="fig:AutosarContainerDefRef " data-latex-style
 * ="scale=0.7" />
 * </p>
 * <p>
 * In ARXML, such a reference can be specified as:
 *
 * <pre>
 * &lt;DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF"&gt;
 *     /MICROSAR/Com/ComGeneral
 * &lt;/DEFINITION-REF&gt;
 * </pre>
 *
 * <pre>
 * <!--PlantUML: AutosarContainerDefRef
 * class {@link MIARRef}{
 *   getValue():String
 * }
 * class {@link MIContainerDefARRef}{
 *  getRefTarget():MIContainerDef
 * }
 * {@link MIARRef}<|-_{@link MIContainerDefARRef}
 *
 * class {@link MIContainerDef} {
 *
 * }
 * {@link MIContainerDefARRef} "0..1" o-_ {@link MIContainerDef}
 * -->
 * </pre>
 *
 * <ul>
 * <li>{@link MIARRef#getValue()} returns the AUTOSAR path of the object, the reference points to (as specified in the ARXML file). In the example above
 * <code>"/MIRCOSAR/Com/ComGeneral"</code> would be this value</li>
 * <li>{@link MIContainerDefARRef#getRefTarget()} on the other hand returns the referenced MDF object if it exists. This method is located in a specific, typesafe (according to
 * the type it points to) reference interface which extends {@link MIARRef}. So, if an object with the AUTOSAR path <code>"/MIRCOSAR/Com/ComGeneral"</code> exists in the model,
 * this method will return it
 * </ul>
 * </p>
 * </div>
 * <h3>For Adaptive AUTOSAR</h3> <div class="extdoc" id="CommonAdaptive">
 * <h2>IReferenceAccess</h2> <!--LaTeX:\label{sec:IReferenceAccess}-->
 *
 * The {@link IReferenceAccess} is a basic model service which provides methods to simplify reference handling.
 *
 * <ul>
 * <li>{@link #getRefTarget(MIARRef)}: Returns the target object, an AUTOSAR reference points to. This method works for all reference types and therefore returns an object of
 * type MIReferrable. This is the base type all reference target types must implement
 * <li>{@link #sortReferences(Collection)}: Sorts a collection of AUTOSAR references to guarantee deterministic order for example during code generation (the sort criteria are
 * described in the JavaDoc documentation in the code).</li>
 * <li>{@link #getAllReferencesPointingTo(MIReferrable)}: This is the reverse operation of {@link #getRefTarget(MIARRef)}</li>
 * </ul>
 *
 * </div> <div class="extdoc" id="AutosarReferencesAdaptive" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation;DvCfgDevDocu"> All AUTOSAR reference objects in
 * the MDF model have the base interface {@link MIARRef}.
 *
 * <p>
 * Figure <!--LaTeX:\vref{fig:AutosarVdpTypeRef}--> shows this type hierarchy for the autosar type reference of a variable data prototype. <br/>
 * <img src="{@docRoot} /../_doc/UML/IReferenceAccess/AutosarVdpTypeRef.png" alt="The autosar data type reference" id="fig:AutosarVdpTypeRef " data-latex-style ="scale=0.7" />
 * </p>
 * <p>
 * In ARXML, such a reference can be specified as:
 *
 * <pre>
 * &lt;TYPE-TREF DEST="IMPLEMENTATION-DATA-TYPE"&gt;
 *     /DataTypes/MyImplDataType
 * &lt;/TYPE-TREF&gt;
 * </pre>
 *
 * <pre>
 * <!--PlantUML: AutosarVdpTypeRef
 * interface {@link MIARRef}{
 *   getValue():String
 * }
 * interface {@link MIAutosarDataTypeARRef}{
 *  getRefTarget():MIAutosarDataType
 * }
 * {@link MIARRef}<|-_{@link MIAutosarDataTypeARRef}
 *
 * interface {@link MIAutosarDataType} {
 *
 * }
 * {@link MIAutosarDataTypeARRef} "0..1" o-_ {@link MIAutosarDataType}
 * -->
 * </pre>
 *
 * <ul>
 * <li>{@link MIARRef#getValue()} returns the AUTOSAR path of the object, the reference points to (as specified in the ARXML file). In the example above
 * <code>"/DataTypes/MyImplDataType"</code> would be this value</li>
 * <li>{@link MIAutosarDataTypeARRef#getRefTarget()} on the other hand returns the referenced MDF object if it exists. This method is located in a specific, typesafe (according
 * to the type it points to) reference interface which extends {@link MIARRef}. So, if an object with the AUTOSAR path <code>"/DataTypes/MyImplDataType"</code> exists in the
 * model, this method will return it
 * </ul>
 * </p>
 * </div>
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IReferenceAccess {

    /**
     * This method returns the target object of the specified reference. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     *
     * @param ref
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getRefTarget(MIARRef ref);

    /**
     * This method returns all target objects of the specified reference. It returns an empty collection in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param ref
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getRefTargets(MIARRef ref);

    /**
     * This method returns the target object of the specified reference parameter. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     *
     * @param parameter
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getReferenceTarget(MIReferenceValue parameter);

    /**
     * This method returns all target objects of the specified reference parameter. It returns an empty collection in the following cases:
     * <ul>
     * <li>If the reference parameter has no reference value
     * <li>If the parameters reference value has no target
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param parameter
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getReferenceTargets(MIReferenceValue parameter);

    /**
     * This method sorts the specified collection of reference objects to guarantee deterministic order.
     * <p>
     * The criterion to be sorted by is the object link of the reference objects. If this link is equal, the reference values (AUTOSAR path) will be compared.
     * </p>
     *
     * @param references
     * @return
     * @throws NullPointerException if the specified collection is <code>null</code>
     */
    @PublishedMethod
    <T extends MIARRef> List<T> sortReferences(Collection<T> references);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    Collection<MIARRef> getAllReferencesPointingTo(MIReferrable referrable);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The returned
     * references are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    List<MIARRef> getAllReferencesPointingToSorted(MIReferrable referrable);

    /**
     * Returns all reference parameters pointing to the specified target object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The
     * returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(MIReferrable target);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param definition is a parameter definition (absolute definition path or its last shortname)
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(MIReferrable target, String definition);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param defRef is a parameter {@link DefRef}
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(MIReferrable target, DefRef defRef);

    /**
     * This method returns all model objects which are parent objects of references pointing to the specified target. It returns an empty collection if the object is invisible,
     * removed or <code>null</code>.
     * <p>
     * The returned list may also contain derived objects (located in the InitialEcuC).
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getObjectsPointingTo(MIReferrable target);

    /**
     * This method returns all parameter objects located in the ActiveEcuC which are parent objects or references pointing to the specified target. It returns an empty
     * collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * The returned objects can be of type {@link MIReferenceValue} and {@link MIInstanceReferenceValue}.
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIParameterValue> getActiveEcucParametersPointingTo(MIReferrable target);

    /**
     * This method returns all objects located in the system description which are parent objects of references pointing to the specified target. It returns an empty collection
     * if the object is invisible, removed or <code>null</code>.
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getSystemDescriptionObjectsPointingTo(MIReferrable target);

}
