package com.vector.cfg.model.access.ecuconfiguration.reference;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucInstanceRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.mdf.model.autosar.base.MIARAnyInstanceRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucInstanceReferenceParameter extends IEcucParameter {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    MIInstanceReferenceValue getEcucObject();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucInstanceRefDefinition getEcucDefinition();

    /**
     * Returns the instance references value object if available and <code>null</code> else.
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    MIARAnyInstanceRef getValue();

    /**
     * Sets the target path of the instance reference. <code>null</code> is permitted to remove the value.
     *
     * @param value
     */
    @KeepSecretFromPublishedApi
    void setTarget(AsrPath value);

    /**
     * Sets the context paths of the instance reference. This method replaces the already existing context references. <code>null</code> is permitted to clear the list.
     *
     * @param value
     */
    @KeepSecretFromPublishedApi
    void setContext(List<AsrPath> value);

}
