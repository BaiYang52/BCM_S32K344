package com.vector.cfg.util.version;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IVersion extends Comparable<IVersion> {

    /**
     * @return The major version number
     */
    @PublishedMethod
    int getMajor();

    /**
     * @return <code>true</code> if the minor version is available
     */
    @PublishedMethod
    boolean hasMinor();

    /**
     * @return The minor version number or the integer value 0 if not available
     */
    @PublishedMethod
    int getMinor();

    /**
     * @return <code>true</code> if the patch level is available
     */
    @PublishedMethod
    boolean hasPatchLevel();

    /**
     * @return The patch level number or the integer value 0 if not available
     */
    @PublishedMethod
    int getPatchLevel();

    /**
     * @return <code>true</code> if the build number is available
     */
    @PublishedMethod
    boolean hasBuild();

    /**
     * @return The build number or the integer value 0 if not available
     */
    @PublishedMethod
    int getBuild();

    /**
     * @return <code>true</code> if the suffix is available
     */
    @PublishedMethod
    boolean hasSuffix();

    /**
     * @return The associated suffix string or "" if there is no suffix available.
     */
    @PublishedMethod
    String getSuffix();

}