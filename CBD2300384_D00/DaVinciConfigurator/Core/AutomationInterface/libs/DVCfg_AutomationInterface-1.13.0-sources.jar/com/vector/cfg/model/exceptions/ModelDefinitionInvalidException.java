package com.vector.cfg.model.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelDefinitionInvalidException extends ModelInconsistencyException {

    private static final long serialVersionUID = -6434102402230715794L;

    private final String definitionPath;

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelDefinitionInvalidException(@Nonnull String msg, @Nonnull String definitionPath) {
        super(checkNotNull(msg));
        this.definitionPath = definitionPath;
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelDefinitionInvalidException(@Nonnull String msg, @Nonnull DefRef defRef) {
        super(checkNotNull(msg));
        this.definitionPath = defRef.getDefRefString();
    }

    @PublishedMethod
    public String getDefinition() {
        return definitionPath;
    }

}
