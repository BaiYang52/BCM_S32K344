package com.vector.cfg.model.access;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * /** <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation;DvCfgDevDocu">
 * <h2>TypedAsrPath</h2> <!--LaTeX: \label{sec:TypedAsrPath} --> The {@link TypedAsrPath} class represents an AUTOSAR path without a connection to any model.
 * {@link TypedAsrPath}s are a concatenation of unique identifiers, e.g. short-names used for identifying a module, container etc. and should be used instead of plain
 * {@link String} path representations, as they are validated upon creation and ensure type safety.
 *
 * This class is immutable, i.e. it cannot be changed after creation!
 * <h5>Creation</h5>A {@link TypedAsrPath} object can be created with the <code>TypedAsrPath.create()</code> function that either takes a {@link String}, or a
 * {@link MIReferrable} as argument. Furthermore, an existing {@link TypedAsrPath} can be concatenated with an additional path segment using the
 * <code>TypedAsrPath.create(AsrPath, String)</code> function.
 *
 * If the specified reference or path is invalid, <code>TypedAsrPath.create()</code> will throw an exception. In order to prevent that, one could use the safe alternative
 * <code>TypedAsrPath.tryCreate()</code> which, instead of throwing an exception, would simply return <code>null</code>.
 *
 * <pre>
 * <code class="Java" id="TypedAsrPath creation methods">
 * MyReferrable myReferrable = ...;
 *
 * //Create some TypedAsrPaths
 * TypedAsrPath<MyReferrable> plainStringPath = TypedAsrPath.create("/ActiveEcuC/PduR/PduRRoutingTables/PduRRoutingPathGroup", MyReferrable.class);
 * TypedAsrPath<MyReferrable> refererrablePath = TypedAsrPath.create(myReferrable);
 * TypedAsrPath<MyReferrable> concatPath = TypedAsrPath.create(plainStringPath, "pathSegment", MyReferrable.class);
 * TypedAsrPath<MyReferrable> safePath = TypedAsrPath.tryCreate("invalid/path", MyReferrable.class); //null
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TypedAsrPath<METACLASS_TYPE extends MIReferrable> extends AsrPath implements IDebugable {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TypedAsrPath.class);

    private final com.vector.cfg.model.base.api.access.TypedAsrPath<METACLASS_TYPE> asrPath;

    TypedAsrPath(com.vector.cfg.model.base.api.access.TypedAsrPath<METACLASS_TYPE> delegate) {
        this.asrPath = delegate;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @KeepSecretFromPublishedApi
    protected com.vector.cfg.model.base.api.access.AsrPath getDelegateAsrPath() {
        return asrPath;
    }

    /**
     * Returns the MetaModelClass object of the AUTOSAR element.
     *
     * @return the MetaModel class object.
     */
    @PublishedMethod
    public Class<METACLASS_TYPE> getMetaModelClass() {
        return asrPath.getMetaModelClass();
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject.
     *
     *
     * <p>
     * Note: This method is an implicit null and modelObjectClass class check. This means, if it returns true, the modelObject is an instance of modelObjectClass.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject and it is instance of modelObjectClass.
     *
     */
    @PublishedMethod
    @Override
    public boolean isPathOf(final MIObject modelObject) {
        return asrPath.isPathOf(modelObject);
    }

    /**
     * {@inheritDoc}
     *
     * @deprecated DO NOT use this method! Use {@link #isPathOf(MIObject)} instead, because a {@link TypedAsrPath} already provides the type information.
     */
    @PublishedMethod
    @Deprecated
    @Override
    public <R extends MIReferrable> boolean isPathOf(final MIObject modelObject, final Class<R> classToCheck) {
        return asrPath.isPathOf(modelObject, classToCheck);
    }

    /**
     * {@inheritDoc}
     *
     * @deprecated DO NOT use this method! Use {@link #asPathOf(MIObject)} instead, because a {@link TypedAsrPath} already provides the type information.
     */
    @PublishedMethod
    @Deprecated
    @Override
    public <R extends MIReferrable> R asPathOf(final MIObject modelObject, final Class<R> classToCheck) {
        return asrPath.asPathOf(modelObject, classToCheck);
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of modelObjectClass. If the check is true, the method returns the object
     * casted to modelObjectClass. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>object</code>, if this is the AUTOSAR path of the modelObject and it is instance of modelObjectClass. Otherwise null.
     * @see #isDefinitionOf(MIObject)
     *
     */
    @PublishedMethod
    public METACLASS_TYPE asPathOf(final MIObject modelObject) {
        return asrPath.asPathOf(modelObject);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {
        return asrPath.toDebugString();
    }

}
