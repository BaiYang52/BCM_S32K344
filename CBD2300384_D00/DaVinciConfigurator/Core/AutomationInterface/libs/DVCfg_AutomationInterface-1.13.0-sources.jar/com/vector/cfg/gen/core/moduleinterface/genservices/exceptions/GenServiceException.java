package com.vector.cfg.gen.core.moduleinterface.genservices.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.genservices.IGenServiceProvider;

/**
 * {@link GenServiceException} is thrown by the {@link IGenServiceProvider}, if a requested GenService does not exist.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenServiceException extends RuntimeException {

    private static final long serialVersionUID = 15214386153878626L;

    // private static final ILogger logger = Logger.INSTANCE.createLogger(GenServiceException.class);

    /**
     * Constructor for GenServiceException.
     *
     * @param message the message
     * @param cause the cause
     */
    @PublishedMethod
    public GenServiceException(String message, Throwable cause) {
        super(message, cause);

    }

    /**
     * Constructor for GenServiceException.
     *
     * @param message the message
     */
    @PublishedMethod
    public GenServiceException(String message) {
        super(message);
    }

    /**
     * Constructor for GenServiceException.
     *
     * @param cause the cause
     */
    @PublishedMethod
    public GenServiceException(Throwable cause) {
        super(cause);
    }

}
