package com.vector.cfg.model.access;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.function.Predicate;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucForeignRefDefinition;
import com.vector.cfg.model.exceptions.UnexpectedTypeException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.MIMDFRootArtefact;
import com.vector.cfg.model.mdf.model.MIModelInfo;
import com.vector.cfg.model.mdf.model.autosar.base.MIARPackage;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcuConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucDefinitionCollection;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.operations.IModelOperationsPublished;
import com.vector.cfg.util.math.MBigDecimal;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.version.IVersion;

/**
 * <div class="extdoc" id="Common">
 * <h2>IModelAccess</h2> The {@link IModelAccess} is a basic model service which collects several general access utility methods.
 *
 * The most basic are:
 * <ul>
 * <li>{@link #getAutosarRoot()}: Returns the root object of the AUTOSAR data model tree</li>
 * <li>{@link #getImmediateParent(MIObject)}: Returns the parent object of the specified instance</li>
 * <li>{@link #getAllInstancesOfType(Class)}: Returns all MDF instances of the specified type</li>
 * </ul>
 * </div>
 * <h3>Invisible Object Handling</h3> <div class="extdoc" id="InvisibleObjectsAccess"> To simplify handling of invisible objects, some model services provide model access even
 * for invisible objects in variant projects. The affected classes and interfaces are:
 * <ul>
 * <li>{@link ModelUtil}</li>
 * <li>{@link ModelAccessUtil}</li>
 * <li>{@link IReferrableAccess}</li>
 * <li>{@link IModelAccess}</li>
 * <li>{@link IModelCompareService}</li>
 * <li>{@link AsrPath}</li>
 * <li>{@link DefRef}</li>
 * <li>{@link IEcucDefinitionAccess} (all methods which deal with configuration side objects)</li>
 * </ul>
 *
 * Only a subset of the methods in these services work with invisible objects (read the methods JavaDoc for details). The general policy to select exactly these methods was:
 * <ul>
 * <li>Support access to type and object identity of MDF objects (definition and AUTOSAR path)</li>
 * <li>Parameter value or other content related information must still be retrieved in a context the object is visible in</li>
 * <li>Also not contained are methods which change model content. E.g. deleting invisible objects, set parameter values, ...</li>
 * </ul>
 *
 * </div>
 * <h3>For Classic AUTOSAR</h3> <div class="extdoc" id="CommonForClassic">
 * <h3>Module configuration and module definition handling</h3>
 *
 * <ul>
 * <li>{@link #getModuleConfiguration(MIObject)}: Returns the module configuration (parent) object of an ECUC object like containers, for example</li>
 * <li>{@link #getModuleDefinition(MIObject)}: Returns the module definition object of an ECUC objects module configuration</li>
 * <li>{@link #isRefinedModuleDefinition(String,String)}: Analyzes module definition refinements</li>
 * <li>{@link #getAllWithDefinition(String)}: Returns all object instances with a specific definition path</li>
 * <li>{@link #getAllStandardDefinitions()}: Returns all AUTOSAR standard definition</li>
 * <li>{@link #getAllModuleDefinitions()}: Returns all loaded {@link MIModuleDef} module definitions</li>
 * </ul>
 *
 * <h3>Get child objects by definition</h3>
 *
 * The following methods navigate through the ECUC model tree and returns objects of the specified definition type:
 * <ul>
 * <li>{@link #getChildByDefinition(MIHasContainer,String)}</li>
 * <li>{@link #getChildrenByDefinition(MIHasContainer,String)}</li>
 * <li>{@link #getContainerByDefinition(MIHasContainer,String)}</li>
 * <li>{@link #getContainersByDefinition(MIHasContainer,String)}</li>
 * <li>{@link #getParentContainerByDefinition(MIHasDefinition,String)}</li>
 * <li>{@link #getParentByDefinition(MIHasDefinition,String)}</li>
 * <li>{@link #getParameterByDefinition(MIContainer,String)}</li>
 * <li>{@link #getParametersByDefinition(MIContainer,String)}</li>
 * </ul>
 *
 * The String argument is an absolute or relative definition path. These get-methods also exists in overloaded variants with a {@link DefRef} argument instead of the definition
 * string.
 * <ul>
 * <li>An absolute definition path is for example: <code>"/MICROSAR/Com/ComGeneral/ComVersionInfoApi"</code></li>
 * <li>A relative definition path is for example: <code>"ComGeneral/ComVersionInfoApi"</code> (as child object of the <code>Com</code> module configuration) or just
 * <code>ComVersionInfoApi</code> (as child object of the <code>ComGeneral</code> container)</li>
 * </ul>
 *
 *
 * <h3>Parameter value handling</h3>
 *
 * The following methods provide access to integer parameters:
 * <ul>
 * <li>{@link #containsInteger(MINumericalValue)}: Checks if the specified parameter really contains an integer value. That's useful since the ARXML file may contain any string
 * in the VALUE tag of a parameter</li>
 * <li>{@link #getAsInteger(MINumericalValue)}</li>
 * <li>{@link #setAsInteger(MINumericalValue,BigInteger)}</li>
 * </ul>
 * Similar methods exist for boolean, float and string parameter types.
 * <h3>Object links</h3>
 *
 * An object link is a string which identifies a model object as good as possible. The object link can be used in reports or log entries. It <b>cannot be used reliably to
 * retrieve model objects</b> because they are ambiguous under specific circumstances.
 *
 * The most simple case of an object link is the AUTOSAR path of an {@link MIReferrable} object.
 * <p>
 * This is, for example, the object link of a container in the ECUC: <br>
 * <code>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject</code> For being able to provide meaningful object links for parameters also, the AUTOSAR path of their parent container
 * gets a postfix which specifies the parameter instance. This postfix is a combination of the parameters definition shortname and the positional index in the list of parameters
 * with the same definition below their parent container: <br>
 * <code>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]</code>
 * </p>
 * <p>
 * The object link of an object can be retrieved with {@link AsrObjectLink}
 *
 * </div>
 * <h3>For Adaptive AUTOSAR</h3> <div class="extdoc" id="CommonForAdaptive">
 * <h3>Object links</h3>
 *
 * An object link is a string which identifies a model object as good as possible. The object link can be used in reports or log entries. It <b>cannot be used reliably to
 * retrieve model objects</b> because they are ambiguous under specific circumstances.
 *
 * The most simple case of an object link is the AUTOSAR path of an {@link MIReferrable} object.
 * <p>
 * This is, for example, the object link of an implementation data type: <br>
 * <code>/DataTypes/MyDataType</code>. For being able to provide meaningful object links for non-referrables also, the AUTOSAR path of their parent element gets a postfix which
 * specifies the element. This postfix is a combination of the feature name and the positional index in the list of elements under the same feature below their parent element:
 * <br>
 * <code>/DataTypes/MyDataType/@adminData/@docRevision[2]</code>
 * </p>
 * The object link of an object can be retrieved with {@link AsrObjectLink}
 *
 * </div>
 *
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IModelAccess {

    /**
     * This constant value is being used within the model and persistency components to represent unlimited integer values (e.g. for upper multiplicity "*"). The value is (2^64
     * + Long.MAX_VALUE) guarantees the following behavior:
     * <ul>
     * <li>It is larger than any integer value valid for AUTOSAR.
     * <li>If someone tries to convert this value to a native long the result will be Long.MAX_VALUE which can expected to be sufficient for all practical cases like large
     * upper-multiplicity values
     * </ul>
     *
     */
    @PublishedField
    int NUMBER_OF_BITS_IN_A_LONG = 64;

    @PublishedField
    BigInteger UNLIMITED_INTEGER = BigInteger.valueOf(2).pow(NUMBER_OF_BITS_IN_A_LONG).add(BigInteger.valueOf(Long.MAX_VALUE));

    /**
     * Returns the root object of the AUTOSAR model.
     *
     * @return MDF root object
     */
    @PublishedMethod
    MIAUTOSAR getAutosarRoot();

    /**
     * Returns the model info object.
     *
     * @return
     */
    @PublishedMethod
    MIModelInfo getModelInfo();

    /**
     * Returns the AUTOSAR schema version of the active ECUC file (the file which contains the active ecuc object of type {@link MIEcuConfiguration}). Never returns
     * <code>null</code>.
     *
     * @return
     * @throws IllegalStateException if the schema version could not be found. This can only happen if no active ecuc object could be found or if this object is not mapped to a
     * file
     */
    @PublishedMethod
    IVersion getActiveEcucSchemaVersion();

    /**
     * Returns the root package of the InitialEcuC.
     *
     * @return
     */
    @PublishedMethod
    MIARPackage getInitialEcucPackage();

    /**
     * Checks if the specified object is contained in the AUTOSAR model tree.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return <code>true</code> if the object or one of its parents is the AUTOSAR root object. <code>false</code> if the object is not part of the model tree
     */
    @PublishedMethod
    boolean isMemberOfModelTree(MIObject obj);

    /**
     * Checks if the specified object is contained in the MDF model tree root.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects.
     * </p>
     *
     * <p>
     * Note: this method will return <code>false</code>, if obj is <code>null</code>.
     * </p>
     * <p>
     * Note: The additional condition will not be applied to the model root itself.
     * </p>
     *
     * @param obj The model object to check.
     * @param additionalCondition An additional condition which has to be fulfilled additionally for each traversed object (except model root).
     * @return <code>true</code> if the object or one of its parents is the model root object. <code>false</code> if the object is not part of the model tree.
     */
    @KeepSecretFromPublishedApi
    boolean isMemberOfModelTree(MIObject obj, Predicate<MIObject> additionalCondition);

    /**
     * Returns <code>true</code> if the specified object is contained in the InitialEcuC.
     *
     * <h1>Example</h1>
     * <ul>
     * <li>/InitialEcuC/Can/CanGeneral is in the InitialEcuC
     * <li>/ActiveEcuC/Can/CanGeneral is not
     * </ul>
     *
     * Use <code>ICeStatePublished.hasInitialValue()</code> to check if an active Object has a initial ECUC value.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    boolean isContainedInInitialEcuc(MIObject obj);

    /**
     * Returns <code>true</code> if the passing object is an ecuc member. <br>
     * <br>
     * Walks up the tree until the object is of type:
     * <ul>
     * <li>{@link MIModuleConfiguration}</li>
     * <li>{@link MIContainer}</li>
     * <li>{@link MIModuleDef}</li>
     * <li>{@link MIEcuConfiguration}</li>
     * <li>{@link MIEcucDefinitionCollection}</li>
     * </ul>
     * <br>
     * Returns <code>false</code> for {@link MIARPackage}.<br>
     * <br>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    boolean isMemberOfEcuc(MIObject obj);

    /**
     * Returns <code>true</code> if the passing object is member of the ActiveEcuC.
     * <p>
     * Utilizes {@link #isMemberOfEcuc(MIObject)} but checks if ecuc object is actually referenced by the ActiveEcuC <br>
     * Returns <code>false</code> for {@link MIARPackage}.<br>
     * <br>
     *
     * @param obj The object to check.
     * @return true if the object is member of the ActiveEcuC.
     */
    @PublishedMethod
    boolean isMemberOfActiveEcuc(MIObject obj);

    /**
     * Returns the module configuration the specified object is contained in.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj is the ECUC object, the module configuration is being requested for
     * @return Module configuration or <code>null</code> if not found or the specified object itself is <code>null</code>
     */
    @PublishedMethod
    MIModuleConfiguration getModuleConfiguration(MIObject obj);

    /**
     * Returns the module definition of the specified object.
     * <p>
     * There are two cases supported:
     * <ol>
     * <li>If the object is a configuration object (module config, container or parameter), the related module definition is returned.
     * <li>If the object is a definition object the related module definition it is contained in is returned.
     * </ol>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return Module definition or <code>null</code> if not found.
     */
    @PublishedMethod
    MIModuleDef getModuleDefinition(MIObject obj);

    /**
     * Returns <code>true</code> if the specified module definition path is a refinement of the specified refined definition path.
     * <p>
     * <h1>Example</h1>
     * <ul>
     * <li>The module definition path <code>/MICROSAR/Can_CanoeemuCanoe/Can</code> is a refinement of <code>/AUTOSAR/Can</code>
     * <li>The module definition path <code>/AUTOSAR/Can</code> is also a refinement of <code>/AUTOSAR/Can</code>
     * <li>The module definition path <code>/MICROSAR/Dem</code> is <b>not</b> a refinement of <code>/AUTOSAR/Can</code>
     * </ul>
     *
     * @param moduleDefPath
     * @return
     * @throws IllegalStateException if the refinement cannot be analyzed (e.g. because the module definition object is missing)
     */
    @PublishedMethod
    boolean isRefinedModuleDefinition(String moduleDefPath, String refinedDefPath);

    /**
     * Overloaded version of {@link IModelAccess#isRefinedModuleDefinition(String, String)}.
     *
     * Usually wildcards used in DefRef objects on match on string basis and don't investigate refinements. In contrast to this behavior this method allows checking with
     * wildcards too. This means that checking a MICROSAR definition path against an AUTOSAR-wildcard based DefRef here returns <code>true</code>.
     *
     * @param moduleDefPath
     * @param refinedDefRef
     * @return
     */
    @PublishedMethod
    boolean isRefinedModuleDefinition(String moduleDefPath, DefRef refinedDefRef);

    /**
     * Returns <code>true</code> if the specified objects definition matches the specified definition.
     *
     * This method also supports refinements, so an AUTOSAR definition also matches refined MIRCOSAR objects.
     *
     * Concerning the specified definition two cases are supported:
     * <ol>
     * <li>Absolute definition path: In this case the complete definition is matched and module refinements are supported
     * <li>Relative definition path: In this case the definition is assumed to be the last short name of the specified objects definition. Nothing else is checked.
     * </ol>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param hasDef
     * @param definition
     * @return
     */
    @PublishedMethod
    boolean matchesDefinition(MIHasDefinition hasDef, String definition);

    /**
     * Returns <code>true</code> if the specified objects definition matches the specified defRef.
     *
     * This method also supports refinements, so a defRef containing an AUTOSAR definition also matches refined MIRCOSAR objects. <b>Be aware</b> that ad defRef containing an
     * AUTOSAR-wildcard doesn't match MIRCOSAR definitions because the wildcard semantic doesn't support refinement checks!
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param hasDef
     * @param defRef
     * @return
     */
    @PublishedMethod
    boolean matchesDefinition(MIHasDefinition hasDef, DefRef defRef);

    /**
     * Returns the refined definition path of the specified object. This means in detail: If the specified object is a configuration object e.g. with a <code>/MICROSAR</code>
     * definition you'll get the related definition path within the refined AUTOSAR standard definition.
     * <p>
     * <h1>Example</h1> If the object has the definition <code>/MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral</code> the method returns <code>/AUTOSAR/Can/CanGeneral</code>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return The refined definition path or <code>null</code> if no refinement exists
     */
    @PublishedMethod
    String getRefinedDefinition(MIHasDefinition obj);

    /**
     * Returns the refined definition path of the specified def ref in one exists. This means in detail: If the specified def ref represents a definition e.g.
     * <code>/MICROSAR</code> definition you'll get the related definition path within the refined AUTOSAR standard definition.
     * <p>
     * <h1>Example</h1> If the def ref represents the definition <code>/MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral</code> the method returns a def ref representing
     * <code>/AUTOSAR/Can/CanGeneral</code>
     *
     *
     * @param defRef The DefRef
     * @return An optional containing the refined defref or {@link java.util.Optional#EMPTY} if no refinement exists.
     */
    @KeepSecretFromPublishedApi
    Optional<DefRef> getRefinedDefinition(DefRef defRef);

    /**
     * This method searches for all objects with the specified definition path within the active module configurations. This definition path may also use a refined module
     * definition path. The method investigates all refinements to find matching definitions in the active configurations.
     * <p>
     * <b>Example:</b> If the specified definition path is and AUTOSAR standard definition, it will also find objects within refined modules. So
     * <code>"/AUTOSAR/Can/CanGeneral"</code> will also find objects with definition <code>"/MICROSAR/Can/CanGeneral"</code>.
     * <p>
     * If the specified definition path is a relative path, it must start with a module definitions base short-name. Nevertheless this method also finds differing module
     * definition names of refined module definitions.
     * <ul>
     * <li><code>"Can/CanGeneral"</code> will find objects with definition <code>"/MICROSAR/Can/CanGeneral"</code> but <code>"CanGeneral"</code> will find nothing!
     * <li><code>"/AUTOSAR/Can"</code> or simply <code>"Can"</code> will find all active Can module configurations
     * </ul>
     * <p>
     * <b>Remark:</b> If the returned child objects are immediate children of the specified parent, their order is the same as in the MDF model.
     *
     * @param definitionPath is an absolute or relative AUTOSAR definition path
     * @return
     */
    @PublishedMethod
    List<MIHasDefinition> getAllWithDefinition(String definitionPath);

    /**
     * Overloaded version of {@link IModelAccess#getAllWithDefinition(String)}.
     *
     * @param defRef the definition to retrieve configuration elements from
     * @return
     */
    @PublishedMethod
    List<MIHasDefinition> getAllWithDefinition(DefRef defref);

    /**
     * Typesafe variant of {@link IModelAccess#getAllWithDefinition(DefRef)}.
     *
     * @param defRef the definition to retrieve configuration elements from
     * @return all elements of the given {@code defRef}
     */
    @PublishedMethod
    <T extends MIHasDefinition> List<T> getAllWithTypedDefinition(TypedDefRef<?, T, ?> defRef);

    /**
     * Returns all MDF instances of the specified type.
     *
     * <p>
     * Please use <code>getAllModuleDefinitions()}.values()</code> instead of <code>getAllInstancesOfType(MIModuleDef.class)</code> for performance reasons!
     * </p>
     *
     * <p>
     * Be aware that retrieving object instances this way is only fast for a small number of expected instances. If you expect a large number of objects and/or large inheritance
     * trees of the specified type (e.g. retrieving all instances of MIARRef) it is probably much faster traversing the complete model tree. The point here is that this method
     * internally builds a set of instances and adds all sets of instances of the derived types. All together means handling a huge amount of hash-sets. <br/>
     * <b>SO - USE THIS METHOD CAREFULLY!</b>
     * <p>
     *
     * @param type to search for.
     * @return {@link Collection} of found elements.
     */
    @PublishedMethod
    <T extends MIObject> Collection<T> getAllInstancesOfType(Class<T> type);

    /**
     * Returns the MDF type which is allowed as type of referenced objects as defined in the specified foreign reference definition. If no such type could be found, this method
     * returns <code>null</code>.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param definition
     * @return
     * @deprecated Use {@link IEcucForeignRefDefinition} provided by the {@link IEcucDefinitionAccess} service
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    Class<? extends MIObject> getDestinationTypeForForeignReference(MIForeignReferenceParamDef definition);

    /**
     * Returns the MDF type which is allowed as type references with the given destination type. If no such type could be found, this method returns <code>null</code>.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param destinationType
     * @return
     * @deprecated Use {@link IEcucForeignRefDefinition} provided by the {@link IEcucDefinitionAccess} service
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    Class<? extends MIObject> getDestinationTypeForReferenceDestinationTypeString(String destinationType);

    /**
     * This method returns the definition path of the object without the leading package structure. The referenced definition object doesn't need to exist because this method
     * only deals with definition string handling.
     * <p>
     * <h1>Example</h1> For an object with definition path <code>/AUTOSAR/Os/OsOS/OsStatus</code> the method will return <code>Os/OsOS/OsStatus</code>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return The relative definition path or <code>null</code> if it couldn't be retrieved.
     */
    @PublishedMethod
    String getRelativeDefinitionPath(MIHasDefinition obj);

    /**
     * This method returns the AUTOSAR path of the specified object without the leading package structure.
     * <p>
     * <h1>Example</h1>
     * <ul>
     * <li>For an object with AUTOSAR path <code>/ActiveEcuC/Com/Something</code> the method will return <code>Com/Something</code>
     * <li>For an object with AUTOSAR path <code>/MICROSAR/Com/ComGeneral</code> the method will return <code>Com/ComGeneral</code>
     * </ul>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return The relative path or <code>null</code> if it couldn't be retrieved.
     */
    @PublishedMethod
    String getRelativeAutosarPath(MIReferrable obj);

    /**
     * Returns the parent object in the model tree or <code>null</code> if ...
     * <ul>
     * <li>The object has no parent
     * <li>The object is the AUTOSAR root object
     * <li>The object is removed
     * </ul>
     *
     * @param obj is the object the parent is being requested for
     * @return
     */
    @PublishedMethod
    MIObject getImmediateParent(MIObject obj);

    /**
     * Returns a string which is being created by {@link AsrObjectLink#getObjectLinkString()}.
     *
     * @param modelObject
     * @return Object link
     * @deprecated Use {@link AsrObjectLink} instead
     */
    @PublishedMethod
    @Deprecated
    String getObjectLink(MIObject modelObject);

    /**
     * Returns a string which is being created by {@link AsrObjectLink#getShortObjectLinkString()}.
     *
     * @param modelObject
     * @return Object link
     * @deprecated Use {@link AsrObjectLink} instead
     */
    @Deprecated
    @PublishedMethod
    String getShortObjectLink(MIObject modelObject);

    /**
     * Retrieves a model object using {@link AsrObjectLink#getAutosarObject()}. If more than one object have been found, the first one is returned.
     *
     * @return The model object or <code>null</code> if not found
     * @deprecated Use {@link AsrObjectLink} instead
     */
    @Deprecated
    @PublishedMethod
    MIObject getObjectByLink(String objectLink);

    /**
     * Retrieves the first found child object (container or parameter) below the specified parent which has the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find objects
     * below a module configuration with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found container or <code>null</code> if not found
     * @throws IllegalArgumentException if arguments are <code>null</code>
     */
    @PublishedMethod
    MIHasDefinition getChildByDefinition(MIHasContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getChildByDefinition(MIHasContainer, String)}.
     *
     * @param parent
     * @param defRef
     * @return
     */
    @PublishedMethod
    MIHasDefinition getChildByDefinition(MIHasContainer parent, DefRef defRef);

    /**
     * Retrieves all child objects (containers or parameters) below the specified parent which have the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find objects
     * below a module configuration with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     * <p>
     * <b>Remark:</b> If the returned child objects are immediate children of the specified parent, their order is the same as in the MDF model.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found objects or an empty list if there are none available
     * @throws IllegalArgumentException if arguments are <code>null</code>
     */
    @PublishedMethod
    List<MIHasDefinition> getChildrenByDefinition(MIHasContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getChildrenByDefinition(MIHasContainer, String)}.
     *
     * @param parent
     * @param defRef
     * @return
     */
    @PublishedMethod
    List<MIHasDefinition> getChildrenByDefinition(MIHasContainer parent, DefRef defRef);

    /**
     * Retrieves the first found child container below the specified parent which has the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find objects
     * below a module configuration with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found container or <code>null</code> if not found
     * @throws IllegalArgumentException if arguments are <code>null</code>
     * @throws UnexpectedTypeException if the found object is not a container
     */
    @PublishedMethod
    MIContainer getContainerByDefinition(MIHasContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getContainerByDefinition(MIHasContainer, String)}.
     *
     * @param parent
     * @param definition
     * @return
     */
    @PublishedMethod
    MIContainer getContainerByDefinition(MIHasContainer parent, DefRef definition);

    /**
     * Retrieves all child containers below the specified parent which have the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find objects
     * below a module configuration with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     * <p>
     * <b>Remark:</b> If the returned child objects are immediate children of the specified parent, their order is the same as in the MDF model.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found containers or an empty list if there are none available
     * @throws IllegalArgumentException if arguments are <code>null</code>
     * @throws UnexpectedTypeException if one of the found objects is not a container
     */
    @PublishedMethod
    List<MIContainer> getContainersByDefinition(MIHasContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getContainersByDefinition(MIHasContainer, String)}.
     *
     * @param parent
     * @param definition
     * @return
     */
    @PublishedMethod
    List<MIContainer> getContainersByDefinition(MIHasContainer parent, DefRef definition);

    /**
     * Walks up the root path until a parent object with the specified definition is found. Otherwise this method returns <code>null</code>.
     * <p>
     * This method considers refinements. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find parent objects of a child from a a module configuration
     * with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     * </p>
     *
     * @param presumableChild
     * @param definitionOfParent
     * @return
     */
    @PublishedMethod
    MIContainer getParentContainerByDefinition(MIHasDefinition presumableChild, String definitionOfParent);

    /**
     * Walks up the root path until a parent object with the specified definition is found. Otherwise this method returns <code>null</code>.
     * <p>
     * This method considers refinements.
     * </p>
     *
     * @param presumableChild
     * @param definitionOfParent
     * @return
     */
    @PublishedMethod
    MIContainer getParentContainerByDefinition(MIHasDefinition presumableChild, DefRef definitionOfParent);

    /**
     * Walks up the root path until a parent object with the specified definition is found. Otherwise this method returns <code>null</code>.
     * <p>
     * This method considers refinements. This means that definition <code>/AUTOSAR/Can/CanGeneral</code> will also find parent objects of a child from a a module configuration
     * with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can</code>.
     * </p>
     *
     * @param presumableChild
     * @param definitionOfParent
     * @return
     */
    @PublishedMethod
    MIHasContainer getParentByDefinition(MIHasDefinition presumableChild, String definitionOfParent);

    /**
     * Walks up the root path until a parent object with the specified definition is found. Otherwise this method returns <code>null</code>.
     * <p>
     * This method considers refinements.
     * </p>
     *
     * @param presumableChild
     * @param definitionOfParent
     * @return
     */
    @PublishedMethod
    MIHasContainer getParentByDefinition(MIHasDefinition presumableChild, DefRef definitionOfParent);

    /**
     * Retrieves the first found parameter below the specified container which has the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral/CanIndex</code> will also find
     * objects below a container with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral</code>.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found parameter or <code>null</code> if not found
     * @throws IllegalArgumentException if arguments are <code>null</code>
     * @throws UnexpectedTypeException if the found object is not a parameter
     */
    @PublishedMethod
    MIParameterValue getParameterByDefinition(MIContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getParameterByDefinition(MIContainer, String)}.
     *
     * @param parent
     * @param definition
     * @return
     */
    @PublishedMethod
    MIParameterValue getParameterByDefinition(MIContainer parent, DefRef definition);

    /**
     * Retrieves all child parameters below the specified container which have the specified definition.
     * <p>
     * If an absolute definition path is being specified, refinements are also permitted. This means that definition <code>/AUTOSAR/Can/CanGeneral/CanIndex</code> will also find
     * objects below a container with definition <code>/MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral</code>.
     * <p>
     * <b>Remark:</b> If the returned child objects are immediate children of the specified parent, their order is the same as in the MDF model.
     *
     * @param parent
     * @param definition is an absolute AUTOSAR definition path or a relative path below the parents definition
     * @return Found parameters or an empty list if there are none available
     * @throws IllegalArgumentException if arguments are <code>null</code>
     * @throws UnexpectedTypeException if one of the found objects is not a parameter
     */
    @PublishedMethod
    List<MIParameterValue> getParametersByDefinition(MIContainer parent, String definition);

    /**
     * Overloaded version of {@link IModelAccess#getParametersByDefinition(MIContainer, String)}.
     *
     * @param parent
     * @param definition
     * @return
     */
    @PublishedMethod
    List<MIParameterValue> getParametersByDefinition(MIContainer parent, DefRef definition);

    /**
     * This method checks if a child object with the specified definition can be created. There are several possible reasons why this may not be the case:
     * <ul>
     * <li>The CE itself is not changeable (for whatever reason, e.g. because the related file is read-only)
     * <li>The definition doesn't exist below this CE
     * <li>The specified shortname is not valid or already used for a child object of this CE
     * </ul>
     * Be aware that this method doesn't check the multiplicity of child objects. The user shall not be restricted to create even inconsistent model contents as long as we can
     * technically store them and make them persistent. All inconsistencies will later be reported by the consistency component in either case.
     *
     * @param parent is the new childs parent object
     * @param childDefinition AUTOSAR definition ref of the child CE
     * @param shortName shortname of the child. In case of a parameter, this string will be ignored and may be <code>null</code>
     * @param childAlreadyExists is <code>true</code> if this method is called after creation of the child object. In this case the method accepts that the specified shortname
     * already exists
     * @return <code>true</code> if the child is creatable.
     * @deprecated Please use com.vector.cfg.model.state.ICeState.isCreateableChild(String, String, boolean) instead
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    boolean isCreateableChild(MIHasContainer parent, String childDefinition, String shortName, boolean childAlreadyExists);

    /**
     * Overloaded version of {@link IModelAccess#isCreateableChild(MIHasContainer, String, String, boolean)}.
     *
     * @param parent
     * @param childDefRef
     * @param shortName
     * @param childAlreadyExists
     * @return
     * @deprecated Please use com.vector.cfg.model.state.ICeState.isCreateableChild(String, String, boolean) instead
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    boolean isCreateableChild(MIHasContainer parent, DefRef childDefRef, String shortName, boolean childAlreadyExists);

    /**
     * This method returns a textual representation of all reasons why the child object is not creatable.
     *
     * @return
     * @deprecated Please use com.vector.cfg.model.state.ICeState.getNotCreatableChildReasons(String, String, boolean) instead.
     */
    @PublishedMethod
    @Deprecated
    Collection<String> getNotCreatableChildReasons(MIHasContainer parent, String childDefinition, String shortName, boolean childAlreadyExists);

    /**
     * AUTOSAR doesn't define the parameter type in the parameter instance but in its definition. But the definition may not be available (e.g. bswmd file is missing). Even if
     * we had the definition available within the project, the persistency had no access to it during model load because it could be contained in a file which would be loaded
     * later.
     * <p>
     * To support convenient parameter access this method tries to detect the specific parameter type.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param param is a configuration parameter instance
     * @return
     * @throws NullPointerException if the parameter is <code>null</code>
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("May lead to ClassCastException when casting the MIParameterValue according the determined EParameterType in case of changed BSWMD. Remove this method.")
    EParameterType getParameterType(MIParameterValue param);

    /**
     * AUTOSAR doesn't define the parameter type in the parameter instance but in its definition. But the definition may not be available (e.g. bswmd file is missing) or may not
     * match the parameter instance (e.g. SIP update and parameter type changed). Even if we had the definition available within the project, the persistency had no access to it
     * during model load because it could be contained in a file which would be loaded later.
     * <p>
     * To support convenient parameter access this method tries to detect the specific parameter type. <b>It is assured that the given parameter instance may be casted to a
     * specific sub type according to the determined parameter type.</b>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param param is a configuration parameter instance
     * @return
     * @throws NullPointerException if the parameter is <code>null</code>
     */
    @PublishedFilter(MsrPlatform.class)
    @PublishedMethod
    EParameterType getParameterTypeSafe(MIParameterValue param);

    /**
     * Translates the parameter definition into a parameter type.
     *
     * @param paramDefinition is a configuration parameter definition
     * @return
     * @throws NullPointerException if the paramDefinition is <code>null</code>
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    EParameterType getParameterType(MIConfigParameter paramDefinition);

    /**
     * returns the number of possible additional configuration entities of the given type in it's context.
     *
     * @param parent parent of the CE
     * @param definition definition of the CE
     * @return max number of additional entities
     */
    @PublishedMethod
    long getMaxAdditionalCECount(MIHasContainer parent, MIReferrable definition);

    /**
     * Returns <code>true</code> if the specified objects definition has the right type. Returns <code>false</code> if the object is <code>null</code> or doesn't have a
     * definition.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param hasDef
     * @return
     */
    @PublishedMethod
    boolean hasCorrectDefinitionType(MIHasDefinition hasDef);

    /**
     * Returns <code>true</code> if the specified parameters definition has the right type. Returns <code>false</code> if the parameter is <code>null</code> or doesn't have a
     * definition.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param param is the parameter to be checked
     * @return
     */
    @PublishedMethod
    boolean hasCorrectParamDefinitionType(MIParameterValue param);

    /**
     * Checks whether the parameter has a value instance. If the argument is <code>null</code> this method returns <code>false</code>.
     *
     * @param parameterValue is the parameter to be checked
     * @return
     */
    @PublishedMethod
    boolean hasValue(MIParameterValue parameterValue);

    /**
     * Checks if the specified parameters value is consistent with its type as specified in its definition. If e.g. the parameters definition specifies the type as an integer
     * this method checks if it really <b>contains</b> an integer.
     * <p>
     * You can use this function before reading a numeric value to check if the parameter has a definition and the value matches the definition. Calling the related get-method
     * afterwards will never lead to an error if this method returned <code>true</code>.
     *
     * Special cases:
     * <ul>
     * <li>If the parameter contains no value (the value string is <code>null</code> or empty), this method returns <code>false</code>
     * <li>If the definition reference cannot be resolved, this method returns <code>false</code>
     * </ul>
     * In all other cases it returns <code>true</code> if the value matches its definition and <code>false</code> else.
     *
     * @param param is an AUTOSAR numerical parameter
     * @return
     */
    @PublishedMethod
    boolean isConsistentWithDefType(MINumericalValue param);

    /**
     * Checks if the specified parameter is consistent with the specified type according to its definition. If the definition is not available, <code>false</code> is returned.
     *
     * @param expectedType
     * @return
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("May return true if parameter has expected definition, but is itself of wrong instance type (e.g. MINumericValue but StringDefinition).")
    boolean isConsistentWithDefType(MIParameterValue param, EParameterType expectedType);

    /**
     * Convenience method to check if a numeric values content string is a boolean value.
     *
     * Be aware that this method only checks the <b>real content</b> of the parameter and <b>not</b> its definition type!
     *
     * @param param is an AUTOSAR numerical parameter
     * @return <code>true</code> if the value string is a boolean value and <code>false</code> else
     */
    @PublishedMethod
    boolean containsBoolean(MINumericalValue param);

    /**
     * Convenience method to check if a numeric values content string is an integer value.
     *
     * Be aware that this method only checks the <b>real content</b> of the parameter and <b>not</b> its definition type!
     *
     * @param param is an AUTOSAR numerical parameter
     * @return <code>true</code> if the value string is an integer value and <code>false</code> else
     */
    @PublishedMethod
    boolean containsInteger(MINumericalValue param);

    /**
     * Convenience method to check if a numeric values content string is a float value.
     *
     * Be aware that this method only checks the <b>real content</b> of the parameter and <b>not</b> its definition type!
     *
     * @param param is an AUTOSAR numerical parameter
     * @return <code>true</code> if the value string is a float value and <code>false</code> else
     */
    @PublishedMethod
    boolean containsFloat(MINumericalValue param);

    /**
     * Convenience method to check if a textual values content string is available.
     *
     * Be aware that this method only checks the <b>real content</b> of the parameter and <b>not</b> its definition type!
     *
     * @param param is an AUTOSAR textual parameter
     * @return <code>true</code> if the value string is available (even if empty) and <code>false</code> else
     */
    @PublishedMethod
    boolean containsString(MITextualValue param);

    /**
     * Convenience method to get a numeric values content string as boolean value.
     *
     * @param param is an AUTOSAR numerical parameter
     * @return The boolean value (never <code>null</code>)
     * @throws NumberFormatException if the parameters value string doesn't represent a boolean value
     */
    @PublishedMethod
    Boolean getAsBoolean(MINumericalValue param);

    /**
     * Convenience method to get a numeric values content string as integer value.
     *
     * @param param is an AUTOSAR numerical parameter
     * @return The integer value (never <code>null</code>)
     * @throws NumberFormatException if the parameters value string doesn't represent an integer value
     */
    @PublishedMethod
    BigInteger getAsInteger(MINumericalValue param);

    /**
     * Convenience method to get a numeric values content string as float value.
     *
     * @param param is an AUTOSAR numerical parameter
     * @return The float value (never <code>null</code>)
     * @throws NumberFormatException if the parameters value string doesn't represent a float value
     */
    @PublishedMethod
    MBigDecimal getAsFloat(MINumericalValue param);

    /**
     * Convenience method to get a numeric values content string.
     *
     * @deprecated This method gets the internal value string without any checks. The type safe variants for getting a numerical value shall therefore be preferred!
     *
     * @param param is an AUTOSAR textual parameter
     * @return The string value or <code>null</code> if not available
     */
    @Deprecated
    @PublishedMethod
    String getValueString(MINumericalValue param);

    /**
     * Convenience method to get a textual values content string.
     *
     * @param param is an AUTOSAR textual parameter
     * @return The string value (never <code>null</code>)
     * @throws NullPointerException if the parameters value string is not available
     */
    @PublishedMethod
    String getAsString(MITextualValue param);

    /**
     * Convenience method to set a numeric values content string as boolean value.
     *
     * This method checks if the specified parameters definition object is available and sets the value only if its definition type is boolean. If the parameter has no
     * definition the parameter is set in either case.
     *
     * @param param is an AUTOSAR numerical parameter
     * @param newValue
     */
    @PublishedMethod
    void setAsBoolean(MINumericalValue param, Boolean newValue);

    /**
     * Convenience method to set a numeric values content string as integer value.
     *
     * This method checks if the specified parameters definition object is available and sets the value only if its definition type is integer. If the parameter has no
     * definition the parameter is set in either case.
     *
     * @param param is an AUTOSAR numerical parameter
     * @param newValue
     */
    @PublishedMethod
    void setAsInteger(MINumericalValue param, BigInteger newValue);

    /**
     * Overloaded variant of {@link IModelAccess#setAsInteger(MINumericalValue, BigInteger)}.
     *
     * Be aware that this method can be called with int and byte parameters too. Java will implicitly convert to long.
     *
     * @param param
     * @param newValue
     */
    @PublishedMethod
    void setAsInteger(MINumericalValue param, long newValue);

    /**
     * Convenience method to set a numeric values content string as float value.
     *
     * This method checks if the specified parameters definition object is available and sets the value only if its definition type is float. If the parameter has no definition
     * the parameter is set in either case.
     *
     * @param param is an AUTOSAR numerical parameter
     */
    @PublishedMethod
    void setAsFloat(MINumericalValue param, BigDecimal newValue);

    /**
     * Overloaded variant of {@link IModelAccess#setAsFloat(MINumericalValue, BigDecimal)}.
     *
     * Be aware that this method can be called with float parameters too. Java will implicitly convert to double.
     *
     * @param param
     * @param newValue
     */
    @PublishedMethod
    void setAsFloat(MINumericalValue param, double newValue);

    /**
     * Convenience method to set a numeric values content string.
     *
     * @deprecated This method sets the internal value string without any checks. The type safe variants for setting a numerical value shall therefore be preferred!
     *
     * @param param is an AUTOSAR textual parameter
     * @param newValue
     */
    @Deprecated
    @PublishedMethod
    void setValueString(MINumericalValue param, String newValue);

    /**
     * Sets the value (newValue) of the passed parameter (parameterToSet). The method is fully typesafe and checked.
     *
     * <p>
     * <b>Attention:</b> {@link EParameterType#INSTANCE_REFERENCE InstancesReferences} are currently <b>NOT</b> supported! <br>
     * <b>Attention:</b> {@link EParameterType#ADD_INFO AddInfo} are currently <b>NOT</b> supported!
     * </p>
     *
     * @param <DEF> the generic type
     * @param <CFG> the generic type
     * @param <VAL> the generic type
     * @param defRef the {@link DefRef} of the parameterToSet. This DefRef is used for type checks!
     * @param parameterToSet the {@link MIParameterValue} which shall be used to set the new value.
     * @param newValue the new value of the Parameter
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * <li>if the parameterToSet parameter is null</li>
     * <li>if the newValue parameter is null, and the requested destination type is no String Type.</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef parameter is not the definition of the passed parameterToSet.</li>
     * <li>if the type of the passed parameter is not compatible with the passed newValue.</li>
     * </ul>
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VAL> void setParameterValue(TypedDefRef<DEF, CFG, VAL> defRef, CFG parameterToSet, VAL newValue);

    /**
     * Gets the value (newValue) of the passed parameter (parameterToSet). The method is fully typesafe and checked.
     *
     * <p>
     * <b>Attention:</b> {@link EParameterType#INSTANCE_REFERENCE InstancesReferences} are currently <b>NOT</b> supported! <br>
     * <b>Attention:</b> {@link EParameterType#ADD_INFO AddInfo} are currently <b>NOT</b> supported!
     * </p>
     *
     * @param defRef the {@link DefRef} of the parameterToSet. This DefRef is used for type checks!
     * @param parameterToGet the {@link MIParameterValue} which shall be used to set the new value.
     * @return the parameter value
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * <li>if the parameterToSet parameter is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef parameter is not the definition of the passed parameterToSet.</li>
     * <li>if the type of the passed parameter is not compatible with the passed newValue.</li>
     * </ul>
     */
    @PublishedMethod
    <DEFINITION_TYPE extends MIConfigParameter, CFG_TYPE extends MIParameterValue, VALUE_TYPE> VALUE_TYPE getParameterValue(
            TypedDefRef<DEFINITION_TYPE, CFG_TYPE, VALUE_TYPE> defRef, CFG_TYPE parameterToGet);

    /**
     * Convenience method to set a textual values content string.
     *
     * This method checks if the specified parameters definition object is available and sets the value only if its definition type is a textual value type. If the parameter has
     * no definition the parameter is set in either case.
     *
     * @param param is an AUTOSAR textual parameter
     * @param newValue
     */
    @PublishedMethod
    void setAsString(MITextualValue param, String newValue);

    /**
     * Sets the specified target object as reference target of the specified reference parameter.
     *
     * If the target is <code>null</code>, the complete reference parameter is being removed from the model.
     *
     * @param referenceValue
     * @param referenceTarget
     */
    @PublishedMethod
    void setReferenceValue(MIReferenceValue referenceValue, MIReferrable referenceTarget);

    /**
     * Sets the specified reference target path as value of the specified reference parameter.
     *
     * If the path is <code>null</code>, the complete reference parameter is being removed from the model.
     *
     * @param referenceValue
     * @param referenceTargetPath fully qualified AUTOSAR path of the reference target
     */
    @PublishedMethod
    void setReferenceValueString(MIReferenceValue referenceValue, String referenceTargetPath);

    /**
     * Sets the specified reference target path and context paths as value of the specified instance reference parameter.
     *
     * If the target path is <code>null</code>, the complete instance reference parameter is being removed from the model.
     *
     * @param referenceValue
     * @param referenceTargetPath fully qualified AUTOSAR path of the reference target
     * @param contextPaths optional context paths. May be null or empty
     */
    @PublishedMethod
    void setInstanceReferenceValueString(MIInstanceReferenceValue referenceValue, String referenceTargetPath, List<String> contextPaths);

    /**
     * Returns the default multi-language long-name of the specified object based on the following rules (in this order).
     * <ul>
     * <li>If only one variant is stored in the node it is returned
     * <li>If a variant with language 'FOR-ALL' (L-attribute) is stored in the node it is returned
     * <li>Otherwise the variant with language 'EN' (L-attribute) is returned
     * <li>If none of the above applies, the first variant is returned
     * </ul>
     *
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    String getLongName(MIIdentifiable obj);

    /**
     * Returns the default multi-language description of the specified object based on the following rules (in this order).
     * <ul>
     * <li>If only one variant is stored in the node it is returned
     * <li>If a variant with language 'FOR-ALL' (L-attribute) is stored in the node it is returned
     * <li>Otherwise the variant with language 'EN' (L-attribute) is returned
     * <li>If none of the above applies, the first variant is returned
     * </ul>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    String getDescription(MIIdentifiable obj);

    /**
     * Sets the running thread read-only. Subsequent MDF model modifications will throw exceptions. Setting a thread read-only e.g. makes sense for background validation
     * threads.
     * <p>
     * Use this feature carefully and be aware that a thread cannot be set to read-write mode afterwards.
     */
    @KeepSecretFromPublishedApi
    void setThreadReadOnly();

    /**
     * Returns all AUTOSAR standard definitions.
     *
     * @return
     */
    @PublishedMethod
    Collection<MIModuleDef> getAllStandardDefinitions();

    /**
     * Returns all loaded {@link MIModuleDef} module definitions in the current Project.
     *
     * @return The keys are the {@link MIModuleDef} objects; the values are the Definitions as DefRef.
     */
    @PublishedMethod
    Map<MIModuleDef, DefRef> getAllModuleDefinitions();

    /**
     * Returns all BSW-implementations.
     *
     * @return
     */
    @PublishedMethod
    Collection<MIBswImplementation> getAllBswImplementations();

    /**
     * Checks if at least one of the unambiguously refined AUTOSAR standard definitions has already been replaced by its refining BSW implementation. (see
     * {@link IModelOperationsPublished#replaceUnambiguouslyRefinedAutosarDefinitionsOld()}).
     *
     * @return
     */
    @PublishedMethod
    boolean unambiguouslyRefinedAutosarDefinitionsReplaced();

    /**
     * Returns all standard AUTOSAR definition paths which have more than one refining bsw-implementation.
     *
     * @return
     */
    @PublishedMethod
    Collection<String> getAmbiguouslyRefinedAutosarDefinitions();

    /**
     * Returns all BSW-implementations which refine the specified module definition.
     *
     * @param absoluteModuleDefinition
     * @return
     */
    @PublishedMethod
    Collection<MIBswImplementation> getRefiningImplementations(String absoluteModuleDefinition);

    /**
     * Returns all module definitions, which refine the specified module definition.
     *
     * @param absoluteModuleDefinition
     * @return
     */
    @PublishedMethod
    Collection<String> getRefiningModuleDefinitions(String absoluteModuleDefinition);

    /**
     * Returns all active module configurations which have no BSW-implementation referenced.
     *
     * @return
     */
    @PublishedMethod
    Collection<MIModuleConfiguration> getModuleConfigurationsWithoutBswImplementation();

    /**
     * Returns all BSW-implementations which match the specified modules definition path.
     *
     * @param moduleConfiguration
     * @return
     */
    @PublishedMethod
    Collection<MIBswImplementation> getMatchingBswImplementations(MIModuleConfiguration moduleConfiguration);

    /**
     * Returns the corresponding symbolic name parameter value (MIParameterValue) of the container. If there is no parameter, which is the symbolic name parameter, null is
     * returned.
     *
     * @param container the parent container
     * @return the symbolic name parameter value
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the container is null</li>
     * </ul>
     */
    @PublishedMethod
    MIParameterValue getSymbolicNameParameter(MIContainer container);

    /**
     * The Methods allow callables to access the mdf meta layer and ensures synchronization. Reason is unsynchronized HashMap MDFOutermostPackageImpl._metaObjects.
     *
     * @param callable
     * @return
     * @throws Exception
     */
    @KeepSecretFromPublishedApi
    <T> T runMetaObjectAccessLocked(Callable<T> callable) throws Exception;

    /**
     * returns the version or null if not accessible.
     *
     * @param moduleConfiguration
     * @return
     */
    @PublishedMethod
    IVersion getVectorBswmdVersion(MIModuleConfiguration moduleConfiguration);

    /**
     * returns the version or null if not accessible.
     *
     * @param moduleDef
     * @return
     */
    @PublishedMethod
    IVersion getVectorBswmdVersion(MIModuleDef moduleDef);

    @KeepSecretFromPublishedApi
    MIMDFRootArtefact getModelRoot();

}
