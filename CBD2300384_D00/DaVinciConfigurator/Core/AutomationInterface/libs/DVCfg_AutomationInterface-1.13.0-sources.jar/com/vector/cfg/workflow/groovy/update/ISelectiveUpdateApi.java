package com.vector.cfg.workflow.groovy.update;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface ISelectiveUpdateApi {

    /**
     * <div class="extdoc" id="includeSWC"> Use {@link #includeSWC(boolean)} to include all SWC's.</div>
     *
     *
     * @param value the value
     */
    @PublishedMethod
    void includeSWC(boolean value);

    /**
     * <div class="extdoc" id="includeLegacyDiagnosticData"> Use {@link #includeLegacyDiagnosticData(boolean)} to include all legacy diagnostic date.</div>
     *
     * @param value
     */
    @PublishedMethod
    void includeLegacyDiagnosticData(boolean value);

    /**
     *
     * <div class="extdoc" id="getAvailableCluster"> Use {@link #getAvailableCluster()} to get a list of AsrPath with all allowed clusters.</div>
     *
     * @returns a list of {@link AsrPath} of the according clusters.
     */
    @PublishedMethod
    List<AsrPath> getAvailableCluster();

    /**
     * <div class="extdoc" id="selectCluster"> Use {@link #selectCluster(AsrPath)} to select one cluster.</div>
     *
     * @param list of {@link AsrPath}
     */
    @PublishedMethod
    void selectCluster(List<AsrPath> cluster);

    /**
     * <div class="extdoc" id="selectClusterSingle"> Use {@link #selectCluster(List)} to select multiple clusters.</div>
     *
     * @param {@link AsrPath}
     */
    @PublishedMethod
    void selectCluster(AsrPath cluster);

}
