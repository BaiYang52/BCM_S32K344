package com.vector.cfg.project.settings.msr.groovy;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <div class="extdoc" id="Common"> The {@link IVectorEmbbededProjectApiEntryPoint} enables querying or modifying the "Vector Embedded Project" project setting. The following
 * section describes how Vector Embedded Projects settings can be accessed and modified. </div> <br>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IVectorEmbbededProjectApiEntryPoint {

    /**
     * <div class="extdoc" id="getEmbeddedProject"><!--Label:IVectorEmbbededProjectApiEntryPoint.getEmbeddedProject--> Use {@link #getEmbeddedProject()} to specify the Embedded
     * Project settings. </div>
     *
     * @param code providing the embedded Vector projects of project settings
     *
     */
    @PublishedMethod
    IVectorEmbeddedProjectApi getEmbeddedProject();

    /**
     * Use {@link #embeddedProject(Closure)} to specify the Embedded Project settings in a scope-like way.
     *
     * @param code code providing the Embedded Vector Projects of settings
     * @see #getEmbeddedProject()
     */
    @PublishedMethod
    <T> T embeddedProject(@VDelegatesToWithClosureParam(IVectorEmbeddedProjectApi.class) Closure<T> code);

}
