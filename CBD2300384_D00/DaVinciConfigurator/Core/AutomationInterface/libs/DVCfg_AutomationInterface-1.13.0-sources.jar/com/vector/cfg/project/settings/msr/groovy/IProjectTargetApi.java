package com.vector.cfg.project.settings.msr.groovy;

import java.util.Collection;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.derivative.DerivativeInfo;
import com.vector.cfg.core.derivative.EImplementationProperties;
import com.vector.cfg.core.derivative.ImplementationProperty;

/**
 *
 * <div class="extdoc" id="Common">{@link IProjectTargetApi} is the entry point for accessing and modifying the target settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IProjectTargetApi {

    /**
     * {@link #getAvailableDerivatives()} returns all possible input values for {@link #setDerivative(DerivativeInfo)}.
     *
     * <div class="extdoc" id="getAvailableDerivatives">
     * <h5>Available Derivatives</h5> {@link #getAvailableDerivatives()} returns all possible input values for {@link #setDerivative(DerivativeInfo)}.
     *
     * </div>
     *
     * @return all available {@link DerivativeInfo}s
     */
    @PublishedMethod
    Collection<DerivativeInfo> getAvailableDerivatives();

    /**
     * {@link #getAvailableDerivatives(String)} returns all possible input values for {@link #setDerivative(String, DerivativeInfo)}.
     *
     * <div class="extdoc" id="getAvailableDerivatives">
     * <h5>Module</h5> The module which supported Derivatives shall be retrieved.
     * <h5>Available Derivatives</h5> {@link #getAvailableDerivatives(String)} returns all possible input values for {@link #setDerivative(String, DerivativeInfo)}. Note: This
     * function will return value of {@link #getAvailableDerivatives()} if module is not hardware-specific.
     *
     * </div>
     *
     * @return all available {@link DerivativeInfo}s
     */
    @PublishedMethod
    Collection<DerivativeInfo> getAvailableDerivatives(String module);

    /**
     * {@link #getDerivative()} returns the derivative project setting.
     *
     * <div class="extdoc" id="getDerivative">
     * <h5>Get Derivative</h5> {@link #getDerivative()} returns the value of the current derivative project setting. Note: This function will return null if no derivative has
     * been configured.</div>
     *
     * @return The derivative of type {@link DerivativeInfo}
     */
    @PublishedMethod
    DerivativeInfo getDerivative();

    /**
     * {@link #getDerivative(String)} returns the derivative set for specific module.
     *
     * <div class="extdoc" id="getDerivative">
     * <h5>Module</h5> The module which derivative setting shall be retrieved.
     * <h5>Get Derivative</h5> {@link #getDerivative(String)} returns the value of the derivative configured for given module. Note: This function will return value of
     * {@link #getDerivative()} (potentially null) if no module-specific derivative has been configured.</div>
     *
     * @return The derivative of type {@link DerivativeInfo}
     */
    @PublishedMethod
    DerivativeInfo getDerivative(String module);

    /**
     * Alias for {@link #setDerivative(DerivativeInfo)}.
     *
     * @param derivative the derivative
     */
    @PublishedMethod
    void derivative(@Nullable DerivativeInfo derivative);

    /**
     * Sets the derivative for the project. The available derivatives can be retrieved with {@link #getAvailableDerivatives()}.
     *
     * <div class="extdoc" id="setDerivative">
     * <h5>Derivative</h5> Set the derivative for the project with {@link #setDerivative(DerivativeInfo)}. The value given here must be one of the values returned by
     * {@link #getAvailableDerivatives()}.
     *
     * </div>
     *
     * @param derivative the derivative for the new project
     */
    @PublishedMethod
    void setDerivative(@Nullable DerivativeInfo derivative);

    /**
     * Alias for {@link #setDerivative(String, DerivativeInfo)}.
     *
     * @param module the module
     * @param derivative the module-specific derivative
     */
    @PublishedMethod
    void derivative(String module, @Nullable DerivativeInfo derivative);

    /**
     * Sets the derivative for given module. The available derivatives can be retrieved with {@link #getAvailableDerivatives(String)}.
     *
     * <div class="extdoc" id="setDerivative">
     * <h5>Module</h5> The module which the derivative shall be set for.
     * <h5>Derivative</h5> Set the derivative for given module with {@link #setDerivative(String, DerivativeInfo)}. The value given here must be one of the values returned by
     * {@link #getAvailableDerivatives(String)}.
     *
     * </div>
     *
     * @param derivative the derivative for the new project
     */
    @PublishedMethod
    void setDerivative(String module, @Nullable DerivativeInfo derivative);

    /**
     * {@link #getAvailableCompilers()} returns all possible input values for {@link #setCompiler(ImplementationProperty)}.
     *
     *
     * <div class="extdoc" id="getAvailableCompilers">
     * <h5>Available Compilers</h5> {@link #getAvailableCompilers()} returns all possible input values for {@link #setCompiler(ImplementationProperty)}. Note: the available
     * compilers depend on the currently configured derivative. This method will return an empty collection if no derivative has been configured at the time it is called.</div>
     *
     * @return all available {@link ImplementationProperty}s of type {@link EImplementationProperties#COMPILER}
     */
    @PublishedMethod
    Collection<ImplementationProperty> getAvailableCompilers();

    /**
     * {@link #getCompiler()} returns the compiler project setting.
     *
     * <div class="extdoc" id="getCompiler">
     * <h5>Get Compiler</h5> {@link #getCompiler()} returns the value of the current compiler project setting. Note: If no compiler has been configured, it will return
     * null.</div>
     *
     * @return The compiler {@link Compiler} of type {@link ImplementationProperty}
     */
    @PublishedMethod
    ImplementationProperty getCompiler();

    /**
     * Alias for {@link #setCompiler(ImplementationProperty)}.
     *
     * @param compiler the compiler
     */
    @PublishedMethod
    void compiler(@Nullable ImplementationProperty compiler);

    /**
     * Sets the compiler for the new project.
     *
     * <div class="extdoc" id="setCompiler">
     * <h5>Compiler</h5> Set the compiler for the new project with {@link #setCompiler(ImplementationProperty)}. The value given here must be one of the values returned by
     * {@link #getAvailableCompilers()}.
     *
     * </div>
     *
     * @param compiler the compiler for the new project
     */
    @PublishedMethod
    void setCompiler(@Nullable ImplementationProperty compiler);

    /**
     * {@link #getAvailablePinLayouts()} returns all possible input values for {@link #setPinLayout(ImplementationProperty)}.
     *
     *
     * <div class="extdoc" id="getAvailablePinLayouts"><!--Label:IProjectTargetApi.getAvailablePinLayouts-->
     * <h5>Available PinLayouts</h5> {@link #getAvailablePinLayouts()} returns all possible input values for {@link #setPinLayout(ImplementationProperty)}. Note: The available
     * pin layouts depend on the currently configured derivative. This method will return a empty collection if no derivative has been configured at the time it is called.
     *
     * </div>
     *
     * @return all available {@link ImplementationProperty}s of type {@link EImplementationProperties#PINLAYOUT}
     */
    @PublishedMethod
    Collection<ImplementationProperty> getAvailablePinLayouts();

    /**
     * {@link #getPinLayout()} returns the pinLayout project setting.
     *
     * <div class="extdoc" id="getPinLayout">
     * <h5>Get PinLayout</h5> {@link #getPinLayout()} returns the value of the current pinLayout project setting. Note: If no pinLayout has been configured, it will return
     * null.</div>
     *
     * @return The pinLayout {@link pinLayout} of type {@link ImplementationProperty}
     */
    @PublishedMethod
    ImplementationProperty getPinLayout();

    /**
     * Alias for {@link #setPinLayout(ImplementationProperty)}.
     *
     * @param pinLayout the pin layout
     */
    @PublishedMethod
    void pinLayout(@Nullable ImplementationProperty pinLayout);

    /**
     * Sets the pin layout for the new project.
     *
     * <div class="extdoc" id="setPinLayout"><!--Label:IProjectTargetApi.setPinLayout-->
     * <h5>PinLayout</h5> Set the pinLayout of the selected derivative for the project with <br>
     * {@link #setPinLayout(ImplementationProperty)}. The value given here must be one of the values returned by {@link #getAvailablePinLayouts()}.
     *
     * </div>
     *
     * @param pinLayout the pin layout for the new project
     */
    @PublishedMethod
    void setPinLayout(@Nullable ImplementationProperty pinLayout);

}