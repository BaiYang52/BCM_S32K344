package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class InvalidShortnameException extends ModelInconsistencyException {

    private static final long serialVersionUID = 8774924118872340504L;

    private final String shortname;

    private final String invalidReason;

    /**
     * Constructor.
     */
    @PublishedMethod
    public InvalidShortnameException(String shortname, String invalidReason) {
        super("The shortname '" + shortname + "' is invalid (" + invalidReason + ")");
        this.shortname = shortname;
        this.invalidReason = invalidReason;
    }

    @PublishedMethod
    public String getShortname() {
        return shortname;
    }

    @PublishedMethod
    public String getInvalidReason() {
        return invalidReason;
    }

}
