package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.model.query.modeltraverser.Path.EEvaluationOptions;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This class is an {@link ISolvingAction} that creates a parameter when executed.
 * <p/>
 * Hint: Just creating a parameter without setting its value, does very often not solve a problem completely and there should be good reason for offering solely this as a
 * solving action. Especially, if the parameter has no default value defined (this is also true for all reference parameters), the parameter will be created without value. The
 * ModelTraverser considers parameters without a value as base-invalid and will not create a valid-view containing such a parameter, see
 * {@link EEvaluationOptions#DisableNoValueCheck}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class SACreateParameter implements ISolvingAction {

    @PublishedField
    protected final MIContainer parent;

    @PublishedField
    protected final DefRef paramDef;

    private final IModelOperations modelOperations;

    private final String description;

    /**
     * Constructor for {@link SACreateParameter}. Please read hint in the class description before using this class.
     *
     * @param parent the parent container
     * @param paramDef the parameter DefRef
     */
    @PublishedMethod
    public SACreateParameter(MIContainer parent, DefRef paramDef) {
        this(parent, checkNotNull(paramDef), "Create Parameter " + paramDef.getLastShortname());

    }

    /**
     * Constructor for {@link SACreateParameter}. Please read hint in the class description before using this class.
     *
     * @param parent the parent container
     * @param paramDef the parameter DefRef
     * @param description override the description of the SA
     */
    @PublishedMethod
    public SACreateParameter(MIContainer parent, DefRef paramDef, String description) {

        this.parent = checkNotNull(parent);
        this.modelOperations = ModelUtil.getService(parent, IModelOperations.class);

        this.paramDef = checkNotNull(paramDef);

        this.description = checkNotNull(description);
        if (description.isEmpty()) {
            throw new IllegalArgumentException("The description is empty.");
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {

        modelOperations.createParameterByDefinition(parent, paramDef);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        return description;
    }
}
