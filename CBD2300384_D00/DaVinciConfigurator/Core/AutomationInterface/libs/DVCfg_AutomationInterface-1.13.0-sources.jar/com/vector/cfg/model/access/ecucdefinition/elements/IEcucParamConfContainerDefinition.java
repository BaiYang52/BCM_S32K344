package com.vector.cfg.model.access.ecucdefinition.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucParamConfContainerDefinition extends IEcucContainerDefinition {

    /**
     * Returns the optional parameter definition which is marked as symbolic name value
     *
     * This never returns <code>null</code>. If the container was no symbolic name value, an absent optional is returned.
     *
     * @return W
     */
    @PublishedMethod
    Optional<MIConfigParameter> getSymbolicNameValue();
}
