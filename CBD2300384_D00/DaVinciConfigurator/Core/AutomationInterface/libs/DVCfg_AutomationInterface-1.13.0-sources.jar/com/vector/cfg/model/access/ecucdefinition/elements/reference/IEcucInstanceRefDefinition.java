package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;
import javax.jmi.reflect.RefClass;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucInstanceRefDefinition extends IEcucAbstractRef {

    /**
     * returns an optional holding the target ref class. Never returns <code>null</code>.
     *
     * @return
     * @deprecated Not required anymore
     */
    @PublishedMethod
    @Deprecated
    @ReworkThisAtNextBreakingChange("Remove this method - no internal and external usage found in R16!")
    Optional<? extends RefClass> getTargetRefClass();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIInstanceReferenceParamDef getDef();
}
