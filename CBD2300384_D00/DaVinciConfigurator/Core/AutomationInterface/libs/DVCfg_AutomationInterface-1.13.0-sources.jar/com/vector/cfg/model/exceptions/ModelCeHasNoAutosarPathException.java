package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;

/**
 * Thrown to indicate that a {@link MIReferrable} object has no corresponding autosar path.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelCeHasNoAutosarPathException extends ReferrableHasNoAutosarPathException {

    private static final long serialVersionUID = -6250273989567268892L;

    /**
     * Constructor.
     *
     * @param mdfObject the MIReferrable which has no autosar path
     * @param ex
     */
    @PublishedMethod
    public ModelCeHasNoAutosarPathException(MIReferrable mdfObject, Throwable ex) {
        super(mdfObject, ex);

    }

    @Override
    @PublishedMethod
    public MIReferrable getCe() {
        return (MIReferrable) super.getCe();
    }
}
