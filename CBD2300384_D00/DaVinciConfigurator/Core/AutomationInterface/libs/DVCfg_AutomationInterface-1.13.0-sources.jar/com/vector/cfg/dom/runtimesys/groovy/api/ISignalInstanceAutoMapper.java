package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.ECompatibility;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ISignalInstanceAutoMapper"><!--Label:ISignalInstanceAutoMapper-->{@link ISignalInstanceAutoMapper} provides an Api to control and evaluate the
 * auto-data-mapping of signal instances to communication elements. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceAutoMapper {

    /**
     * <div class="extdoc" id="selectTargetCommunicationElements"><!--Label:ISignalInstanceAutoMapper.selectTargetCommunicationElements-->
     * {@link #selectTargetCommunicationElements(Closure)} allows to define predicates to narrow down the target communciation elements for the auto-mapping. The predicates are
     * used to filter the possible target communication elements which were computed from the signal instance selection.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetCommunicationElements(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:ISignalInstanceAutoMapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the results
     * of the auto-mapping. It corresponds to the confirm page of the data mapping assistant.
     * <p>
     * For each signal instance the provided closure is called: Parameters are the signal instance, the optional matched target communication element (or null), and a list of
     * all potential target communication elements (respecting the {@link #selectTargetCommunicationElements(Closure)} predicates). The return value must be a communication
     * element or null.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the matches of the auto-mapping.
     *
     * @exception SelectionException when both {@link #evaluateMatches(Closure)} and {@link #evaluateMatchesWithCompatibility(Closure)} are called.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,java.util.List<com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement>") @Nonnull Closure<ICommunicationElement> code);

    /**
     * <div class="extdoc" id=
     * "evaluateMatchesWithCompatibility"><!--Label:ISignalInstanceAutoMapper.evaluateMatchesWithCompatibility-->{@link #evaluateMatchesWithCompatibility(Closure)} allows to
     * evaluate and change the results of the auto-mapping. It corresponds to the confirm page of the data mapping assistant. In contrast to {@link #evaluateMatches(Closure)}
     * this method also provides the compatibility of the optional match.
     * <p>
     * For each signal instance the provided closure is called: Parameters are the signal instance, the optional matched target communication element (or null), their
     * compatibility and a list of all potential target communication elements (respecting the {@link #selectTargetCommunicationElements(Closure)} predicates). The return value
     * must be a communication element or null.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the matches of the auto-mapping using compatibility of the optional match.
     *
     * @exception SelectionException when both {@link #evaluateMatches(Closure)} and {@link #evaluateMatchesWithCompatibility(Closure)} are called.
     */
    @PublishedMethod
    void evaluateMatchesWithCompatibility(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,com.vector.cfg.model.sysdesc.api.com.ECompatibility,java.util.List<com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement>") @Nonnull Closure<ICommunicationElement> code);

    /**
     * <div class="extdoc" id="confirmByCompatibility"><!--Label:ISignalInstanceAutoMapper.confirmByCompatibility-->{@link #confirmByCompatibility(Closure)} allows to evaluate
     * the mappings which should be created.
     * <p>
     * For each signal instance the provided closure is called: Parameters are the signal instance, the optional matched target communication element (or null) and the
     * compatibility of them ({@link ECompatibility#NULL} if no optional match present) respecting all previous evaluations. So this is the final verifying step to confirm or
     * reject the mapping. The return value must be true if the mapping should be created or false if you want to reject the mapping.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the mappings which decides which mapping should be accepted and which one not.
     */
    @PublishedMethod
    void confirmByCompatibility(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,com.vector.cfg.model.sysdesc.api.com.ECompatibility") @Nonnull Closure<Boolean> code);

    /**
     * <div class="extdoc" id="expandNestedArraysOfPrimitive">
     * <h5>Nested Array of Primitives</h5><!--Label:sec:ISignalInstanceAutoMapper_expandNestedArraysOfPrimitive--> {@link #expandNestedArraysOfPrimitive(boolean)} allows to
     * control the expansion of nested arrays of primitive globally. Per default, arrays are fully expanded (allowing to data map each array element). By setting the value to
     * 'false', all nested arrays of primitive are not expanded and can be directly data-mapped to a signal. </div> *
     * <p>
     * The fully qualified communication element name is e.g. determinable when using the data mapping assistant, performing an arbitrary signal group mapping of the root data
     * element, and using the right-mouse menu its 'Copy fully qualified name' action on the nested array element.
     * </p>
     *
     * @param expand
     */
    @PublishedMethod
    void expandNestedArraysOfPrimitive(boolean expand);

    /**
     * <div class="extdoc" id="expandNestedArraysOfPrimitiveFullyQualified">{@link #expandNestedArraysOfPrimitive(String,boolean)} allows to control the expansion of nested
     * arrays of primitive for single nested arrays. Per default, the {@link #expandNestedArraysOfPrimitive(boolean)} applies. For the given fully qualified communication
     * element name, the global setting can be overridden. </div>
     *
     * @param fullyQualifiedComElementName
     * @param expand
     */
    @PublishedMethod
    void expandNestedArraysOfPrimitive(String fullyQualifiedComElementName, boolean expand);

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetCommunicationElementsCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<ICommunicationElement>> getEvaluateMatchesCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<ICommunicationElement>> getEvaluateMatchesWithCompatibilityCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<Boolean>> getConfirmByCompatibilityCode();

}
