package com.vector.cfg.gen.core.bswmdmigration.groovy;

import javax.annotation.concurrent.ThreadSafe;

import org.junit.Rule;
import org.junit.rules.TestRule;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmigration.IBswmdMigrationServicePublished;

/**
 * The {@link IMigrationClassRule}} describes how the migration testing is run and reported.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IMigrationClassRule extends TestRule {

    /**
     * Returns the {@link IBswmdMigrationServicePublished } service.
     *
     * @return {@link IBswmdMigrationServicePublished }
     */
    @KeepSecretFromPublishedApi
    IBswmdMigrationServicePublished getBswmdMigrationService();

    /**
     * Retuns the migration api setup as a {@link Rule}.
     *
     * @return {@link IMigrationApi}
     */
    @PublishedMethod
    IMigrationApi getRule();

}
