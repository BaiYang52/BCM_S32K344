/**
 * Provides the APIs to start the Update Workflow. <div class="extdoc" id="UpdateWorkflowAPIs">APIs that allows to start the complete Update Workflow process or parts of
 * it.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.groovy.update.project;