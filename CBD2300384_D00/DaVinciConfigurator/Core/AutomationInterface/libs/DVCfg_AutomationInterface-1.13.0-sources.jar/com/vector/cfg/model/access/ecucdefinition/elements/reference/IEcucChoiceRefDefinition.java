package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucChoiceRefDefinition extends IEcucAbstractRef {

    /**
     * returns an list of target definitions. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    List<IEcucContainerDefinition> getTargetDefinitions();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIChoiceReferenceParamDef getDef();
}
