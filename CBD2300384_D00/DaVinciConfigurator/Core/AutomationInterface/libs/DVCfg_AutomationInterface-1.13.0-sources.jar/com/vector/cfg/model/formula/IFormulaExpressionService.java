package com.vector.cfg.model.formula;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.formulalanguage.MIFormulaExpression;

/**
 * <div class="extdoc" id="Common">
 *
 * The {@link IFormulaExpressionService} is a project service which provides several methods to evaluate a {@link MIFormulaExpression}, and set its value as well.
 *
 * <h3>Get Formula Value</h3> The formula expressions can contain a simple numeric literal, a boolean literal, or a more advanced expression that handles references to autosar
 * model elements, arithmetic functions, special functions, and special values. The method <code>getValue(MIFormulaExpression)</code> evaluates the expression and returns the
 * evaluation result as an {@link IFormulaResult}.
 *
 * <h3>Set Formula Value</h3> Replacing the content of a {@link MIFormulaExpression} with a simple numeric value is possible using the following methods:
 *
 * <ul>
 * <li>{@link #setValue(MIFormulaExpression, Number)}: Replaces the content of the provided formula expression with the provided numeric value.</li>
 * <li>{@link #setValue(MIFormulaExpression, boolean)}: Replaces the content of the provided formula expression with the string representation of the provided Boolean
 * value.</li>
 * </ul>
 *
 * <p>
 * <b>Important remark:</b> These operations must run within a unit of work. The client code is responsible for opening the transaction before calling these two methods.
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IFormulaExpressionService {

    /**
     * Get the result of parsing, and if necessary evaluating, the passed {@link MIFormulaExpression}.
     *
     * @param formula the formula from the MDF model.
     * @return {@link IFormulaResult}
     * @throws NullPointerException if the parameter formula is null.
     */
    @PublishedMethod
    IFormulaResult getValue(MIFormulaExpression formula);

    /**
     * Replaces the content of the passed {@link MIFormulaExpression} by the provided numeric value.
     *
     * @param formula the formula from the MDF model.
     * @param value   the numeric value to set.
     * @throws NullPointerException if any of the parameters is null.
     */
    @PublishedMethod
    void setValue(MIFormulaExpression formula, Number value);

    /**
     * Replaces the content of the passed {@link MIFormulaExpression} by the string representation of the provided Boolean value.
     *
     * @param formula the formula from the MDF model.
     * @param value   the Boolean value to set.
     * @throws NullPointerException if any of the parameters is null.
     */
    @PublishedMethod
    void setValue(MIFormulaExpression formula, Boolean value);
}
