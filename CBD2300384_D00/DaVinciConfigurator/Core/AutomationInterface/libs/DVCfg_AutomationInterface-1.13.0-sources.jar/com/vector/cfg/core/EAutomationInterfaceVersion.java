package com.vector.cfg.core;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.osgi.service.resolver.VersionRange;
import org.osgi.framework.Bundle;
import org.osgi.framework.Version;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedApiVersionInfo;
import com.vector.annotations.publishedapi.VersionType;
import com.vector.cfg.core.internal.Activator;

/**
 * The enum {@link EAutomationInterfaceVersion} describes the compatibility of the Cfg5 to the Automation interface clients.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public enum EAutomationInterfaceVersion {

    VERSION_1_0_0("1.0.0", "[1.0.0 , 1.1)", "Cfg5.13 - AR4-16"),
    VERSION_1_1_0("1.1.0", "[1.0.0 , 1.2)", "Cfg5.14 - AR4-17"),
    VERSION_1_2_0("1.2.0", "[1.0.0 , 1.3)", "Cfg5.15 - AR4-18"),
    VERSION_1_3_0("1.3.0", "[1.0.0 , 1.4)", "Cfg5.16 S-5 - AR4-19"),
    VERSION_1_4_0("1.4.0", "[1.0.0 , 1.5)", "Cfg5.16 - AR4-19"),
    VERSION_1_5_0("1.5.0", "[1.0.0 , 1.6)", "Cfg5.17 - AR4-20"),
    //------------------------------------------------------------------------------
    //Now         |<VERSION>|<VERSIONRANGE MSR><VERSIONRANGE AMSR>|<DESCRIPTION>   |
    //------------------------------------------------------------------------------
    VERSION_1_6_0("1.6.0", "[1.0.0 , 1.7)", "[1.6.0 , 1.7)", "Cfg5.18 - AR4-21"),
    VERSION_1_7_0("1.7.0", "[1.0.0 , 1.8)", "[1.7.0 , 1.8)", "Cfg5.20 - AR4-23"),
    VERSION_1_8_0("1.8.0", "[1.0.0 , 1.9)", "[1.8.0 , 1.9)", "Cfg5.21 - AR4-24"),
    VERSION_1_9_0("1.9.0", "[1.0.0 , 1.10)", "[1.9.0 , 1.10)", "Cfg5.22 - AR4-25"),
    VERSION_1_10_0("1.10.0", "[1.0.0 , 1.11)", "[1.10.0 , 1.11)", "Cfg5.23 - AR4-26"),
    VERSION_1_11_0("1.11.0", "[1.0.0 , 1.12)", "[1.11.0 , 1.12)", "Cfg5.24 - AR4-27"),
    VERSION_1_12_0("1.12.0", "[1.0.0 , 1.13)", "[1.12.0 , 1.13)", "Cfg5.25 - AR4-28"),
    VERSION_1_13_0("1.13.0", "[1.0.0 , 1.14)", "[1.13.0 , 1.14)", "Cfg5.26 - AR4-29"),
    ;

    /**
     * AutomationInterfaceVersionRange specifies the compatibility of Cfg Core Versions to external components automation scripts.
     *
     * <p>
     * This VersionRanges is used to determine which Automation scripts are compatible to the current Cfg5Core. The CFG_AUTOMATION_INTERFACE_VERSION_RANGE_STRING specifies the
     * current version. The VersionRange should start at the last BreakingChange (e.g. MajorVersion 3.0.0) and end at the current Major.Minor Version incl. all patches<br />
     * Example: Current Version 1.13.0 => Range: [1.0.0,1.14)
     * </p>
     *
     */
    @PublishedApiVersionInfo(domainType = DomainType.AUTOMATION_IF, versionType = VersionType.VERSION_RANGE)
    public static final String CFG_AUTOMATION_INTERFACE_VERSION_RANGE_STRING = "[1.0.0 , 1.14)";

    /**
     * AutomationInterfaceVersion specifies the current version of the Cfg Core to external components automation scripts.
     *
     *
     * <p>
     * The AutomationInterfaceVersion version shall be incremented, when any PublishedAPI classes are changed. <br/>
     * <ul>
     * <li>Additions to classes => Increment Minor version</li>
     * <li>BreakingChanges to classes => Increment Major version</li>
     * </ul>
     * </p>
     *
     *
     * <p>
     * The following version history is a mapping from Cfg-Core version to Cfg5 releases / MICROSAR releases:
     * <ul>
     * <li><b>1.0.0</b>: Cfg5.13 - AR4-R16</li>
     * <li><b>1.1.0</b>: Cfg5.14 - AR4-R17</li>
     * <li><b>1.2.0</b>: Cfg5.15 - AR4-R18</li>
     * <li><b>1.3.0</b>: Cfg5.16 S-5 - AR4-19</li>
     * <li><b>1.4.0</b>: Cfg5.16 - AR4-R19</li>
     * <li><b>1.5.0</b>: Cfg5.17 - AR4-R20</li>
     * <li><b>1.6.0</b>: Cfg5.18 - AR4-R21</li>
     * <li><b>1.7.0</b>: Cfg5.20 - AR4-R23</li>
     * <li><b>1.8.0</b>: Cfg5.21 - AR4-R24</li>
     * <li><b>1.9.0</b>: Cfg5.22 - AR4-R25</li>
     * <li><b>1.10.0</b>: Cfg5.23 - AR4-R26</li>
     * <li><b>1.11.0</b>: Cfg5.24 - AR4-R27</li>
     * <li><b>1.12.0</b>: Cfg5.25 - AR4-R28</li>
     * <li><b>1.13.0</b>: Cfg5.26 - AR4-R29</li>
     * </ul>
     * </p>
     *
     */
    @PublishedApiVersionInfo(domainType = DomainType.AUTOMATION_IF, versionType = VersionType.VERSION)
    public static final String CFG_AUTOMATION_INTERFACE_VERSION_STRING = "1.13.0";

    /* End JavaListing */

    @GuardedBy("Class Obj")
    private static EAutomationInterfaceVersion currentVersion;

    /**
     * Return the current {@link EAutomationInterfaceVersion} of this DaVinci Configurator Classic at runtime.
     *
     * @return the current version.
     */
    public static EAutomationInterfaceVersion getCurrentVersion() {
        return initAndGetCurrentVersion();
    }

    private static EAutomationInterfaceVersion initAndGetCurrentVersion() {
        synchronized (EAutomationInterfaceVersion.class) {
            if (currentVersion != null) {
                return currentVersion;
            }
            final Optional<EAutomationInterfaceVersion> versionOf = versionOf(CFG_AUTOMATION_INTERFACE_VERSION_STRING);
            if (!versionOf.isPresent()) {
                throw new IncompatibleClassChangeError("The Current AutomationInterface " + CFG_AUTOMATION_INTERFACE_VERSION_STRING
                        + " has no corresponding EAutomationInterfaceVersion object. You have to create an enum literal for each version increment.");
            }

            verifyManifestMfVersion(versionOf.get().getVersion());
            currentVersion = versionOf.get();
            return currentVersion;
        }

    }

    private static void verifyManifestMfVersion(Version currentVersionOfCoreFeature) {
        final Bundle bundle = Activator.getContext().getBundle();
        final Version manifestMdfVersion = bundle.getVersion();

        if (manifestMdfVersion.getMajor() == currentVersionOfCoreFeature.getMajor()) {
            if (manifestMdfVersion.getMinor() == currentVersionOfCoreFeature.getMinor()) {
                if (manifestMdfVersion.getMicro() == currentVersionOfCoreFeature.getMicro()) {
                    // Both versions are equal => Valid
                    return;
                }
            }
        }
        /*
        throw new IncompatibleClassChangeError("The Manifest.MF Eclipse version " + manifestMdfVersion + " of " + bundle.getSymbolicName()
                + " is NOT equal to the AutomationInterfaceVersion " + currentVersionOfCoreFeature
                + ". Both versions must be the same in Major.Minor.Path. You have to synchronize these versions!");
                */

    }

    /**
     * Parses the passed versionStr and returns an {@link EAutomationInterfaceVersion}, if exists.
     *
     * @param versionStr the version to parse.
     * @return the {@link EAutomationInterfaceVersion} literal of the parsed version.
     */

    public static Optional<EAutomationInterfaceVersion> versionOf(String versionStr) {
        checkNotNull(versionStr);
        final String versionStrTemp = versionStr.trim();
        for (final EAutomationInterfaceVersion ver : values()) {

            if (versionStrTemp.equals(ver.getVersionString())) {
                return Optional.of(ver);
            }
        }
        return Optional.absent();
    }

    /*
     * Instance fields and methods
     */

    /**
     * Specifies the compatibility of Cfg Core Versions.
     *
     * @See IGeneratorPackage for the Corresponding Version
     */
    private final VersionRange versionRangeMsr;

    private final VersionRange versionRangeAMsr;

    private final Version version;

    private final String versionString;

    private final String versionRangeMsrString;

    private final String versionRangeAMsrString;

    private final String description;

    EAutomationInterfaceVersion(String versionStr, String versionRangeMsrStr, String versionRangeAMsrStr, String description) {
        versionString = versionStr;
        this.versionRangeMsrString = versionRangeMsrStr;
        this.versionRangeAMsrString = versionRangeAMsrStr;
        this.description = description;

        this.versionRangeMsr = new VersionRange(versionRangeMsrStr);
        this.versionRangeAMsr = new VersionRange(versionRangeAMsrStr);
        version = org.osgi.framework.Version.parseVersion(versionStr);
        checkArgument(versionRangeMsr.includes(version));
    }

    EAutomationInterfaceVersion(String versionStr, String versionRangeStr, String description) {
        this(versionStr, versionRangeStr, versionRangeStr, description);
    }

    /**
     * Returns the version as String.
     *
     * @return the version string
     */

    public String getVersionString() {
        return versionString;
    }

    public Version getVersion() {
        return version;
    }

    /**
     * Returns the versionRange as String. This returns the version range for MSR.
     *
     * @return Returns the versionRange.
     */
    public String getVersionRangeStringMsr() {
        return versionRangeMsrString;
    }

    /**
     * Returns the versionRange as String. This returns the version range for AMSR.
     *
     * @return Returns the versionRange.
     */
    public String getVersionRangeStringAMsr() {
        return versionRangeAMsrString;
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object. This returns the version range for MSR.
     */
    public VersionRange getCompatibleCoreVersionRangeAMsr() {
        return versionRangeAMsr;
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object. This returns the version range for AMSR.
     */
    public VersionRange getCompatibleCoreVersionRangeMsr() {
        return versionRangeMsr;
    }

    /**
     * Returns the description of the Version, to display for the user.
     * <p>
     * Normally this shall contain the Cfg5 version and the MICROSAR release.
     *
     *
     * @return Returns the description.
     */

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return getDescription() + " (AutomationInterfaceVersion: " + getVersionString() + ")";
    }

    public String toStringWithRange() {
        return getDescription() + " (AutomationInterfaceVersion: " + getVersionString() + " Compatible range MSR: " + getVersionRangeStringMsr() + " Compatible range AMSR: "
                + getVersionRangeStringAMsr() + ")";
    }
}
