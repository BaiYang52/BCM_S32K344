package com.vector.cfg.datamining.pai;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common"> The {@link ISearchApiEntryPoint} provides the possibility to search parameters, containers or module configurations by several criteria. The
 * API also provides the ability to execute several checks on the results.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface ISearchApiEntryPoint {

    /**
     * <div class="extdoc" id="search">The {@link #search(String)} is used to evaluate a {@link DataMiningService} query. If the query isn't correct, a {@link SearchApiException}
     * will be thrown. </div>
     *
     * @param <T>   the generic type
     * @param query the query
     * @param code  the code
     * @return the t
     */
    @PublishedMethod
    <T> T search(@Nonnull String query, @VDelegatesToWithClosureParam(ISearchResultApi.class) Closure<T> code);

    /**
     * The {@link #search(String)} is used to evaluate a {@link DataMiningService} query. If the query isn't correct, a {@link SearchApiException} will be thrown.
     *
     * @param query the query
     * @return the i search result api
     */
    @PublishedMethod
    ISearchResultApi search(@Nonnull String query);

}
