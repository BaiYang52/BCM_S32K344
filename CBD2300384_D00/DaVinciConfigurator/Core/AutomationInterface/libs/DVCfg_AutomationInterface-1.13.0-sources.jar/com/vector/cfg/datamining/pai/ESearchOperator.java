package com.vector.cfg.datamining.pai;

import java.util.function.BiPredicate;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.scripting.groovy.extensions.VectorCollectionExtensions;
import com.vector.davinci.util.base.VUtil;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum ESearchOperator {

    EQ((actual, expected) -> actual == expected),

    GE((actual, expected) -> actual >= expected),

    GT((actual, expected) -> actual > expected),

    LE((actual, expected) -> actual <= expected),

    LT((actual, expected) -> actual < expected),

    NE((actual, expected) -> actual != expected);

    private BiPredicate<Integer, Integer> operation;

    ESearchOperator(BiPredicate<Integer, Integer> operation) {
        this.operation = operation;
    }

    @KeepSecretFromPublishedApi
    public BiPredicate<Integer, Integer> getOperation() {
        return this.operation;
    }

    // NOTE: Workaround to tell the compiler that the com.vector.cfg.util.scripting.groovy plugin
    //       needs to be attracted.
    static {
        VUtil.indirectClassUsageForCompiler(VectorCollectionExtensions.class);
    }

}
