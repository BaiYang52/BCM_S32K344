package com.vector.cfg.gen.core.moduleinterface.auxiliary;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;

/**
 * The Class {@link IHasSetGeneratorResultSink} provides a setter semantic for {@link IGeneratorResultSink}s. E.g. A {@link IGenerationProcessor} is a
 * {@link IHasSetGeneratorResultSink}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasSetGeneratorResultSink {

    /**
     * Sets the current resultSink.
     * <p>
     * <b>Attention</b>: This method is not intended to be called by clients. It will be called by the framework.
     * </p>
     *
     * @param resultSink The resultSink to set by the framework.
     */
    @PublishedMethod
    void setResultSink(IGeneratorResultSink resultSink);
}
