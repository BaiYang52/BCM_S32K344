package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="IComponentPortUnmapper"><!--Label:IComponentPortUnmapper-->{@link IComponentPortUnmapper} provides an Api to control and evaluate the unmapping of
 * {@link IComponentPort}s from their connected {@link IComponentPort}s. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPortUnmapper {

    /**
     * <div class="extdoc" id="selectTargetPorts"><!--Label:IComponentPortUnmapper.selectTargetPorts-->{@link #selectTargetPorts(Closure)} allows to define predicates to narrow
     * down the target ports which shall be disconnected from the in previous step selected ports.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetPorts(@Nonnull @VDelegatesToWithClosureParam(ITargetComponentPortSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:IComponentPortUnmapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the results of
     * the unmapped component ports.
     * <p>
     * For each selected component port the provided closure is called: Parameters are the current handled component port and a list of all connected target component ports
     * (respecting the {@link #selectTargetPorts(Closure)} predicates). The return value must be a list of component ports which are connected to the current handled source
     * port.
     * </p>
     * </div>
     *
     * @param code The code to evaluate connected component ports which should be disconnected.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.port.IComponentPort,java.util.List<com.vector.cfg.model.sysdesc.api.port.IComponentPort>") @Nonnull Closure<List<IComponentPort>> code);

    @KeepSecretFromPublishedApi
    Optional<Closure<List<IComponentPort>>> getEvaluateMatchesCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetPortsCode();

}
