package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Comparator;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ITaskMappingSuccessorDefinition"><!--Label:ITaskMappingSuccessorDefinition-->{@link ITaskMappingSuccessorDefinition} provides an API to specify the
 * order of the task mappings by defining successor relationships.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMappingSuccessorDefinition {

    /**
     * <div class="extdoc" id="forTaskMapping"><!--Label:ITaskMappingSuccessorDefinition.forTaskMapping-->{@link #forTaskMapping(Closure)} allows to select a starting task
     * mapping for which successors can be defined.</div>
     *
     * @param code The code to select the starting task mapping of a successor chain.
     * @return The {@link ITaskMappingSuccessorChain} which allows to select successor task mappings.
     */
    @PublishedMethod
    ITaskMappingSuccessorChain forTaskMapping(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="sortSuccessorsInternally"><!--Label:ITaskMappingSuccessorDefinition.sortSuccessorsInternally-->{@link #sortSuccessorsInternally(Comparator)}
     * allows to define an additional comparator to increase the overview. Therefore the defined successors will be analyzed and divided in logical groups. The given comparator
     * is applied on each logical group separately, so that the defined successor relationships will not be violated.<br>
     * Hint: You can use only one comparator at the same time. So defining a custom comparator and using a default comparator at the same time will cause an exception.
     *
     * <p>
     * The following default comparators can be used instead: <br>
     * {@link #sortSuccessorsInternallyByExecutableEntity()} - sorts the task mappings alphabetically by their executable entity names.
     * </p>
     * </div>
     *
     * @throws SelectionException if {@link #sortSuccessorsInternally(Comparator)} and one of the default comparators mentioned above is used at the same time.
     * @param taskMappingComparator A custom comparator to sort the successor groups.
     */
    @PublishedMethod
    void sortSuccessorsInternally(Comparator<ITaskMapping> taskMappingComparator);

    /**
     * <div class="extdoc" id=
     * "sortSuccessorsInternallyByExecutableEntity"><!--Label:ITaskMappingSuccessorDefinition.sortSuccessorsInternallyByExecutableEntity-->{@link #sortSuccessorsInternallyByExecutableEntity()}
     * sorts the task mappings of the defined successors alphabetically by their executable entity names. See {@link #sortSuccessorsInternally(Comparator)} for more details.
     * <br>
     *
     * <p>
     * To use a custom comparator use {@link #sortSuccessorsInternally(Comparator)} instead.
     * </p>
     * </div>
     *
     * @throws SelectionException if {@link #sortSuccessorsInternallyByExecutableEntity()} is used together with {@link #sortSuccessorsInternally(Comparator)}.
     * @param taskMappingComparator A custom comparator to sort the successor groups.
     */
    @PublishedMethod
    void sortSuccessorsInternallyByExecutableEntity();

    // -----------------------------------------------

    @KeepSecretFromPublishedApi
    List<ITaskMappingSuccessorChain> getTaskMappingSuccessorChains();

    @KeepSecretFromPublishedApi
    Comparator<ITaskMapping> getComparator();
}
