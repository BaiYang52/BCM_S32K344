package com.vector.cfg.gen.core.moduleinterface;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link EGenerationProcessResult} defines the overall return state of a generation process execution.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF })
public enum EGenerationProcessResult {

    SUCCESSFUL(0) {
        @Override
        public boolean isSuccessful() {
            return true;
        }
    },
    WARNING(1) {
        @Override
        public boolean isSuccessful() {
            return true;
        }
    },
    CANCELED(2),
    ERROR(3) {
        @Override
        public boolean isErroneous() {
            return true;
        }
    },
    FATAL_ERROR(4) {
        @Override
        public boolean isErroneous() {
            return true;
        }

        @Override
        public boolean isFatal() {
            return true;
        }
    };

    private final int errorCode;

    EGenerationProcessResult(int errorCode) {
        this.errorCode = errorCode;

    }

    @PublishedMethod
    public boolean isSuccessful() {
        return false;
    }

    @PublishedMethod
    public boolean isErroneous() {
        return false;
    }

    @PublishedMethod
    public boolean isFatal() {
        return false;
    }

    @KeepSecretFromPublishedApi
    public EGenerationProcessResult getResultWithHighestErrorCode(EGenerationProcessResult other) {

        if (this.errorCode < other.errorCode) {
            return other;
        } else if (this.errorCode == other.errorCode) {
            return this;
        } else {
            return this;
        }

    }

}
