package com.vector.cfg.workflow.diff.groovy.projectcompare.compare.result;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * A {@link IDifference} represents a difference within the {@link ICompareResult} API.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDifference {

    /**
     * <div class="extdoc" id="getIdentifier">The method {@link #getIdentifier()} is used to get the identifier of the CE represented by this {@link IDifference}.
     *
     * </div>
     *
     * @return the identifier of the CE represented by this {@link IDifference}.
     */
    @PublishedMethod
    String getIdentifier();

    /**
     * <div class="extdoc" id="getDifferenceType">The method {@link #getType()} is used to get the type of this {@link IDifference}.
     *
     * </div>
     *
     * @return the type of this {@link IDifference}.
     */
    @PublishedMethod
    EDifferenceType getType();

    /**
     * <div class="extdoc" id="getOrigin">The method {@link #getOrigin()} is used to get the origin of this {@link IDifference}.
     *
     * </div>
     *
     * @return the origin of this {@link IDifference}.
     */
    @PublishedMethod
    EDifferenceOrigin getOrigin();

}
