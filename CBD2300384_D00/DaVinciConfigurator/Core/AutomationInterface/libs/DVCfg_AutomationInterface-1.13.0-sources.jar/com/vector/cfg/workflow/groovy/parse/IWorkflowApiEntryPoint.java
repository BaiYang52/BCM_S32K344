package com.vector.cfg.workflow.groovy.parse;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.update.IUpdateWorkflowApi;

import groovy.lang.Closure;

/**
 * {@link IWorkflowApiEntryPoint} is the entry point for workflow related API like the update process of input files.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IWorkflowApiEntryPoint {

    /**
     * Returns the {@link IWorkflowApi}.
     *
     * @return the workflow api
     */
    @PublishedMethod
    IWorkflowApi getWorkflow();

    /**
     * Executes the specified closure with the {@link IWorkflowApi} as delegate.
     *
     * @param code
     * @return the closures return value
     */
    @PublishedMethod
    <T> T workflow(@VDelegatesToWithClosureParam(IWorkflowApi.class) Closure<T> code);

    /**
     * The Interface IWorkflowApi. <div class="extdoc" id="IWorkflowApi">
     * <p>
     * The {@link IWorkflowApi} is the automation interface for workflows. It is available everywhere in any script using a property approach or using a delegate approach:
     *
     * <pre>
     * <code class="Java" id="description">
     * scriptTask("PropertyApproach", DV_APPLICATION) {
     *     code {
     *         workflow.update {
     *             ...
     *         }
     *     }
     * }
     *
     * scriptTask("DelegateApproach", DV_APPLICATION) {
     *     code {
     *         workflow {
     *             update {
     *                 ...
     *             }
     *         }
     *     }
     * }
     *</code>
     * </pre>
     *
     * The following functionality is provided:
     * </p>
     * </div>
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IWorkflowApi extends IUpdateWorkflowApi, IDynamicObjectAware {

        @PublishedMethod
        List<IWfEcuInstance> parse(@Nonnull @VDelegatesToWithClosureParam(IParseApi.class) Closure<?> code);

    }

}
