package com.vector.cfg.util.version;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * This is an immutable class implementing version numbers.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class Version implements IVersion {

    private final Integer major;

    private final Integer minor;

    private final Integer patchLevel;

    private final Integer build;

    private final String suffix;

    /**
     * Static factory method for a Version object. Pass the version to parse.
     *
     * @param version
     * @return the created version. Never returns <code>null</code>!
     *
     * @exception VersionFormatException
     * <ul>
     * <li>if passed version is null</li>
     * <li>if the passed version has an invalid format</li>
     * <li>if passed version is null</li>
     * </ul>
     */
    @PublishedMethod
    public static IVersion valueOf(String version) {
        if (version == null) {
            throw new VersionFormatException("The version is null. Major version number must be always available.");
        }
        try {
            final Integer[] n = new Integer[4];
            for (int i = 0; i < 4; ++i) {
                final int numDigits = getNumLeadingDigits(version);
                if (numDigits == 0) {
                    break; // no more digits found
                }
                final String number = version.substring(0, numDigits);
                n[i] = getInt(number);
                version = removePrefixAndOptionalSeparator(version, numDigits);
            }
            return new Version(n[0], n[1], n[2], n[3], version);

        } catch (final RuntimeException ex) {
            throw new VersionFormatException("The format of the version " + version + " is invalid.", ex);
        }

    }

    /**
     * Static factory method.
     *
     * @param major
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major) {
        return new Version(major, null, null, null, null);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param suffix
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, String suffix) {
        return new Version(major, null, null, null, suffix);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @return
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor) {
        return new Version(major, minor, null, null, null);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @param suffix
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor, String suffix) {
        return new Version(major, minor, null, null, suffix);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @param patchLevel
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor, int patchLevel) {
        return new Version(major, minor, patchLevel, null, null);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @param patchLevel
     * @param suffix
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor, int patchLevel, String suffix) {
        return new Version(major, minor, patchLevel, null, suffix);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @param patchLevel
     * @param build
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor, int patchLevel, int build) {
        return new Version(major, minor, patchLevel, build, null);
    }

    /**
     * Static factory method.
     *
     * @param major
     * @param minor
     * @param patchLevel
     * @param build
     * @param suffix
     * @return
     *
     * @throws VersionFormatException
     */
    @PublishedMethod
    public static IVersion valueOf(int major, int minor, int patchLevel, int build, String suffix) {
        return new Version(major, minor, patchLevel, build, suffix);
    }

    /**
     * Merges all values of the overlay version which are missing in the master version and returns the result.
     *
     * @param master
     * @param overlay
     * @return
     *
     *
     */
    @PublishedMethod
    public static IVersion merge(IVersion master, IVersion overlay) {
        final Integer mergedMajor = Integer.valueOf(master.getMajor()); // Always available
        Integer mergedMinor = null;
        Integer mergedPatchLevel = null;
        Integer mergedBuild = null;
        String mergedSuffix = null;

        // Get master values
        if (master.hasMinor()) {
            mergedMinor = Integer.valueOf(master.getMinor());
        }
        if (master.hasPatchLevel()) {
            mergedPatchLevel = Integer.valueOf(master.getPatchLevel());
        }
        if (master.hasBuild()) {
            mergedBuild = Integer.valueOf(master.getBuild());
        }
        if (master.hasSuffix()) {
            mergedSuffix = master.getSuffix();
        }

        // Overlay
        if (mergedMinor == null && overlay.hasMinor()) {
            mergedMinor = Integer.valueOf(overlay.getMinor());
        }
        if (mergedPatchLevel == null && overlay.hasPatchLevel()) {
            mergedPatchLevel = Integer.valueOf(overlay.getPatchLevel());
        }
        if (mergedBuild == null && overlay.hasBuild()) {
            mergedBuild = Integer.valueOf(overlay.getBuild());
        }
        if (mergedSuffix == null && overlay.hasSuffix()) {
            mergedSuffix = overlay.getSuffix();
        }

        return new Version(mergedMajor, mergedMinor, mergedPatchLevel, mergedBuild, mergedSuffix);
    }

    /**
     * Calculates the max version of both. If one version is <code>null</code>, the other one is returned.
     *
     * @param v1 (can be <code>null</code>)
     * @param v2 (can be <code>null</code>)
     * @return The max version or <code>null</code> if both are <code>null</code>
     */
    @KeepSecretFromPublishedApi
    public static IVersion max(IVersion v1, IVersion v2) {
        if (v1 == null) {
            return v2; // May return null here
        }
        if (v2 == null) {
            return v1;
        }
        if (v1.compareTo(v2) < 0) {
            return v2;
        }
        return v1;
    }

    /**
     * Calculates the min version of both. If one version is <code>null</code>, the other one is returned.
     *
     * @param v1 (can be <code>null</code>)
     * @param v2 (can be <code>null</code>)
     * @return The min version or <code>null</code> if both are <code>null</code>
     */
    @KeepSecretFromPublishedApi
    public static IVersion min(IVersion v1, IVersion v2) {
        if (v1 == null) {
            return v2; // May return null here
        }
        if (v2 == null) {
            return v1;
        }
        if (v1.compareTo(v2) > 0) {
            return v2;
        }
        return v1;
    }

    /**
     * Constructor.
     *
     * @param major
     * @param minor
     * @param patchLevel
     * @param build
     */
    private Version(Integer major, Integer minor, Integer patchLevel, Integer build, String suffix) {
        if (major == null) {
            throw new VersionFormatException("Major version number must be always available.");
        }
        guaranteeNotNegative("Major version", major);
        guaranteeNotNegative("Minor version", minor);
        guaranteeNotNegative("Patch level", patchLevel);
        guaranteeNotNegative("Build number", build);

        this.major = major;
        this.minor = minor;
        this.patchLevel = patchLevel;
        this.build = build;

        if (suffix == null || suffix.isEmpty()) {
            this.suffix = null;
        } else {
            this.suffix = suffix;
        }
    }

    private void guaranteeNotNegative(String name, Integer value) {
        if (value == null) {
            return;
        }
        if (value.intValue() < 0) {
            throw new VersionFormatException(name + " must be >= 0");
        }
    }

    private static String removePrefixAndOptionalSeparator(String s, int lengthPrefix) {
        if (s.length() <= lengthPrefix) {
            return "";
        }
        if (s.charAt(lengthPrefix) == '.') {
            ++lengthPrefix;
        }
        return s.substring(lengthPrefix);
    }

    /**
     * Returns the number of leading digits.
     *
     * @param version
     * @return
     */
    private static int getNumLeadingDigits(String version) {
        final int length = version.length();
        for (int i = 0; i < length; ++i) {
            final char c = version.charAt(i);
            if (!Character.isDigit(c)) {
                return i;
            }
        }
        return length;
    }

    private static Integer getInt(String n) {
        try {
            return Integer.valueOf(n);
        } catch (final NumberFormatException e) {
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int getMajor() {
        return major.intValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasMinor() {
        return minor != null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int getMinor() {
        if (minor == null) {
            return 0;
        }
        return minor.intValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasPatchLevel() {
        return patchLevel != null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int getPatchLevel() {
        if (patchLevel == null) {
            return 0;
        }
        return patchLevel.intValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasBuild() {
        return build != null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int getBuild() {
        if (build == null) {
            return 0;
        }
        return build.intValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasSuffix() {
        return suffix != null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getSuffix() {
        if (suffix == null) {
            return "";
        }
        return suffix;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int compareTo(IVersion other) {
        final Integer otherMajor = other.getMajor();
        if (major == null || otherMajor == null) {
            throw new VersionFormatException("Major version number must be available always");
        }
        int c = compareIntegers(major, otherMajor);
        if (c != 0) {
            return c;
        }
        c = compareIntegers(minor, other.getMinor());
        if (c != 0) {
            return c;
        }
        c = compareIntegers(patchLevel, other.getPatchLevel());
        if (c != 0) {
            return c;
        }
        c = compareIntegers(build, other.getBuild());
        if (c != 0) {
            return c;
        }
        return compareSuffixes(suffix, other.getSuffix());
    }

    /**
     * Compares the specified integer objects. Uses 0 as default if an object reference is <code>null</code>.
     *
     * @param myInteger
     * @param otherInteger
     * @return
     */
    private int compareIntegers(Integer myInteger, Integer otherInteger) {
        final int myValue = (myInteger == null ? 0 : myInteger.intValue());
        final int otherValue = (otherInteger == null ? 0 : otherInteger.intValue());
        if (myValue < otherValue) {
            return -1;
        }
        if (myValue > otherValue) {
            return 1;
        }
        return 0;
    }

    /**
     * Compares the specified string objects. Uses "" as default if an object reference is <code>null</code>.
     *
     * @param mySuffix
     * @param otherSuffix
     * @return
     */
    private int compareSuffixes(String mySuffix, String otherSuffix) {
        if (mySuffix == null) {
            mySuffix = "";
        }
        if (otherSuffix == null) {
            otherSuffix = "";
        }
        return mySuffix.compareTo(otherSuffix);
    }

    @PublishedMethod
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((build == null) ? 0 : build.hashCode());
        result = prime * result + ((major == null) ? 0 : major.hashCode());
        result = prime * result + ((minor == null) ? 0 : minor.hashCode());
        result = prime * result + ((patchLevel == null) ? 0 : patchLevel.hashCode());
        result = prime * result + ((suffix == null) ? 0 : suffix.hashCode());
        return result;
    }

    @PublishedMethod
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Version)) {
            return false;
        }
        final Version other = (Version) obj;

        if (compareIntegers(major, other.major) != 0) {
            return false;
        }
        if (compareIntegers(minor, other.minor) != 0) {
            return false;
        }
        if (compareIntegers(patchLevel, other.patchLevel) != 0) {
            return false;
        }
        if (compareIntegers(build, other.build) != 0) {
            return false;
        }
        return compareSuffixes(suffix, other.suffix) == 0;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        final StringBuilder s = new StringBuilder();
        s.append(major.toString());
        if (minor != null) {
            s.append('.');
            s.append(minor.toString());
            if (patchLevel != null) {
                s.append('.');
                s.append(patchLevel.toString());
                if (build != null) {
                    s.append('.');
                    s.append(build.toString());
                }
            }
        }
        if (suffix != null) {
            s.append(suffix);
        }
        return s.toString();
    }

}
