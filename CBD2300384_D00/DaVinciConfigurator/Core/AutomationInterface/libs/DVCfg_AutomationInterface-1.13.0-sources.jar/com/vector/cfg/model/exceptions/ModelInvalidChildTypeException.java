package com.vector.cfg.model.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * Thrown to indicate that a parent object doesn't have a specific child type.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelInvalidChildTypeException extends ModelInconsistencyException {

    private static final long serialVersionUID = 2934324340294625202L;

    private final MIObject parent;

    private final String childFeatureName;

    private final Class<? extends MIObject> type;

    @PublishedMethod
    public ModelInvalidChildTypeException(@Nonnull MIObject parent, @Nonnull String childFeatureName, @Nonnull Class<? extends MIObject> type) {
        super("'" + type.getName() + "' is not a child object type of feature '" + childFeatureName + "' below " + parent.getClass().getName());

        checkNotNull(parent, "parent is null");
        checkNotNull(childFeatureName, "childFeatureName is null");
        checkNotNull(type, "type is null");

        this.parent = parent;
        this.childFeatureName = childFeatureName;
        this.type = type;
    }

    @PublishedMethod
    public MIObject getParent() {
        return parent;
    }

    @PublishedMethod
    public String getChildFeatureName() {
        return childFeatureName;
    }

    @PublishedMethod
    public Class<? extends MIObject> getType() {
        return type;
    }

}
