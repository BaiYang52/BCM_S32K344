package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.ECompatibility;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ICommunicationElementAutoMapper"><!--Label:ICommunicationElementAutoMapper-->{@link ICommunicationElementAutoMapper} provides an Api to control and
 * evaluate the auto-data-mapping of communication elements to signal instances. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationElementAutoMapper {

    /**
     * <div class="extdoc" id="selectTargetSignalInstances"><!--Label:ICommunicationElementAutoMapper.selectTargetSignalInstances-->{@link #selectTargetSignalInstances(Closure)}
     * allows to define predicates to narrow down the target signal instances for the auto-mapping. The predicates are used to filter the possible target signal instances which
     * were computed from the communication element selection.</div>
     *
     * @param code The code to define predicates.
     */
    @PublishedMethod
    void selectTargetSignalInstances(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="evaluateMatches"><!--Label:ICommunicationElementAutoMapper.evaluateMatches-->{@link #evaluateMatches(Closure)} allows to evaluate and change the
     * results of the auto-mapping. It corresponds to the confirm page of the data mapping assistant.
     * <p>
     * For each communication element the provided closure is called: Parameters are the communication element, the optional matched target signal instance (or null), and a list
     * of all potential target signal instances (respecting the {@link #selectTargetSignalInstances(Closure)} predicates). The return value must be a signal instance or null.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the matches of the auto-mapping.
     *
     * @exception SelectionException when both {@link #evaluateMatches(Closure)} and {@link #evaluateMatchesWithCompatibility(Closure)} are called.
     */
    @PublishedMethod
    void evaluateMatches(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,java.util.List<com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance>") @Nonnull Closure<IAbstractSignalInstance> code);

    /**
     * <div class="extdoc" id=
     * "evaluateMatchesWithCompatibility"><!--Label:ICommunicationElementAutoMapper.evaluateMatchesWithCompatibility-->{@link #evaluateMatchesWithCompatibility(Closure)} allows
     * to evaluate and change the results of the auto-mapping. In contrast to {@link #evaluateMatches(Closure)} this method also provides the compatibility of the optional
     * match.
     * <p>
     * For each communication element the provided closure is called: Parameters are the communication element, the optional matched target signal instance (or null), the
     * compatibility of them and a list of all potential target signal instances (respecting the {@link #selectTargetSignalInstances(Closure)} predicates). The return value must
     * be a signal instance or null.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the matches of the auto-mapping using compatibility of the optional match.
     *
     * @exception SelectionException when both {@link #evaluateMatches(Closure)} and {@link #evaluateMatchesWithCompatibility(Closure)} are called.
     */
    @PublishedMethod
    void evaluateMatchesWithCompatibility(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,com.vector.cfg.model.sysdesc.api.com.ECompatibility,java.util.List<com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance>") @Nonnull Closure<IAbstractSignalInstance> code);

    /**
     * <div class="extdoc" id="confirmByCompatibility"><!--Label:ICommunicationElementAutoMapper.confirmByCompatibility-->{@link #confirmByCompatibility(Closure)} allows to
     * evaluate the mappings which should be created.
     * <p>
     * For each communication element the provided closure is called: Parameters are the communication element, the optional matched target signal instance (or null) and the
     * compatibility of them ({@link ECompatibility#NULL} if no optional match present) respecting all previous evaluations. So this is the final verifying step to confirm or
     * reject the mapping. The return value must be true if the mapping should be created or false if you want to reject the mapping.
     * </p>
     * </div>
     *
     * @param code The code to evaluate the mappings which decides which mapping should be accepted and which one not.
     */
    @PublishedMethod
    void confirmByCompatibility(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.dom.runtimesys.api.com.ICommunicationElement,com.vector.cfg.dom.runtimesys.api.com.IAbstractSignalInstance,com.vector.cfg.model.sysdesc.api.com.ECompatibility") @Nonnull Closure<Boolean> code);

    /**
     * <div class="extdoc" id="expandNestedArraysOfPrimitive">
     * <h5>Nested Array of Primitives</h5><!--Label:sec:ICommunicationElementAutoMapper_expandNestedArraysOfPrimitive--> {@link #expandNestedArraysOfPrimitive(boolean)} allows
     * to control the expansion of nested arrays of primitive globally. Per default, arrays are fully expanded (allowing to data map each array element). By setting the value to
     * 'false', all nested arrays of primitive are not expanded and can be directly data-mapped to a signal. </div>
     *
     * @param expand
     */
    @PublishedMethod
    void expandNestedArraysOfPrimitive(boolean expand);

    /**
     * <div class="extdoc" id="expandNestedArraysOfPrimitiveFullyQualified"> {@link #expandNestedArraysOfPrimitive(String,boolean)} allows to control the expansion of nested
     * arrays of primitive for single nested arrays. Per default, the {@link #expandNestedArraysOfPrimitive(boolean)} applies. For the given fully qualified communication
     * element name, the global setting can be overridden.
     * <p>
     * The fully qualified communication element name is e.g. determinable when using the data mapping assistant, performing an arbitrary signal group mapping of the root data
     * element, and using the right-mouse menu its 'Copy fully qualified name' action on the nested array element.
     * </p>
     * </div>
     *
     * @param fullyQualifiedComElementName
     * @param expand
     */
    @PublishedMethod
    void expandNestedArraysOfPrimitive(String fullyQualifiedComElementName, boolean expand);

    @KeepSecretFromPublishedApi
    Optional<Closure<?>> getSelectTargetSignalsCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<IAbstractSignalInstance>> getEvaluateMatchesCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<IAbstractSignalInstance>> getEvaluateMatchesWithCompatibilityCode();

    @KeepSecretFromPublishedApi
    Optional<Closure<Boolean>> getConfirmByCompatibilityCode();

}
