package com.vector.cfg.workflow.groovy.update.result;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.workflow.groovy.update.project.IFilePreprocessingProjectApi;

/**
 * Reports the result of the file preprocessing after it was executed with the {@link IFilePreprocessingProjectApi}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IFilePreprocessingResult {

    /**
     * Returns the resulting System Extract that was created in the file preprocessing.
     *
     * @return Path to the result System Extract or {@code null} if no result is available.
     */
    @PublishedMethod
    @Nullable
    IPersistablePath getSystemExtractResult();

    /**
     * Returns the resulting Diagnostic Ecuc that was created in the file preprocessing.
     *
     * @return Path to the result Diagnostic Ecuc or {@code null} if no result is available.
     */
    @PublishedMethod
    @Nullable
    IPersistablePath getDiagnosticEcucExportResult();
}
