/**
 * <div class="extdoc" id="solvingactions" data-use-qualified-path="true"> If the solution for an inconsistency is more complex, you can implement a SA on your own, but if the
 * solution is just a single basic model operation, there are generic SAs that you can use in the package {@link com.vector.cfg.consistency.contribution.helper.solvingactions}.
 * <p>
 * Some can be constructed with the <code>new</code> operator:
 * <ul>
 * <li>{@link SACreateContainer}</li>
 * <li>{@link SACreateParameter}</li>
 * <li>{@link SACreateParameterOnce}</li>
 * <li>{@link SetMaximumValue}</li>
 * <li>{@link SetDefaultValue}</li>
 * <li>{@link SetMinimumValue}</li>
 * <li>{@link SADeleteMDFObject}</li>
 * <li>{@link SASetBoolean}</li>
 * <li>{@link SASetFloat}</li>
 * <li>{@link SASetInteger}</li>
 * <li>{@link SASetReference}</li>
 * <li>{@link SASetTextual}</li>
 * </ul>
 * </p>
 * <p>
 * Some are created using the project service {@link ISolvingActionFactory}
 * <ul>
 * <li>{@link ISolvingActionFactory#setBoolean(MIContainer, DefRef, Boolean)}</li>
 * <li>{@link ISolvingActionFactory#setFloat(MIContainer, DefRef, double)}</li>
 * <li>{@link ISolvingActionFactory#setInteger(MIContainer, DefRef, long)}</li>
 * <li>{@link ISolvingActionFactory#setReference(MIContainer, DefRef, MIReferrable)}</li>
 * <li>{@link ISolvingActionFactory#setTextual(MIContainer, DefRef, String)}</li>
 * </ul>
 * and some are created using static methods:
 *
 * <ul>
 * <li>{@link SetDefaultValue#create(MIParameterValue)}</li>
 * <li>{@link SetMaximumValue#create(MIParameterValue)}</li>
 * <li>{@link SetMinimumValue#create(MIParameterValue)}</li>
 * </ul>
 * </p>
 * <p>
 * The class {@link SolvingActions} contains methods to combine independent SAs to a single SA.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.consistency.contribution.helper.solvingactions;