package com.vector.cfg.model.operations;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.exceptions.InconsistentParentDefinitionException;
import com.vector.cfg.model.exceptions.InvalidShortnameException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.exceptions.ModelDefinitionNotFoundException;
import com.vector.cfg.model.exceptions.ModelInconsistencyException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.base.MIARPackage;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;

/**
 * <div class="extdoc" id="Common">
 * <h2>IModelOperationsPublished</h2> {@link IModelOperationsPublished} is a project service which provides some basic and often used model change operations.
 *
 * <p>
 * <b>Important remark:</b> All operations implemented in this service must run within a unit of work. The client code is responsible for opening this transaction before calling
 * the model operation.
 * </p>
 *
 * <h3>Deleting objects</h3>
 *
 * Deleting model objects is <b>only</b> permitted with the following service method: {@link #deleteFromModel(MIObject)}
 *
 * Deleting objects with other means leads to a runtime exception and cancels the currently running model change transaction! <!--Latex:\ifClassicDoc-->
 * <h3>Pre-configuration, recommended and initial values</h3>
 *
 * <ul>
 * <li>{@link #resetToPreConfigValues(MIModuleConfiguration)}: Overwrites all parameter values in this module configuration with their pre-configuration value. Only parameters,
 * which are mentioned in the pre-configuration, are affected. This method also creates containers which are contained in the pre-configuration but not in the active ECUC
 * <li><code>resetToRecommendedValues(*)</code>: Overwrites all parameter values with their recommended or default value. Only parameters, which have recommended or default
 * values are affected
 * <li><code>resetToInitialValues(*)</code>: Overwrites all parameter values with their initial (derived) value. Only parameters, which have a initial value are affected
 * </ul>
 *
 *
 * <h3>Creating containers and parameters</h3>
 *
 * <ul>
 * <li>{@link #createParameterByDefinition(MIContainer,String)}: Creates a new parameter below the specified parent container. This method also assigns recommended or default
 * values if available. If both exists, the recommended value has the higher priority.
 * <li>{@link #createContainerByDefinitionWithoutChildren(MIHasContainer,String,String)}: Creates a new container with this definition and shortname below the specified parent.
 * This method also creates all sub-containers and parameters with lower multiplicity >= 1 (recursively)
 * </ul>
 *
 *
 * <h3>Cloning containers and parameters</h3>
 *
 * <ul>
 * <li>{@link #deepCloneMDFObject(MIObject,MIObject)}: Clones a parameter or a complete container tree and adds it below the specified destination parent
 * </ul>
 *
 * <h3>Activating or deleting module configurations</h3>
 *
 * <ul>
 * <li><code>activateModuleConfiguration(...)</code>: Activates a new module configuration instance</li>
 * <li>{@link #deleteModuleConfiguration(MIModuleConfiguration)}: Deletes a module configuration instance</li>
 * <li>{@link #deleteModuleConfigurations(MIModuleConfiguration[])}: Deletes several module configuration instances</li>
 * </ul>
 * <!--Latex:\fi--> </div>
 *
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IModelOperationsPublished {

    /**
     * Creates a new container below the specified parent. This method also creates all sub-containers and parameters with lower multiplicity >= 1 (recursively).
     *
     * If the specified shortname is <code>null</code> or empty, {@link #createContainerByDefinition(MIHasContainer, String)} will be called.
     *
     * @param parent - of the new container
     * @param def - definition path of the new container which is either an absolute AUTOSAR path or just the last short-name of its definition
     * @param shortname - short-name of the new container
     * @return The created container instance (never returns <code>null</code>)
     * @throws ModelCeHasNoDefinitionException if the parent has no definition
     * @throws ModelDefinitionNotFoundException if the child definition doesn't exist
     * @throws InconsistentParentDefinitionException if the child definition is not a child of the parent definition
     * @throws InvalidShortnameException if the shortname is invalid
     */
    @PublishedMethod
    MIContainer createContainerByDefinition(MIHasContainer parent, String def, String shortname);

    /**
     * This is a convenience wrapper for {@link #createContainerByDefinition(MIHasContainer, String, String)}. It uses the last shortname of the definition path as shortname for
     * the container. If this shortname already exists it calls {@link IReferrableAccess#getValidShortname(com.vector.cfg.model.mdf.commoncore. autosar.MIARObject, String, 3)}
     * to create a valid one.
     *
     * @param parent
     * @param def
     * @return
     */
    @PublishedMethod
    MIContainer createContainerByDefinition(MIHasContainer parent, String def);

    /**
     * Overloaded variant of {@link #createContainerByDefinition(MIHasContainer, String, String)}.
     *
     * If the specified shortname is <code>null</code> or empty, {@link #createContainerByDefinition(MIHasContainer, DefRef, String)} will be called.
     *
     * @param parent
     * @param def
     * @param shortname
     * @return
     */
    @PublishedMethod
    MIContainer createContainerByDefinition(MIHasContainer parent, DefRef def, String shortname);

    /**
     * This is a convenience wrapper for {@link #createContainerByDefinition(MIHasContainer, DefRef, String)}. It uses the last shortname of the definition path as shortname for
     * the container. If this shortname already exists it calls {@link IReferrableAccess#getValidShortname(com.vector.cfg.model.mdf.commoncore. autosar.MIARObject, String, 3)}
     * to create a valid one.
     *
     * @param parent
     * @param def
     * @return
     */
    @PublishedMethod
    MIContainer createContainerByDefinition(MIHasContainer parent, DefRef def);

    /**
     * Implements the same semantic as {@link #createContainerByDefinition(MIHasContainer, String, String)} but without creating sub-containers and parameters.
     *
     * @param parent
     * @param def
     * @param shortname
     * @return
     * @throws ModelCeHasNoDefinitionException if the parent has no definition
     * @throws ModelDefinitionNotFoundException if the child definition doesn't exist
     * @throws InconsistentParentDefinitionException if the child definition is not a child of the parent definition
     * @throws InvalidShortnameException if the shortname is invalid
     */
    @PublishedMethod
    MIContainer createContainerByDefinitionWithoutChildren(MIHasContainer parent, String def, String shortname);

    /**
     * Overloaded variant of {@link #createContainerByDefinitionWithoutChildren(MIHasContainer, String, String)} .
     *
     * @param parent
     * @param def
     * @param shortname
     * @return
     */
    @PublishedMethod
    MIContainer createContainerByDefinitionWithoutChildren(MIHasContainer parent, DefRef def, String shortname);

    /**
     * Creates a new parameter below the specified parent container. This method also assigns recommended or default values if available. If both exists, the recommended value
     * has the higher priority.
     *
     * @param parent - of the new parameter
     * @param def - definition path of the new parameter which is either an absolute AUTOSAR path or just the last short-name of its definition
     * @return The created parameter instance (never returns <code>null</code>)
     * @throws ModelCeHasNoDefinitionException if the parent has no definition
     * @throws ModelDefinitionNotFoundException if the child definition doesn't exist
     * @throws InconsistentParentDefinitionException if the child definition is not a child of the parent definition
     */
    @PublishedMethod
    MIParameterValue createParameterByDefinition(MIContainer parent, String def);

    /**
     * Overloaded variant of {@link #createParameterByDefinition(MIContainer, String)}.
     *
     * @param parent
     * @param def
     * @return
     */
    @PublishedMethod
    MIParameterValue createParameterByDefinition(MIContainer parent, DefRef def);

    /**
     * Clones the value content of the specified source parameter to the destination parameter. Be aware that this method doesn't clone the definition reference. It also doesn't
     * clone other content of the parameter (index attribute, annotations, ...). Both specified objects must already exist.
     *
     * @param src
     * @param dest
     * @throws ModelInconsistencyException in case of errors (e.g. if the parameters have different types or definitions)
     */
    @PublishedMethod
    void cloneParameterValue(MIParameterValue src, MIParameterValue dest);

    /**
     * Clones the definition reference of the specified source object to the destination object. Both specified objects must already exist.
     *
     *
     * @param src
     * @param dest
     */
    @PublishedMethod
    void cloneDefinition(MIHasDefinition src, MIHasDefinition dest);

    /**
     * Clones {@link MIObject} with all children.<br>
     * Valid source objects are {@link MIContainer}, {@link MIParameterValue}.<br>
     *
     * <b>Clone {@link MIModuleConfiguration} is not supported!!</b><br>
     * <br>
     * Returns null if type is not supported.
     *
     * @param source is the object to be cloned (ECUC parameter or container)
     * @param destinationParent (is the parent object, the new clone is being added to)
     */
    @PublishedMethod
    MIObject deepCloneMDFObject(MIObject source, MIObject destinationParent);

    /**
     * Deletes the specified object from the model. <br>
     * <br>
     * <b>Inside UnitOfWork:</b><br>
     * Checks via CeState whether the object is deletable or not.<br>
     *
     * @throws IllegalStateException if object can not be deleted.
     *
     * @param obj is the object to be deleted
     */
    @PublishedMethod
    void deleteFromModel(MIObject obj);

    /**
     * Overwrites all parameter values in this module configuration with their pre-configuration value. Only parameters, which are mentioned in the pre-configuration, are
     * affected.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void resetToPreConfigValues(MIModuleConfiguration moduleConfig);

    /**
     * Resets all parameters which have recommended or default values defined.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void resetToRecommendedValues(MIModuleConfiguration moduleConfig);

    /**
     * Resets all parameters which have initial values defined.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void resetToInitialValues(MIModuleConfiguration moduleConfig);

    /**
     * Resets all parameters which have recommended or default values defined.
     *
     * @param container
     */
    @PublishedMethod
    void resetToRecommendedValues(MIContainer container);

    /**
     * Resets all parameters which have initial values defined.
     *
     * @param container
     */
    @PublishedMethod
    void resetToInitialValues(MIContainer container);

    /**
     * Resets the specified parameter if it has a recommended or default value defined.
     *
     * @param parameter
     */
    @PublishedMethod
    void resetToRecommendedValue(MIParameterValue parameter);

    /**
     * Resets the specified parameter if it has a initial value defined.
     *
     * @param parameter
     */
    @PublishedMethod
    void resetToInitialValue(MIParameterValue parameter);

    /**
     * Creates a new module configuration based on the specified BSW-implementation and adds it to the active ECUC. In case of a split configuration, a new persistency location
     * is being created and added to the project settings.
     *
     * @param arPackage is the AUTOSAR package, the new module configuration shall be added to
     * @param shortname is the name of the new module configuration
     * @param bswImpl is the BSW-implementation of the new module configuration
     */
    @PublishedMethod
    void activateModuleConfiguration(MIARPackage arPackage, String shortname, MIBswImplementation bswImpl);

    /**
     * Creates a new module configuration based on the specified module definition and adds it to the active ECUC. In case of a split configuration, a new persistency location
     * is being created and added to the project settings.
     *
     * Use this method for creating module configurations were no BSW-implementation is available for, e.g. for AUTOSAR standard module definitions.
     *
     * @param arPackage
     * @param shortname
     * @param moduleDef
     */
    @PublishedMethod
    void activateModuleConfiguration(MIARPackage arPackage, String shortname, MIModuleDef moduleDef);

    /**
     * Overloaded variant of {@link #activateModuleConfigurationOld(MIARPackage, String, MIBswImplementation)} .
     *
     * This method uses the parent package of the active-ECUC as default to create the new module configuration below.
     *
     * @param shortname
     * @param bswImpl
     */
    @PublishedMethod
    void activateModuleConfiguration(String shortname, MIBswImplementation bswImpl);

    /**
     * Overloaded variant of {@link #activateModuleConfigurationOld(MIARPackage, String, MIModuleDef)}.
     *
     * This method uses the parent package of the active-ECUC as default to create the new module configuration below.
     *
     * @param shortname
     * @param bswImpl
     */
    @PublishedMethod
    void activateModuleConfiguration(String shortname, MIModuleDef moduleDef);

    /**
     * Changes the name of given module configuration. Considers possible issues with preconfigured reference values.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void renameModuleConfiguration(MIModuleConfiguration moduleConfig, String newModuleConfigName);

    /**
     * Deletes the specified module configuration from the model. In case of a split configuration, the related persistency location is being removed from the project settings.
     * In XML file base configurations, the related file is being deleted during the next project save if it doesn't contain configuration objects anymore.
     *
     * If the module configuration is referenced from the active-ECUC this link is being removed too.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void deleteModuleConfiguration(MIModuleConfiguration moduleConfig);

    /**
     * Deletes the specified module configurations from the model. In case of a split configuration, the related persistency location is being removed from the project settings.
     * In XML file base configurations, the related file is being deleted during the next project save if it doesn't contain configuration objects anymore.
     *
     * If a module configuration is referenced from the active-ECUC this link is being removed too.
     *
     * @param moduleConfig
     */
    @PublishedMethod
    void deleteModuleConfigurations(MIModuleConfiguration[] moduleConfigs);

    /**
     * Changes the bsw-implementation of the specified module configuration.
     *
     * @param moduleConfig
     * @param bswImpl
     */
    @PublishedMethod
    void changeImplementation(MIModuleConfiguration moduleConfig, MIBswImplementation bswImpl);

    /**
     * Searches all modules with standard AUTOSAR definitions and replaces them with BSW-implementations if they are refined unambiguously.
     *
     *
     */
    @PublishedMethod
    void replaceUnambiguouslyRefinedAutosarDefinitions();

}