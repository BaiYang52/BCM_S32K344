package com.vector.cfg.dom.modemgt.groovy.api;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.modemgt.groovy.bswm.BswMAutoConfigException;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationApi;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationDomain;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationFeature;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IModeManagementApi} provides high convenience support for mode management related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IModeManagementApi {

    /**
     * {@link #bswMAutoConfig(String, Closure)} provides access to the BswM auto configuration API.
     * <div class="extdoc" id="bswMAutoConfig"><!--Label:IModeManagementApi.bswMAutoConfig-->
     * <h5>Executing the BswM Auto Configuration</h5>{@link IModeManagementApi#bswMAutoConfig(String, Closure)} delegates the given code to the {@link IBswMAutoConfigurationApi}
     * of the given BswM auto configuration domain. Also see overload {@link #bswMAutoConfig(MIContainer, String, Closure)} for using this API in multi partition use case.</div>
     *
     * <p>
     * The method will open an <code>ITransaction</code> if one isn't already running.
     * </p>
     *
     * @param bswMAutoCfgDomainId the identifier of the BswM auto configuration domain (e.g. "ECU State Handling", "Communication Control", ...)
     * @param code the code configuring the given BswM auto configuration domain via the appropriate {@link IBswMAutoConfigurationApi}
     * @return the result calculated by the given code
     * @throws BswMAutoConfigException
     * <ul>
     * <li>if no matching BswM generator is part of the current SIP</li>
     * <li>if the auto configuration fails</li>
     * <li>if there are zero or more than one {@code BswMConfig} containers (e.g. in multi partition use case, use {@link #bswMAutoConfig(MIContainer, String, Closure)} in this
     * case)</li>
     * </ul>
     */
    @PublishedMethod
    <T> T bswMAutoConfig(String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationApi.class) Closure<T> code);

    /**
     * Overload of {@link #bswMAutoConfig(String, Closure)} for multi partition use case. This method also works fine in single partition use case.
     *
     * @param bswMConfig the {@code BswMConfig} container on which to perform the auto configuration
     * @param bswMAutoCfgDomainId the identifier of the BswM auto configuration domain (e.g. "ECU State Handling", "Communication Control", ...)
     * @param code the code configuring the given BswM auto configuration domain via the appropriate {@link IBswMAutoConfigurationApi}
     * @return the result calculated by the given code
     * @throws NullPointerException if the given {@code BswMConfig} container is {@code null}
     */
    @PublishedMethod
    <T> T bswMAutoConfig(MIContainer bswMConfig, String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationApi.class) Closure<T> code);

    /**
     * {@link #getBswMAutoConfigDomains()} provides read-access to all available BswM auto configuration domains.
     * <div class="extdoc" id="getBswMAutoConfigDomains"><!--Label:IModeManagementApi.getBswMAutoConfigDomains-->
     * <h5>Inspecting BswM Auto Configuration Domains</h5> The {@link #getBswMAutoConfigDomains()} method of the {@link IModeManagementApi} interface provides read-access to all
     * available BswM auto configuration domains. Available features and parameters can be inspected for various properties. See javadoc of {@link IBswMAutoConfigurationDomain},
     * {@link IBswMAutoConfigurationFeature} and {@link IBswMAutoConfigurationParameter} for details. Also see overload {@link #getBswMAutoConfigDomains(MIContainer)} for using
     * this API in multi partition use case.</div>
     *
     * @return read-access to all available BswM auto configuration domains
     * @throws BswMAutoConfigException if there are zero or more than one {@code BswMConfig} containers (e.g. in multi partition use case, use
     * {@link #getBswMAutoConfigDomains(MIContainer)} in this case)
     */
    @PublishedMethod
    List<IBswMAutoConfigurationDomain> getBswMAutoConfigDomains();

    /**
     * Overload of {@link #getBswMAutoConfigDomains()} for multi partition use case. This method also works fine in single partition use case.
     *
     * @param bswMConfig the {@code BswMConfig} container for whose BswM auto configuration domains to get read-access for
     * @return read-access to all available BswM auto configuration domains
     * @throws NullPointerException if the given {@code BswMConfig} container is {@code null}
     */
    @PublishedMethod
    List<IBswMAutoConfigurationDomain> getBswMAutoConfigDomains(MIContainer bswMConfig);

    /**
     * Convenience access to an {@link IBswMAutoConfigurationDomain} with a given identifier. See overload {@link #bswMAutoConfigDomain(MIContainer, String)} for using this API
     * in multi partition use case.
     *
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @return the {@link IBswMAutoConfigurationDomain} with the given identifier
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     * @throws BswMAutoConfigException if there are zero or more than one {@code BswMConfig} containers (e.g. in multi partition use case, use
     * {@link #bswMAutoConfigDomain(MIContainer, String)} in this case)
     */
    @PublishedMethod
    IBswMAutoConfigurationDomain bswMAutoConfigDomain(String bswMAutoCfgDomainId);

    /**
     * Overload of {@link #bswMAutoConfigDomain(String)} for multi partition use case. This method also works fine in single partition use case.
     *
     * @param bswMConfig the {@code BswMConfig} container whose {@link IBswMAutoConfigurationDomain} to get
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @return the {@link IBswMAutoConfigurationDomain} with the given identifier
     * @throws NullPointerException if the given {@code BswMConfig} container is {@code null}
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     */
    @PublishedMethod
    IBswMAutoConfigurationDomain bswMAutoConfigDomain(MIContainer bswMConfig, String bswMAutoCfgDomainId);

    /**
     * Convenience access to an {@link IBswMAutoConfigurationDomain} with a given identifier.
     *
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @param code the code inspecting the corresponding {@link IBswMAutoConfigurationDomain}
     * @return the result calculated by the given code
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     * @throws BswMAutoConfigException if there are zero or more than one {@code BswMConfig} containers (e.g. in multi partition use case, use
     * {@link #bswMAutoConfigDomain(MIContainer, String, Closure)} in this case)
     */
    @PublishedMethod
    <T> T bswMAutoConfigDomain(String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationDomain.class) Closure<T> code);

    /**
     * Overload of {@link #bswMAutoConfigDomain(String, Closure)} for multi partition use case. This method also works fine in single parition use case.
     *
     * @param bswMConfig the {@code BswMConfig} container on whose {@link IBswMAutoConfigurationDomain} to execute the given code
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @param code the code inspecting the corresponding {@link IBswMAutoConfigurationDomain}
     * @return the result calculated by the given code
     * @throws NullPointerException if the given {@code BswMConfig} container is {@code null}
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     */
    @PublishedMethod
    <T> T bswMAutoConfigDomain(MIContainer bswMConfig, String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationDomain.class) Closure<T> code);

}
