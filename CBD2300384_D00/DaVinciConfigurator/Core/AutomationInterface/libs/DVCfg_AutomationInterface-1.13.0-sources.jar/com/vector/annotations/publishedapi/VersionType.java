package com.vector.annotations.publishedapi;

/**
 * VersionType specifies if the annotated field with {@link PublishedApiVersionInfo} is a Version or a VersionRange.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 * @see PublishedApiVersionInfo
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
// @CHECKSTYLE:OFF Is an Enum for Annotations, and also PublishedAPI, so the name is not changeable.
public enum VersionType {
    // @CHECKSTYLE:ON
    VERSION,
    VERSION_RANGE;
}
