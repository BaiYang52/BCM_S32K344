package com.vector.cfg.consistency.groovy.api;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

/**
 * The {@link IValidationApi} provides access to all validation (validation view, consistency) related functions, to retrieve validation-results and solve soling-actions. The
 * {@link IValidationApi} instance can be retrieved with the {@link IValidationApiEntryPoint}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IValidationApi {
    /**
     * <div class="extdoc" id="getValidationResultsIntro"> {@link #getValidationResults()} waits for background-validation-idle and returns all validation-results of any kind.
     * The returned collection has no deterministic order, especially it is not the same order as in the GUI. </div>
     * <p/>
     * This method returns live results, on-demand (generation) results, consistency-runtime-error results and any other kind of results that may be defined in the future.
     * <p/>
     * This method waits for the live-background validation to be idle in order to have reproducible results. If this is not wanted for some reason, e.g. it is known that a
     * particular result is already created and published, {@link #getValidationResultsNow()} can be used.
     *
     * @return the validation results
     */
    @PublishedMethod
    Collection<IValidationResultUI> getValidationResults();

    /**
     * Returns all validation-results of any kind.
     * <p/>
     * This method is similar to {@link #getValidationResults()} except that it does not wait for background-validation-idle, and hence some results may or may not be already in
     * the returned collection, depending on the kind, validator-configuration, timing,... Use this method only if you know these details.
     *
     *
     * @return the validation results
     */
    @PublishedMethod
    Collection<IValidationResultUI> getValidationResultsNow();

    /**
     * <div class="extdoc" id="getSolver"> {@link #getSolver()} gives access to the {@link ISolver} API, which has advanced methods for bulk solutions.</div>
     *
     * @return the solver
     */
    @PublishedMethod
    ISolver getSolver();

    /**
     * Returns the {@link IValidationResultCreationApi} to create {@link IValidationResult} in script task, which provide a resultSink.
     *
     * <p>
     * Note: this is only possible during script task execution, and when the script task provides a resultSink.
     * </p>
     *
     * @return the result creation API
     * @see IValidationResultCreationApi
     */
    @PublishedMethod
    IValidationResultCreationApi getResultCreation();

    /**
     * Activates the {@link IValidationResultCreationApi} to create {@link IValidationResult} in script task, which provide a resultSink.
     *
     * <p>
     * Note: this is only possible during script task execution, and when the script task provides a resultSink.
     * </p>
     *
     * @param code code to execute with the result creation API
     * @see IValidationResultCreationApi
     */
    @PublishedMethod
    void resultCreation(@VDelegatesToWithClosureParam(IValidationResultCreationApi.class) Closure<?> code);

    /**
     * Get the {@link ISettings} interface.
     *
     * @return the settings
     */
    @PublishedMethod
    ISettings getSettings();

    /**
     * Calls the passed {@link Closure} with {@link DelegatesTo} {@link ISettings}.
     *
     * @param code the closure
     */
    @PublishedMethod
    void settings(@VDelegatesToWithClosureParam(ISettings.class) Closure<?> code);
}
