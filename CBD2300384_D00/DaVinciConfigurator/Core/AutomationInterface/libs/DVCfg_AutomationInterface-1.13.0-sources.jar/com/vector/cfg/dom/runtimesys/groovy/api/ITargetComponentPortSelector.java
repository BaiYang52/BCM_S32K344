package com.vector.cfg.dom.runtimesys.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * <div class="extdoc" id="ITargetComponentPortSelector"><!--Label:ITargetComponentPortSelector-->The {@link ITargetComponentPortSelector} Api allows the definition of
 * predicates for target component port selection. it mainly consists of the {@link IComponentPortSelector} Api but has enhancements for selecting target component ports for
 * auto-mapping of ports.
 * <p>
 * The predicates are combined via logical AND. To realize other combinations, use the {@link IComponentPortSelector#or}, {@link IComponentPortSelector#not} and
 * {@link IComponentPortSelector#and} predicates.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITargetComponentPortSelector extends IComponentPortSelector {

}
