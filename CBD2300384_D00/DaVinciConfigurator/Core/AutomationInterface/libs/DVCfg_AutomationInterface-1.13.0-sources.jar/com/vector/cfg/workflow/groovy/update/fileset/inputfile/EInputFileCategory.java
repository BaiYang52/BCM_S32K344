package com.vector.cfg.workflow.groovy.update.fileset.inputfile;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 *
 * Wrapper enum for the workflow internal {@link com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory}.
 *
 * <div class="extdoc" id="fileCategories"> Following input file categories are generally available. (To retrieve all available file categories for a specific input file, use
 * {@link IInputFileApi#getAvailableFileCategories()} <br>
 * <ul>
 * <li>{@link EInputFileCategory.LEGACY_DIAGNOSTIC_DATA}</li>
 * <li>{@link EInputFileCategory.LEGACY_DIAGNOSTIC_STATE_DESCRIPTION}</li>
 * <li>{@link EInputFileCategory.LEGACY_DIAGNOSTIC_PATCH_FILE}</li>
 * <li>{@link EInputFileCategory.LEGACY_COMMUNICATION_DATA}</li>
 * <li>{@link EInputFileCategory.LEGACY_COMMUNICATION_MODIFICATION_SCRIPT}</li>
 * <li>{@link EInputFileCategory.PROJECT_STANDARD_CONFIGURATION}</li>
 * <li>{@link EInputFileCategory.DEFINITION_RESTRICTIONS}</li>
 * <li>{@link EInputFileCategory.DIAGNOSTIC_COMMON_DATA}</li>
 * <li>{@link EInputFileCategory.DIAGNOSTIC_SYSTEM_EXTRACT}</li>
 * <li>{@link EInputFileCategory.DIAGNOSTIC_SYSTEM_DESCRIPTION}</li>
 * <li>{@link EInputFileCategory.COMMUNICATION_SYSTEM_EXTRACT}</li>
 * <li>{@link EInputFileCategory.COMMUNICATION_SYSTEM_DESCRIPTION}</li>
 * <li>{@link EInputFileCategory.AUTOSAR_COMPLEMENTARY_DATA}</li>
 * </ul>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EInputFileCategory {

    /**
     * Legacy diagnostic data file, e.g. *.cdd, *.odx or a *.pdx files.
     */
    LEGACY_DIAGNOSTIC_DATA(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.LEGACY_DIAGNOSTIC_DATA),

    /**
     * Legacy diagnostic state description file, e.g. *.csv files.
     */
    LEGACY_DIAGNOSTIC_STATE_DESCRIPTION(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.LEGACY_DIAGNOSTIC_STATE_DESCRIPTION),

    /**
     * Legacy diagnostic patch file, e.g. *.data files.
     */
    LEGACY_DIAGNOSTIC_PATCH_FILE(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.LEGACY_DIAGNOSTIC_PATCH_FILE),

    /**
     * Legacy communication data file, e.g. *.dbc, *.ldf, *.xml files.
     */
    LEGACY_COMMUNICATION_DATA(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.LEGACY_COMMUNICATION_DATA),

    /**
     * Legacy converter communication modification script file, e.g. *.vsde files.
     */
    LEGACY_COMMUNICATION_MODIFICATION_SCRIPT(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.LEGACY_COMMUNICATION_MODIFICATION_SCRIPT),

    /**
     * Project Standard COnfiguration file.
     */
    PROJECT_STANDARD_CONFIGURATION(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.PROJECT_STANDARD_CONFIGURATION),

    /**
     * BSW definition restriction file.
     */
    DEFINITION_RESTRICTIONS(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.DEFINITION_RESTRICTIONS),

    /**
     * Diagnostic common data file.
     */
    DIAGNOSTIC_COMMON_DATA(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.DIAGNOSTIC_COMMON_DATA),

    /**
     * Diagnostic System Extract file.
     */
    DIAGNOSTIC_SYSTEM_EXTRACT(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.DIAGNOSTIC_SYSTEM_EXTRACT),

    /**
     * Diagnostic System Description file.
     */
    DIAGNOSTIC_SYSTEM_DESCRIPTION(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.DIAGNOSTIC_SYSTEM_DESCRIPTION),

    /**
     * Communication System Extract file.
     */
    COMMUNICATION_SYSTEM_EXTRACT(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.COMMUNICATION_SYSTEM_EXTRACT),

    /**
     * Communication System Description file.
     */
    COMMUNICATION_SYSTEM_DESCRIPTION(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.COMMUNICATION_SYSTEM_DESCRIPTION),

    /**
     * Complementary AUTOSAR *.arxml file with non-specific content.
     */
    AUTOSAR_COMPLEMENTARY_DATA(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory.AUTOSAR_COMPLEMENTARY_DATA);

    private final com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory value;

    EInputFileCategory(com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory value) {
        this.value = value;
    }

    /**
     * @returns the Value of enum literal.
     */
    @KeepSecretFromPublishedApi
    public com.vector.cfg.workflow.update.api.configuration.inputfiles.EInputFileCategory getValue() {
        return value;
    }

}
