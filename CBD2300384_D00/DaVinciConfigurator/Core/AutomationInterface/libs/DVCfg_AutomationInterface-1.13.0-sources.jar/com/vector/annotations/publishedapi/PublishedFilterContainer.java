package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@link PublishedFilterContainer} is the container for {@link PublishedFilter} annotations to allow {@link Repeatable} usage. See {@link PublishedFilter} for details.
 *
 *
 * <p>
 * The {@link PublishedFilterContainer} annotation <b>shall not be used by clients</b> using the published API. This is only for the export and tracking of the published API. So
 * a client shall not annotate any class or interface with the {@link PublishedApi} annotation.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @see PublishedFilter
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.TYPE, ElementType.FIELD })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedFilterContainer {

    /**
     * the multiple values of {@link PublishedFilter}.
     *
     * @return the published filter
     */
    PublishedFilter[] value();
}
