package com.vector.cfg.project.evs.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common">The mode type gives the option to setup variants and their values by hand or when auto mode is used, the values will be created
 * automatically.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IModeTypeApi {

    /**
     * <div class="extdoc" id="mode">Use {@link #autoMode(Closure)} this mode if the project needs only a simple variant handling. The {@link #autoMode(Closure)} creates one
     * COMMUNICATION criterion and adds a value for the given variant automatically. Can be used if only one variant criterion is needed.</div>
     *
     * @param code code providing the simple mode of variants.
     */
    @PublishedMethod
    <T> T autoMode(@VDelegatesToWithClosureParam(IAutoModeApi.class) Closure<T> code);

}
