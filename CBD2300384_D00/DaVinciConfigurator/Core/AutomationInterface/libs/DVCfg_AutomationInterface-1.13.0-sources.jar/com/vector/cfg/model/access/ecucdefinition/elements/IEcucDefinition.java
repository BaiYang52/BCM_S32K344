package com.vector.cfg.model.access.ecucdefinition.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucScopeEnum;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucDefinition {

    /**
     * Returns the related definition object. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    MIParamConfMultiplicity getDef();

    /**
     * Returns the multiplicity information of the specified object. This never returns <code>null</code>. It implements the AUTOSAR standard semantic for multiplicity: If the
     * request multiplicity value is not defined in the model, this method returns 1.
     *
     * @return The objects multiplicity value but never <code>null</code>
     */
    @PublishedMethod
    IEcucDefMultiplicity getMultiplicity();

    /**
     * Returns the Scope of the specified object. This never returns <code>null</code>. If the request scope is not defined in the model, this method returns ECU.
     *
     * @return the Scope
     */
    @PublishedMethod
    MIEcucScopeEnum getEcucScope();

    /**
     * Returns the restricted state of the PSC.
     *
     * @return <code>true</code> if this CE is restricted by DefinitionRestriction of the PSC, <code>false</code> otherwise.
     */
    @PublishedMethod
    boolean isRestricted();

    /**
     * Returns the optional AUTOSAR Path of the restriction Source.
     *
     * @return the optional AUTOSAR Path of the restriction Source.
     */
    @PublishedMethod
    Optional<String> getRestrictingDefPath();

    /**
     * Returns the type of configuration instances which can use this definition.
     * <p>
     * <b>Example:</b> The {@link IEcucContainerDefinition} will return {@link MIContainer}.
     * </p>
     *
     * @return
     */
    @PublishedMethod
    <T extends MIHasDefinition> Class<T> getConfigurationType();

}
