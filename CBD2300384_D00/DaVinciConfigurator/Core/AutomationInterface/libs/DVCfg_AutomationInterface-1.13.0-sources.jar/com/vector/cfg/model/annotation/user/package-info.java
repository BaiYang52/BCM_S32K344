/**
 * This package contains API to query and create user annotation for model objects.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.annotation.user;