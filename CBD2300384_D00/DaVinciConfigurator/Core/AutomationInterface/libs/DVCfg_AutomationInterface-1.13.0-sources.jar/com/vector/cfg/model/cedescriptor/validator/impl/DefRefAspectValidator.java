package com.vector.cfg.model.cedescriptor.validator.impl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.ReworkThisAtNextPublishedApiChange;
import com.vector.cfg.model.cedescriptor.aspect.IDefRefAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidationException;
import com.vector.cfg.model.cedescriptor.validator.DescriptorAspectBuilderValidator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@ReworkThisAtNextPublishedApiChange("GROOVY-8669 - This can be moved again in an internal package, when the Groovy Annotation loading bug was fixed.")
public class DefRefAspectValidator extends DescriptorAspectBuilderValidator<IDefRefAspect> {

    /**
     * Constructor for DefRefAspectValidator.
     *
     */
    public DefRefAspectValidator() {
        super(IDefRefAspect.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkImpl(IDefRefAspect aspect) throws AspectValidationException {
        if (aspect.getDefRef() == null) {
            throw new AspectValidationException("An IDefRefAspect without a valid DefRef is not allowed.");
        }
    }

}
