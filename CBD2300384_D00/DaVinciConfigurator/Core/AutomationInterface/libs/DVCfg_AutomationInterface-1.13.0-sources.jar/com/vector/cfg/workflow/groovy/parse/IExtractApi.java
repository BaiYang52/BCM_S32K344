package com.vector.cfg.workflow.groovy.parse;

import java.nio.file.Path;
import java.util.Collection;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExtractApi {

    @PublishedMethod
    Path getFile();

    @PublishedMethod
    IExtractApi file(@Nonnull Object file);

    @PublishedMethod
    void setFile(@Nonnull Object file);

    @PublishedMethod
    Collection<Object> getExcludedElements();

    @PublishedMethod
    void setExcludedElements(Collection<?> excludedElements);

}
