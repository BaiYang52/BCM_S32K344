package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ITaskMappingSelector} Api allows the definition of predicates for {@link ITaskMapping} selection.
 * <p>
 * <div class="extdoc" id="ITaskMappingSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMappingSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches task mappings whose event is part of the internal behavior of a component with the given component
     * name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches task mappings whose event is part of the internal behavior of a component with the given
     * component name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfiguration">{@link #moduleConfiguration(String)} matches task mappings whose event is part of the internal behavior of a module
     * configuration with the given module configuration name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull String name);

    /**
     * <div class="extdoc" id="moduleConfigurationPattern">{@link #moduleConfiguration(Pattern)} matches task mappings whose event is part of the internal behavior of a module
     * configuration with the given module configuration name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPath">{@link #moduleConfigurationAsrPath(String)} matches task mappings whose event is part of the internal behavior of a
     * module configuration with the given module configuration autosar path.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPathPattern">{@link #moduleConfigurationAsrPath(Pattern)} matches task mappings whose event is part of the internal behavior of
     * a module configuration with the given module configuration autosar path pattern.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="event">{@link #event(String)} matches task mappings for events with the given event name.</div>
     *
     * @param name An event name.
     */
    @PublishedMethod
    void event(@Nonnull String name);

    /**
     * <div class="extdoc" id="eventPattern">{@link #event(Pattern)} matches task mappings for events matching the given event name pattern.</div>
     *
     * @param namePattern An event name pattern.
     */
    @PublishedMethod
    void event(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="eventAsrPath">{@link #eventAsrPath(String)} matches task mappings for events with the given event autosar path.</div>
     *
     * @param asrPath An event autosar path.
     */
    @PublishedMethod
    void eventAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="eventAsrPathPattern">{@link #eventAsrPath(Pattern)} matches task mappings for events matching the given event autosar path pattern.</div>
     *
     * @param asrPathPattern An event autosar path pattern.
     */
    @PublishedMethod
    void eventAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches task mappings which belongs to component types with the given component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches task mappings which belongs to component types matching the given component type name
     * pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches task mappings which belongs to component types with the given component type
     * autosar path.</div>
     *
     * @param asrPath A component type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches task mappings which belongs to component types matching the given
     * component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches task mappings which are not mapped to a task.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches task mappings which are mapped to a task.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="task">{@link #task(String)} matches task mappings which are mapped to a task with the given task name.</div>
     *
     * @param name A task name.
     */
    @PublishedMethod
    void task(@Nonnull String name);

    /**
     * <div class="extdoc" id="taskPattern">{@link #task(Pattern)} matches task mappings which are mapped to a task whose name matches the given task name pattern.</div>
     *
     * @param name A task name pattern.
     */
    @PublishedMethod
    void task(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches task mappings for which the given closure results to true.</div>
     *
     * @param code The closure to select task mappings.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(ITaskMapping.class) Closure<Boolean> code);

    // ------------- event predicates ---------------

    /**
     * <div class="extdoc" id="bswEvent">{@link #bswEvent()} matches task mappings for bsw events.</div>
     */
    @PublishedMethod
    void bswEvent();

    /**
     * <div class="extdoc" id="rteEvent">{@link #rteEvent()} matches task mappings for rte events.</div>
     */
    @PublishedMethod
    void rteEvent();

    /**
     * <div class="extdoc" id="timing">{@link #timing()} matches task mappings for timing events.</div>
     */
    @PublishedMethod
    void timing();

    /**
     * <div class="extdoc" id="timingPeriod">{@link #timing(BigDecimal)} matches task mappings for timing events with the given period (seconds).</div>
     *
     * @param period The period of the timing event in seconds.
     */
    @PublishedMethod
    void timing(BigDecimal period);

    /**
     * <div class="extdoc" id="init">{@link #init()} matches task mappings for init events.</div>
     */
    @PublishedMethod
    void init();

    /**
     * <div class="extdoc" id="dataReception">{@link #dataReception()} matches task mappings for data received events.</div>
     */
    @PublishedMethod
    void dataReceived();

    /**
     * <div class="extdoc" id="dataReceptionError">{@link #dataReceptionError()} matches task mappings for data receive error events.</div>
     */
    @PublishedMethod
    void dataReceiveError();

    /**
     * <div class="extdoc" id="dataSendCompletion">{@link #dataSendCompleted()} matches task mappings for data send completed events.</div>
     */
    @PublishedMethod
    void dataSendCompleted();

    /**
     * <div class="extdoc" id="dataWriteCompleted">{@link #dataWriteCompleted()} matches task mappings for data write completed events.</div>
     */
    @PublishedMethod
    void dataWriteCompleted();

    /**
     * <div class="extdoc" id="operationInvoked">{@link #operationInvoked()} matches task mappings for operation invoked events.</div>
     */
    @PublishedMethod
    void operationInvoked();

    /**
     * <div class="extdoc" id="operationInvokedNamed">{@link #operationInvoked(String)} matches task mappings for operation invoked events which are invoked by an operation with
     * the given operationName.</div>
     */
    @PublishedMethod
    void operationInvoked(@Nonnull String operationName);

    /**
     * <div class="extdoc" id="serverCallReturns">{@link #serverCallReturns()} matches task mappings for events which are asynchronous server call returns events.</div>
     */
    @PublishedMethod
    void serverCallReturns();

    /**
     * <div class="extdoc" id="modeSwitch">{@link #modeSwitch()} matches task mappings for mode switch events.</div>
     */
    @PublishedMethod
    void modeSwitch();

    /**
     * <div class="extdoc" id="modeEntry">{@link #modeEntry()} matches task mappings for mode switch events with activation kind ON-ENTRY.</div>
     */
    @PublishedMethod
    void modeEntry();

    /**
     * <div class="extdoc" id="modeExit">{@link #modeExit()} matches task mappings for mode switch events with activation kind ON-EXIT.</div>
     */
    @PublishedMethod
    void modeExit();

    /**
     * <div class="extdoc" id="modeTransition">{@link #modeTransition()} matches task mappings for mode switch events with activation kind ON-TRANSITION.</div>
     */
    @PublishedMethod
    void modeTransition();

    /**
     * <div class="extdoc" id="modeSwitchedAck">{@link #modeSwitchedAck()} matches task mappings for mode switched acknowledgement events.</div>
     */
    @PublishedMethod
    void modeSwitchedAck();

    /**
     * <div class="extdoc" id="externalTrigger">{@link #externalTrigger()} matches task mappings for external trigger occurred events.</div>
     */
    @PublishedMethod
    void externalTrigger();

    /**
     * <div class="extdoc" id="internalTrigger">{@link #internalTrigger()} matches task mappings for internal trigger occurred events.</div>
     */
    @PublishedMethod
    void internalTrigger();

    /**
     * <div class="extdoc" id="background">{@link #background()} matches task mappings for background events.</div>
     */
    @PublishedMethod
    void background();

    /**
     * <div class="extdoc" id="transformerHardError">{@link #transformerHardError()} matches task mappings for transformer hard error events.</div>
     */
    @PublishedMethod
    void transformerHardError();

    /**
     * <div class="extdoc" id="mandatory">{@link #mandatory()} matches task mappings for events which must be mapped. (The mapping of operation invoked events is optional, so this
     * predicate filters all operation invoked events.)</div>
     */
    @PublishedMethod
    void mandatory();

    // ------------- executable entity predicates ---------------

    /**
     * <div class="extdoc" id="symbol">{@link #symbol(String)} matches task mappings for runnable entities with the given symbol and bsw schedulable entities whose corresponding
     * bsw module entry short name matches the given symbol.</div>
     *
     * @param symbol An executable entity symbol.
     */
    @PublishedMethod
    void symbol(@Nonnull String symbol);

    /**
     * <div class="extdoc" id="symbolPattern">{@link #symbol(Pattern)} matches task mappings runnable entities whose symbol matches the given symbol pattern and bsw schedulable
     * entities whose corresponding bsw module entry short name matches the given symbol pattern.</div>
     *
     * @param symbol An executable entity symbol pattern.
     */
    @PublishedMethod
    void symbol(@Nonnull Pattern symbolPattern);

    /**
     * <div class="extdoc" id="executableEntity">{@link #executableEntity(String)} matches task mappings for executable entities (functions) with the given name.</div>
     *
     * @param name An executable entity name.
     */
    @PublishedMethod
    void executableEntity(@Nonnull String name);

    /**
     * <div class="extdoc" id="executableEntityPattern">{@link #executableEntity(Pattern)} matches task mappings for executable entities (functions) with the given name
     * pattern.</div>
     *
     * @param namePattern An executable entity name pattern.
     */
    @PublishedMethod
    void executableEntity(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="executableEntityAsrPath">{@link #executableEntityAsrPath(String)} matches task mappings for executable entities (functions) with the given autosar
     * path.</div>
     *
     * @param asrPath An executable entity autosar path.
     */
    @PublishedMethod
    void executableEntityAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="executableEntityAsrPathPattern">{@link #executableEntityAsrPath(Pattern)} matches task mappings for executable entities (functions) with the given
     * autosar path pattern.</div>
     *
     * @param asrPathPattern An executable entity autosar path pattern.
     */
    @PublishedMethod
    void executableEntityAsrPath(@Nonnull Pattern asrPathPattern);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<ITaskMapping> getSelectedTaskMappings();

}
