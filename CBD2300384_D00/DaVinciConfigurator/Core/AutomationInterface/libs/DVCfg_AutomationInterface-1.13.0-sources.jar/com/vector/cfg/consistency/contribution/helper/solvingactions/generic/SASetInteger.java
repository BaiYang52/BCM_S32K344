package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets an integer parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class SASetInteger extends SASetNumTextRef<MINumericalValue> {

    private final BigInteger targetValue;

    /**
     * Constructor for SASetInteger.
     *
     * @param numerical the parameter to be adjusted
     * @param targetValue the target value as BigInteger
     */
    @PublishedMethod
    public SASetInteger(MINumericalValue numerical, BigInteger targetValue) {
        super(numerical, MixedText.newBuilder().append(targetValue.toString()).flushResult());
        this.targetValue = targetValue;
    }

    /**
     * Constructor for SASetInteger.
     *
     * @param numerical the parameter to be adjusted
     * @param targetValue the target value as long
     */
    @PublishedMethod
    public SASetInteger(MINumericalValue numerical, long targetValue) {
        super(numerical, MixedText.newBuilder().append(BigInteger.valueOf(targetValue).toString()).flushResult());
        this.targetValue = BigInteger.valueOf(targetValue);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        ModelUtil.getModelAccess(getParam()).setAsInteger(getParam(), targetValue);
    }
}