package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.MIObject;

/**
 * {@link InvisibleObjectException} are thrown when accessing invisible mdf objects.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public abstract class InvisibleObjectException extends ModelVariantException {

    private static final long serialVersionUID = 4419095244860879641L;

    protected InvisibleObjectException(String message, MIObject source) {
        super(message, source);
    }

    protected InvisibleObjectException(String message, MIObject source, Throwable innerEx) {
        super(message, source, innerEx);
    }

}
