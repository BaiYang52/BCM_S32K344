package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/*
 * This published interface uses the implementation class as method return value, this is not allowed according to the new plugin architecture rules.
 * This problem cannot be solved without a breaking change, so we keep this interface in the legacy plugin for now.
 */

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * With this project service you can create SetParameter solving actions if you have a container and a parameter definition, but not the parameter instance. If there is already
 * a parameter instance, it is used, otherwise it is created.
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface ISolvingActionFactory {

    /**
     * Creates a solving action to set a boolean parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setBoolean(MIContainer container, DefRef paramDefRef, Boolean targetValue);

    /**
     * Creates a solving action to set a float parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setFloat(MIContainer container, DefRef paramDefRef, BigDecimal targetValue);

    /**
     * Creates a solving action to set a float parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setFloat(MIContainer container, DefRef paramDefRef, double targetValue);

    /**
     * Creates a solving action to set an integer parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setInteger(MIContainer container, DefRef paramDefRef, long targetValue);

    /**
     * Creates a solving action to set an integer parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setInteger(MIContainer container, DefRef paramDefRef, BigInteger targetValue);

    /**
     * Creates a solving action to set a reference parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setReference(MIContainer container, DefRef paramDefRef, MIReferrable targetValue);

    /**
     * Creates a solving action to set a textual parameter. The solving action uses the first existing instance, otherwise it creates one, and hence is not suitable for multi
     * instance parameters.
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    SASetParam setTextual(MIContainer container, DefRef paramDefRef, String targetValue);
}
