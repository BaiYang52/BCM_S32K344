package com.vector.cfg.gen.core.moduleinterface;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IProjectContext;

/**
 * IGeneratorPackageFactory could be used to register a GeneratorPackage, to register Validation rules or execute arbitrary code during initialization.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGeneratorPackageFactory extends IDeployablePackage {

    /**
     * Gets the CFG5 core feature version.
     *
     * <p>
     * Attention: This method must return the string from {@link IGeneratorPackage#CFG_CORE_FEATURE_VERSION_STRING} retrieved for a private final field. This ensures, that the
     * version in encoded in the Factory not retrieved at runtime.
     * </p>
     *
     * <p>
     * Example:<br />
     * 1.00.00
     * </p>
     *
     * @return The current CFG core feature version.
     */
    @Override
    @PublishedMethod
    String getCfgCoreFeatureVersionString();

    /**
     * Creates the corresponding IGeneratorPackages.
     *
     * <p>
     * The factory does not have to return an GeneratorPackage, if it only registers validators.
     * </p>
     *
     * @param projectContext the project context
     * @return List of GeneratorPackages
     */
    @PublishedMethod
    <T extends IDeployablePackage> List<T> createPackages(IProjectContext projectContext);

}
