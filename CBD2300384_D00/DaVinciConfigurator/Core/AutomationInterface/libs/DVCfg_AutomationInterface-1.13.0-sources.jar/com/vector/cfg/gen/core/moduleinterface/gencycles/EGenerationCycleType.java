package com.vector.cfg.gen.core.moduleinterface.gencycles;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.calculation.ECalculationSubPhase;
import com.vector.cfg.util.IDebugable;

/**
 * <div class="extdoc" id="Common"> The generation process consists of multiple generation cycles, and inside multiple phases (calculation, validation and generation). An
 * {@link IGeneratorPackage} can select in which cycle the generator should be executed. This is mostly used when a certain generator type (like Measurement and Calibration
 * generator) want run after the normal code generators.
 *
 * The class {@link EGenerationCycleType} defines the available cycles for the generation process. The cycles are executed with the defined ordinalOrder. The dependency
 * describes which cycle has to executed before the defined cycle.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
/* JavaListing GenerationCycles "The supported generation cycles" */
public enum EGenerationCycleType implements IDebugable {

    CODE_GENERATION("Code generation", /* ordinalOrder */10),
    MC_SUPPORT_DATA_GENERATION("Measurement and Calibration support data generation", /* ordinalOrder */30, dependsOn(CODE_GENERATION)),
    GENERATED_CODE_ANALYSIS("Generated Code Analysis", /* ordinalOrder */50, dependsOn(CODE_GENERATION)),
    BUILD_SYSTEM_GENERATION("Build system generation", /* ordinalOrder */60, dependsOn(CODE_GENERATION)),
    EXTERNAL_POST_GENERATION_STEPS("External Post Generation Steps", /* ordinalOrder */70, dependsOn(CODE_GENERATION))
    /* End JavaListing */
    ;

    private final int orderId;

    private final String descriptiveCycleName;

    private final ImmutableList<EGenerationCycleType> dependencyCyles;

    /**
     * Creates a {@link EGenerationCycleType} in the order of the passed orderId. The order is ascending, e.g. 1 before 2.
     *
     * @param descriptivePhaseName
     * @param orderId              the order id
     * @param dependencyCyles      the Cycle which have to be executed before this.
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the orderId is negative</li>
     *                                     </ul>
     */
    EGenerationCycleType(String descriptivePhaseName, int orderId, ImmutableList<EGenerationCycleType> dependencyCyles) {
        this.dependencyCyles = checkNotNull(dependencyCyles);
        this.descriptiveCycleName = checkNotNull(descriptivePhaseName);
        this.orderId = orderId;
        checkArgument(orderId >= 0);
    }

    /**
     * Creates a {@link EGenerationCycleType} in the order of the passed orderId. The order is ascending, e.g. 1 before 2.
     *
     * @param descriptivePhaseName
     * @param orderId              the order id
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the orderId is negative</li>
     *                                     </ul>
     */
    EGenerationCycleType(String descriptivePhaseName, int orderId) {
        this.dependencyCyles = ImmutableList.of();
        this.descriptiveCycleName = checkNotNull(descriptivePhaseName);
        this.orderId = orderId;
        checkArgument(orderId >= 0);
    }

    /**
     * Gets the comparator for the {@link ECalculationSubPhase}s. The comparator compares the literals by their orderId (ordinalOrder).
     *
     * @return the comparator
     */
    @PublishedMethod
    public static Comparator<EGenerationCycleType> getComparator() {
        return new Comparator<EGenerationCycleType>() {

            @Override
            public int compare(EGenerationCycleType o1, EGenerationCycleType o2) {
                return o1.orderId - o2.orderId;
            }
        };
    }

    private static ImmutableList<EGenerationCycleType> dependsOn(EGenerationCycleType... cycles) {
        final List<EGenerationCycleType> cycleList = Lists.newArrayList(cycles);
        Collections.sort(cycleList);
        return ImmutableList.copyOf(cycleList);
    }

    /**
     * Gets the all literals as a list of sorted values, sorted by the comparator of {@link #getComparator()}.
     *
     * @return the sorted values of all literals.
     */
    @PublishedMethod
    public static List<EGenerationCycleType> getSortedValues() {
        final List<EGenerationCycleType> list = new ArrayList<>(Arrays.asList(values()));
        Collections.sort(list, getComparator());

        return list;
    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveCycleName;
    }

    /**
     * Getter method for dependencyCyles.
     *
     * @return Returns the dependencyCyles.
     */
    @KeepSecretFromPublishedApi
    public List<EGenerationCycleType> getDependencyCyles() {
        return dependencyCyles;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return getDescriptiveName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String toDebugString() {
        return super.name();
    }

}
