/**
 * The project comparison provides an API for the automatic merge of 3 participating DaVinci projects.
 *
 * <div class="extdoc" id="AutoMerge"><!--AutoMerge-->The project comparison provides an API for the automatic merge of 3 DaVinci projects. </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge;