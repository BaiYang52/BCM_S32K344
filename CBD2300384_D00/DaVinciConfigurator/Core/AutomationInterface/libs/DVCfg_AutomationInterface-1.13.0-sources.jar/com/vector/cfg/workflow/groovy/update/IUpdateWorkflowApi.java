package com.vector.cfg.workflow.groovy.update;

import java.util.function.Consumer;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.project.IProject;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.parse.IWorkflowApiEntryPoint.IWorkflowApi;
import com.vector.cfg.workflow.groovy.update.project.IFilePreprocessingProjectApi;
import com.vector.cfg.workflow.groovy.update.project.IUpdateProjectApi;
import com.vector.cfg.workflow.groovy.update.result.IFilePreprocessingResult;

import groovy.lang.Closure;

/**
 * The Interface IUpdateWorkflowApi.
 *
 * * <div class="extdoc" id="IUpdateWorkflowApi">
 * <h2>IWorkflowApi</h2> <!--Label:IWorkflowApi-->
 * <p>
 * The {@link IWorkflowApi} is the automation interface for workflows. It is available everywhere in any script using a property approach or using a delegate approach:
 *
 * <pre>
<code class="Java" id="description">

 * scriptTask("PropertyApproach", APPLICATION) {
 *     code {
 *         workflow.updateProject("MyProject.dpa", {
 *             ...
 *         })
 *     }
 * }
 *
 * scriptTask("DelegateApproach", APPLICATION) {
 *     code {
 *         workflow {
 *             updateProject("MyProject.dpa",  {
 *                 ...
 *             })
 *         }
 *     }
 * }
 *
 * scriptTask("DelegateApproach", APPLICATION) {
 *     code {
 *
 *        dpaProjectFile ->
 *
 *        projects.openProject(dpaProjectFile) {
 *
 *           workflow {
 *
 *               boolean isPreprocessingRequired = isFilePreprocessingRequired(project)
 *               boolean isUpdateRequired = isUpdateRequired(project)
 *
 *               if(isPreprocessingRequired) {
 *                   filePreprocessingProject(project) {
 *                       ...
 *                   }
 *               }
 *
 *               if(isUpdateRequired) {
 *                   updateProject(project) {
 *                       ...
 *
 *                   }
 *               }
 *           }
 *        }
 *    }
 * }
 * </code>
 * </pre>
 * </p>
 * </div>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUpdateWorkflowApi {

    /**
     * The update method starts the update workflow after the code closure was executed.
     *
     * <div class="extdoc" id="update">
     * <h2>Update Project</h2> <!--Label:IWorkflowApi.update-->
     * <p>
     * Using {@link #update(Object, Closure)} an existing project can be updated with new input data. The given code {@link Closure}, parameterizing the update of the project,
     * is delegated to the {@link IUpdateApi} <!--Ref:IUpdateApi-->.
     * </p>
     *
     * @deprecated Use new method {@link #updateProject(Object, Closure)}
     *
     * </div>
     *
     * @param dpaFilePath the dpa file path
     * @param code the code
     */
    @PublishedMethod
    @Deprecated
    <T> T update(Object dpaFilePath,
            @VDelegatesToWithClosureParam(IUpdateApi.class) Closure<T> code);

    /**
     *
     *
     * see {@link #update(Object, Closure)} for more information.
     *
     * @deprecated Use new method {@link #updateProject(Object, Consumer)}
     */
    @PublishedMethod
    @Deprecated
    void update(Object dpaFilePath, Consumer<IUpdateApi> code);

    /**
     * The update method starts the update workflow.
     *
     * This method starts the update and uses the input files which were selected in the InputFiles Editor.
     *
     * @deprecated Use new method {@link #updateProject(Object)
     *
     * @param dpaFilePath the dpa file path
     * @param code the code
     */
    @PublishedMethod
    @Deprecated
    void update(Object dpaFilePath);

    /**
     * The updateProject method starts the update workflow after the code closure was executed.
     *
     * <div class="extdoc" id="update">
     * <h2>Update Project</h2> <!--Label:IWorkflowApi.updateProject-->
     * <p>
     * Using {@link #updateProject(Object, Closure)} an existing project can be updated with new input data. The given code {@link Closure}, parameterizing the update of the
     * project, is delegated to the {@link IUpdateProjectApi} <!--IUpdateProjectApi-->.
     * </p>
     *
     *
     * </div>
     *
     * @param dpaFilePath the dpa file path
     * @param code the code
     */
    @PublishedMethod
    <T> T updateProject(Object dpaFilePath, @VDelegatesToWithClosureParam(IUpdateProjectApi.class) Closure<T> code);

    /**
     *
     *
     * see {@link #updateProject(Object, Closure)} for more information.
     *
     */
    @PublishedMethod
    void updateProject(Object dpaFilePath, Consumer<IUpdateProjectApi> code);

    /**
     * The updateProject method starts the update workflow.
     *
     * This method starts the update and uses the input files which were selected in the InputFiles Editor.
     *
     *
     * @param dpaFilePath the dpa file path
     */
    @PublishedMethod
    void updateProject(Object dpaFilePath);

    /**
     * This updateProject method starts the update workflow with a already loaded project after the code closure was executed.
     *
     * <div class="extdoc" id="update">
     * <h2>Update already loaded Project</h2> <!--Label:IWorkflowApi.updateProject-->
     * <p>
     * Using {@link #updateProject(com.vector.cfg.util.IProjectContext, Closure)} an existing and already loaded project can be updated with new input data. The given code
     * {@link Closure}, parameterizing the update of the project, is delegated to the {@link IUpdateProjectApi} <!--IUpdateProjectApi-->.
     * </p>
     *
     *
     * </div>
     *
     * @param project the {@link IProject} which was already loaded before.
     * @param code the update project API code.
     */
    @PublishedMethod
    <T> T updateProject(IProject project, @VDelegatesToWithClosureParam(IUpdateProjectApi.class) Closure<T> code);

    /**
     *
     * see {@link #updateProject(IProject, Closure)} for more information.
     *
     */
    @PublishedMethod
    void updateProject(IProject project, Consumer<IUpdateProjectApi> code);

    /**
     * see {@link #updateProject(Object)} for more information.
     *
     * The only difference here is that an already loaded {@link IProject} could be passed to use it for the update execution.
     *
     * @param projectContext the {@link IProject} which was already loaded before.
     */
    @PublishedMethod
    void updateProject(IProject project);

    /**
     * The filePreprocessingProject method starts only the file preprocessing part of the update workflow after the code closure was executed.
     *
     * <div class="extdoc" id="filePreprocessing">
     * <h2>File Preprocessing</h2>
     * <p>
     * Using {@link #filePreprocessingProject(Object, Closure)} an existing project can be preprocessed with new input data. The given code {@link Closure}, parameterizing the
     * file preprocessing of the project, is delegated to the {@link IFilePreprocessingProjectApi}.
     * </p>
     * <p>
     * The return type is <code>com.vector.cfg.workflow.groovy.update.result.IFilePreprocessingResult</code> that references the file preprocessing result.
     * </p>
     *
     * </div>
     *
     * @param dpaFilePath the dpa file path
     * @param code the code
     * @return the file preprocessing result
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(Object dpaFilePath, @VDelegatesToWithClosureParam(IFilePreprocessingProjectApi.class) Closure<?> code);

    /**
     *
     * see {@link #filePreprocessingProject(Object, Closure)} for more information.
     *
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(Object dpaFilePath, Consumer<IFilePreprocessingProjectApi> code);

    /**
     * The filePreprocessingProject method starts the file preprocessing of the Update Workflow.
     *
     * This method starts the file preprocessing and uses the input files which were selected in the InputFiles Editor.
     *
     * @param dpaFilePath the dpa file path.
     * @return the file preprocessing result
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(Object dpaFilePath);

    /**
     *
     * see {@link #filePreprocessingProject(Object, Closure)} for more information.
     *
     * The only difference here is that an already loaded {@link IProject} could be passed to use it for the file Preprocessing execution.
     *
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(IProject project, @VDelegatesToWithClosureParam(IFilePreprocessingProjectApi.class) Closure<?> code);

    /**
     *
     * see {@link #filePreprocessingProject(IProject, Closure)} for more information.
     *
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(IProject project, Consumer<IFilePreprocessingProjectApi> code);

    /**
     * see {@link #filePreprocessingProject(Object)} for more information.
     *
     * The only difference here is that an already loaded {@link IProject} could be passed to use it for the file Preprocessing execution.
     *
     * @param projectContext the {@link IProject} which was already loaded before.
     * @return the file preprocessing result
     */
    @PublishedMethod
    IFilePreprocessingResult filePreprocessingProject(IProject project);

    /**
     * Checks if an complete update is required for the given project.
     *
     * <div class="extdoc" id="isUpdateRequired">
     * <h2>Is Update required</h2>
     * <p>
     * Using {@link #isUpdateRequired(Object)} will check if an complete update is required for the given project.
     * </p>
     * </div>
     *
     * @param dpaFilePath The path to the DpaFile.
     * @return {@code true} if an update is required otherwise {@code false}.
     */
    @PublishedMethod
    boolean isUpdateRequired(Object dpaFilePath);

    /**
     * see {@link #isUpdateRequired(Object)} for more information.
     *
     * The only difference here is that an already loaded {@link IProjectContext} could be passed to use it for the file Preprocessing execution.
     *
     * @param projectContext the {@link IProjectContext} which was already loaded before.
     * @return {@code true} if an update is required otherwise {@code false}.
     */
    @PublishedMethod
    boolean isUpdateRequired(IProject project);

    /**
     * Checks if an complete update is required for the given project.
     *
     * <div class="extdoc" id="isFilePreprocessingRequired">
     * <h2>Is File Preprocessing required</h2>
     * <p>
     * Using {@link #isFilePreprocessingRequired(Object)} will check if the File Preprocessing is required for the given project.
     * </p>
     * </div>
     *
     * @param dpaFilePath The path to the DpaFile.
     * @return {@code true} if the File Preprocessing is required otherwise {@code false}.
     */
    @PublishedMethod
    boolean isFilePreprocessingRequired(Object dpaFilePath);

    /**
     * see {@link #isFilePreprocessingRequired(Object)} for more information.
     *
     * The only difference here is that an already loaded {@link IProjectContext} could be passed to use it for the file Preprocessing execution.
     *
     * @param projectContext the {@link IProjectContext} which was already loaded before.
     * @return {@code true} if the File Preprocessing is required otherwise {@code false}.
     */
    @PublishedMethod
    boolean isFilePreprocessingRequired(IProject project);

    /**
     * Closes the Project (if not already closed) that is loaded during the the execution of the Workflow PAI API.
     */
    @KeepSecretFromPublishedApi
    void closeProject();
}