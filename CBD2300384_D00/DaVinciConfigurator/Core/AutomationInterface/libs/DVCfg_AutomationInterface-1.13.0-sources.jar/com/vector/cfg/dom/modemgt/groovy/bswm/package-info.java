/**
 * The ModeMgm <code>bswm</code> package contains the BswM-related interfaces of the mode management domain API.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.modemgt.groovy.bswm;