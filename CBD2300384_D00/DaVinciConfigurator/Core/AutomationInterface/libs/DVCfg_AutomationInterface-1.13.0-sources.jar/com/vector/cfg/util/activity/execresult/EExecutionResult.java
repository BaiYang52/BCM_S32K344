package com.vector.cfg.util.activity.execresult;

import org.eclipse.core.runtime.IStatus;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * EExecutionResult contains all possible results states of an {@link IExecutionResult}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IExecutionResult
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.AUTOMATION_IF_INTERNAL_ADDONS })
public enum EExecutionResult {
    SUCCESSFUL("Successful"),
    WARNING("Warning"),
    ERROR("Error"),
    FATAL_ERROR("FatalError"),
    CANCELED("Canceled"),;

    private String descriptiveName;

    EExecutionResult(String descName) {
        this.descriptiveName = descName;
    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }

    @KeepSecretFromPublishedApi
    public static EExecutionResult fromIStatus(IStatus status) {
        switch (status.getSeverity()) {
        case IStatus.OK:
            return SUCCESSFUL;
        case IStatus.INFO:
            return SUCCESSFUL;
        case IStatus.WARNING:
            return WARNING;
        case IStatus.ERROR:
            return ERROR;
        case IStatus.CANCEL:
            return CANCELED;
        default:
            throw new IllegalStateException("the status object has an unknown severity");
        }
    }

    @KeepSecretFromPublishedApi
    public int toIStatusSeverity() {
        switch (this) {
        case SUCCESSFUL:
            return IStatus.OK;
        case WARNING:
            return IStatus.WARNING;
        case ERROR:
        case FATAL_ERROR:
            return IStatus.ERROR;
        case CANCELED:
            return IStatus.CANCEL;
        default:
            throw new IllegalStateException("Unknown EExecutionResult: " + this);
        }
    }
}
