/**
 * Basic APIs to interaction with the Groovy runtime from Java and vice versa. The package also defines some util classes used from Groovy to reflect Groovy objects.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.scripting.groovy;