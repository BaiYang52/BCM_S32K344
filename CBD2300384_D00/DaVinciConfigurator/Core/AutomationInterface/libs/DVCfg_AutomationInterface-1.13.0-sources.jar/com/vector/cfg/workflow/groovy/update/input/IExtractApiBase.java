package com.vector.cfg.workflow.groovy.update.input;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.util.annotations.DeferredExecution;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * modifies the list of extract files and selects the ecuInstance.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExtractApiBase {

    /**
     * modifies the list of extracts.
     *
     * <p>
     * <b>Note: This closure is deferred executed in the same thread as the script.</b>
     * </p>
     *
     * Example:
     *
     * <pre>
     * <code>
     extractFiles{
        // clear the list of communication extracts
        it.clear()
        // adds an communication extract
        it.add(extractPath)
    }
     * </code>
     * </pre>
     *
     * @param code
     */
    @PublishedMethod
    void extractFiles(
            @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @DelegatesTo(target = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>", strategy = Closure.DELEGATE_FIRST) @ClosureParams(value = FromString.class, options = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>") Closure<?> code);

    /**
     * See {@link IExtractApiBase#extractFiles(Closure)} for more information.
     *
     * @param code
     */
    @PublishedMethod
    void extractFiles(
            @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Consumer<List<IPersistablePath>> code);

    /**
     * selects the ecuInstance of the extracts to import.
     *
     * <p>
     * <b>Note: This closure is deferred executed in the same thread as the script.</b>
     * </p>
     *
     *
     * <pre>
     * <code>
    ecuInstanceSelection{
        ecuInstance = availableEcuInstances[0]
    }
     * </code>
     * </pre>
     *
     * @param code
     */
    @PublishedMethod
    void ecuInstanceSelection(
            @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @VDelegatesToWithClosureParam(IEcuInstanceSelectionApi.class) Closure<IUpdateEcuInstance> code);

    /**
     * See {@link IExtractApiBase#ecuInstanceSelection(Closure)} for more information.
     *
     * @param code
     */
    @PublishedMethod
    void ecuInstanceSelection(
            @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Function<IEcuInstanceSelectionApi, IUpdateEcuInstance> code);

    /**
     * Represents an ecu instance for ecu instance selection.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IUpdateEcuInstance {

        /**
         * getter for the name.
         *
         * @return the name of the ecu instance.
         */
        @PublishedMethod
        String getName();

    }

    /**
     * Api for the selection of an ecuInstance.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IEcuInstanceSelectionApi {
        @PublishedMethod
        List<IUpdateEcuInstance> getAvailableEcuInstances();

    }

}
