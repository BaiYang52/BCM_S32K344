package com.vector.cfg.util.version;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class VersionFormatException extends RuntimeException {

    private static final long serialVersionUID = -3315876115168832678L;

    /**
     * Constructor.
     */
    @PublishedMethod
    public VersionFormatException() {
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public VersionFormatException(String msg) {
        super(msg);
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public VersionFormatException(String msg, Throwable e) {
        super(msg, e);
    }

}
