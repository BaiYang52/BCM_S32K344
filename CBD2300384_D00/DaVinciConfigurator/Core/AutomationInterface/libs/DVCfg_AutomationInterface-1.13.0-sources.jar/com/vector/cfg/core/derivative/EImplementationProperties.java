package com.vector.cfg.core.derivative;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Module implementation properties currently supported by CFG5.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public enum EImplementationProperties {
    /**
     * Compiler.
     */
    COMPILER("Compiler"),
    /**
     * PinLayout.
     */
    PINLAYOUT("PinLayout"),
    /**
     * String used for CPU define.
     */
    CPU_DEFINE("NameForCpuDefine");

    private String text;

    EImplementationProperties(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return this.text;
    }
}