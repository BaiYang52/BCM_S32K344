/**
 * Provides the result of the Update Workflow.<div class="extdoc" id="UpdateWorkflowResults">Provides the results that are produced by the Update Workflow execution.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.groovy.update.result;