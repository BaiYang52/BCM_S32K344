package com.vector.cfg.model.formula;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.asr.formula.api.IFormulaExpression;

/**
 * {@link ModelFormulaException} defines the abstract exception of all exceptions thrown by the formula sub system.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IFormulaError
 * @see IFormulaExpression
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelFormulaException extends RuntimeException implements IHasFormulaString {
    private static final long serialVersionUID = 4691217454396679093L;

    @PublishedMethod
    protected ModelFormulaException(String msg, Throwable ex) {
        super(msg, ex);
    }

    @PublishedMethod
    protected ModelFormulaException() {
        super();
    }

    @PublishedMethod
    protected ModelFormulaException(String message) {
        super(message);
    }

    @PublishedMethod
    public ModelFormulaException(Throwable cause) {
        super(null, cause);
    }

    /**
     * Returns the {@link List} of {@link IFormulaError}, of this {@link ModelFormulaException}.
     *
     * @return the error list
     */
    @PublishedMethod
    public Collection<IFormulaError> getErrorList() {
        return Collections.emptyList();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getFormulaString() {
        return "";
    }

    @PublishedMethod
    public EModelFormulaExceptionType getType() {
        return EModelFormulaExceptionType.UNKNOWN_ERROR;
    }

    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public enum EModelFormulaExceptionType {
        SYNTAX_ERROR,
        SEMANTIC_ERROR,
        EVALUATION_ERROR,
        UNKNOWN_ERROR;
    }

}
