package com.vector.cfg.gen.core.moduleinterface.exceptions;

import java.util.Arrays;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The {@link GeneratorPackageWrapperException} could wrap multiple {@link GenerationFailedException}s into a single {@link GeneratorPackageException} and then
 * could be rethrown to the Client. This is used for the hierarchic error handling. See ErrorHandlingContext.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GeneratorPackageWrapperException extends GeneratorPackageException {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorPackageWrapperException.class);

    private static final long serialVersionUID = 8034556141756693293L;

    /**
     * Constructs a new GeneratorPackageWrapperException for a GeneratorPackage
     * <p>
     * The new created GeneratorPackageWrapperException inserts the passed exceptions into the resultList.
     *
     * @param genExList The List of {@link GeneratorPackageException}s. For each item a Error will be reported in the Configurator.
     */
    @PublishedMethod
    public GeneratorPackageWrapperException(List<? extends GeneratorPackageException> genExList) {
        super(false, genExList);
    }

    /**
     * Constructs a new GeneratorPackageWrapperException for a GeneratorPackage
     * <p>
     * The new created GeneratorPackageWrapperException inserts the passed exceptions into the resultList.
     *
     *
     * @param genExList The List of {@link GeneratorPackageException}s. For each item a Error will be reported in the Configurator.
     */
    @PublishedMethod
    public GeneratorPackageWrapperException(GeneratorPackageException... genExList) {
        super(false, Arrays.asList(genExList));
    }
}
