package com.vector.cfg.customersupport.srp.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.scripting.groovy.extensions.VectorCollectionExtensions;
import com.vector.davinci.util.base.VUtil;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@PublishedFilter(MsrPlatform.class)
@ThreadSafe
public enum EProjectInformationApi {

    ALL_PROJECT_RELEVANT_DATA,
    DAVINCI_WORKSPACE,
    PROJECT_SYSTEM_FILES,
    PROJECT_LOG_FILES,
    BSW_INTERNAL_BEHAVIOR_FILES,
    MEASUREMENT_AND_CALIBRATION_FILES,
    SCRIPT_TASKS,
    ECU_CONFIGURATION_FILES,
    PROJECT_INPUT_FILES,
    GENERATED_FILES,
    TOOL_LOG_FILES,
    APPLICATION_COMPONENT_FILES,
    TIMING_EXTENSION_FILES,
    DIAGNOSTIC_DATA_FILES,
    SERVICE_COMPONENT_FILES;

    // NOTE: Workaround to tell the compiler that the com.vector.cfg.util.scripting.groovy plugin
    //       needs to be attracted.
    static {
        VUtil.indirectClassUsageForCompiler(VectorCollectionExtensions.class);
    }

}
