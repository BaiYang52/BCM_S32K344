package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.model.sysdesc.api.port.IPortInterface;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IPortInterfaceSelector} Api allows the definition of predicates for port interface selection.
 * <p>
 * <div class="extdoc" id="IPortInterfaceSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ReworkThisAtNextBreakingChange("Remove methods using @Override annotation and adapt documentation links")
public interface IPortInterfaceSelector extends IElementSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches port interfaces with the given port interface name.</div>
     *
     * @param name A port interface name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="names">{@link #names(Collection)} matches port interfaces with the given port interface names. The order of the names is not relevant in any
     * kind.</div>
     *
     * @param names A collection of port interface names.
     */
    @PublishedMethod
    void names(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches port interfaces with the given port interface name pattern.</div>
     *
     * @param namePattern A port interface name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches port interfaces with the given port interface autosar path.</div>
     *
     * @param asrPath A port interface autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches port interfaces with the given port interface autosar path pattern.</div>
     *
     * @param asrPathPattern A port interface autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="service">{@link #service()} matches port interfaces which are service interfaces.</div>
     */
    @PublishedMethod
    void service();

    /**
     * <div class="extdoc" id="application">{@link #application()} matches port interfaces which are application interfaces.</div>
     */
    @PublishedMethod
    void application();

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches port interfaces which are sender receiver interfaces.</div>
     */
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches port interfaces which are client server interfaces.</div>
     */
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="modeSwitch">{@link #modeSwitch()} matches port interfaces which are mode switch interfaces.</div>
     */
    @PublishedMethod
    void modeSwitch();

    /**
     * <div class="extdoc" id="nvData">{@link #nvData()} matches port interfaces which are NvData interfaces.</div>
     */
    @PublishedMethod
    void nvData();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches port interfaces which are trigger interfaces.</div>
     */
    @PublishedMethod
    void trigger();

    /**
     * <div class="extdoc" id="parameter">{@link #parameter()} matches port interfaces which are parameter interfaces.</div>
     */
    @PublishedMethod
    void parameter();

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches port interfaces for which the given closure results to true.</div>
     *
     * @param code The closure to select port interfaces.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IPortInterface.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} first matches all component types with the given component type name, then retrieves all port
     * interfaces of the component type's port prototypes.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} first matches all component types with the given component type name pattern, then retrieves
     * all port interfaces of the component type's port prototypes.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} first matches all component types with the given component type asr path, then
     * retrieves all port interfaces of the component type's port prototypes.</div>
     *
     * @param asrPath A component type type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} first matches all component types with the given component type asr path
     * pattern, then retrieves all port interfaces of the component type's port prototypes.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} first matches all components with the given component name, then retrieves all port interfaces of the
     * component's ports.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="components">{@link #components(Collection)} first matches all components with the given component names, then retrieves all port interfaces of the
     * component's ports. The order of the names is not relevant in any kind.</div>
     *
     * @param names A collection of component names.
     */
    @PublishedMethod
    void components(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} first matches all components with the given component name pattern, then retrieves all port
     * interfaces of the component's ports.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentPort">{@link #componentPort(String)} first matches all {@link IComponentPort}s with the given name, then retrieves all port interfaces of
     * the component ports.</div>
     *
     * <p>
     * Hint: The name of a component port, is the name of the component and the port prototype, separated by a dot.<br>
     * Example:<br>
     * ComponentPort: 'App1.pMyPort' is the port prototype 'pMyPort' in the context of component 'App1'.<br>
     * ComponentPort: 'COMPOSITIONTYPE.rDelegation' is the port prototype 'rDelegation' in the context of the ecu composition.
     * </p>
     *
     * @param name A component port name.
     */
    @PublishedMethod
    void componentPort(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPorts">{@link #componentPorts(Collection)} first matches all {@link IComponentPort}s with the given names, then retrieves all port
     * interfaces of the component ports. The order of the names is not relevant in any kind.</div>
     *
     * <p>
     * Hint: The name of a component port, is the name of the component and the port prototype, separated by a dot.<br>
     * Example:<br>
     * ComponentPort: 'App1.pMyPort' is the port prototype 'pMyPort' in the context of component 'App1'.<br>
     * ComponentPort: 'COMPOSITIONTYPE.rDelegation' is the port prototype 'rDelegation' in the context of the ecu composition.
     * </p>
     *
     * @param names A a collection of component port names.
     */
    @PublishedMethod
    void componentPorts(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="componentPortPattern">{@link #componentPort(Pattern)} first matches all {@link IComponentPort}s with the given name pattern, then retrieves all
     * port interfaces of the component ports.</div>
     *
     *
     * <p>
     * Hint: The name of a component port, is the name of the component and the port prototype, separated by a dot.<br>
     * Example:<br>
     * ComponentPort: 'App1.pMyPort' is the port prototype 'pMyPort' in the context of component 'App1'.<br>
     * ComponentPort: 'COMPOSITIONTYPE.rDelegation' is the port prototype 'rDelegation' in the context of the ecu composition.
     * </p>
     *
     * @param namePattern A component port name pattern.
     */
    @PublishedMethod
    void componentPort(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="put">{@link #put(List)} can be used to set {@link IPortInterface}s into the selection. This is the most efficient way to create a selection from
     * existing objects. If further predicates are specified the predicates will be applied only on the port interfaces that were given into this {@link #put(List)} method. The
     * iteration order is relevant for getting deterministic results on further usage of the selection API. This method should only be called once.</div>
     *
     * @throws SelectionException if the method is called more than once or if the given portInterfaces are null.
     */
    @PublishedMethod
    void put(List<IPortInterface> portInterfaces);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IPortInterface> getSelectedPortInterfaces();

}
