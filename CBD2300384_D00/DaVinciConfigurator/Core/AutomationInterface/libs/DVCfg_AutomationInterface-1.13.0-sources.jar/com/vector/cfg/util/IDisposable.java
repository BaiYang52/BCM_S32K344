package com.vector.cfg.util;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * IDisposable describes an interface to release unmanaged resources at a defined point in time.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDisposable {

    /**
     * Dispose can be called to release unmanaged resources at a defined point in time.
     *
     * <p>
     * Multiple calls to this method are allowed, and must not throw any exceptions.
     * </p>
     */
    @PublishedMethod
    void dispose();
}
