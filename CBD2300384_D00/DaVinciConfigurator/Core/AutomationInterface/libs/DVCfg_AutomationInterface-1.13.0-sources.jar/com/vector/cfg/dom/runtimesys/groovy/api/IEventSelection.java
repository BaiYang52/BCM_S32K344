package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IEvent;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IEventSelection"><!--Label:IEventSelection-->{@link IEventSelection} represents a selection of {@link IEvent}s and the possible operations on these
 * events.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IEventSelection {

    /**
     * <div class="extdoc" id="mapToTask"><!--Label:IEventSelection.mapToTask-->{@link #mapToTask(Closure)} tries to perform a task mapping for the selection of events (triggers).
     * Inside the closure the task mapping can be controlled, e.g. selecting the task to which the events should be mapped to and order the event's positions. Does not consider
     * events (triggers) which do not reference an executable entity (function).</div>
     *
     * <p>
     * The event selection will produce trace, info and warning logs. To see them, activate the '{@link com.vector.cfg.dom.runtimesys.groovy.api.IEventSelection}' logger with the
     * appropriate log level.
     * </p>
     *
     * @param code The code to provide select a task and order the task mappings.
     * @return A list of created task mappings.
     * @throws Throws a {@link SelectionException} if more than one or none task is selected inside the closure.
     */
    @PublishedMethod
    List<? extends ITaskMapping> mapToTask(@Nonnull @VDelegatesToWithClosureParam(ITaskMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="setActivationOffset"><!--Label:IEventSelection.setActivationOffset-->{@link #setActivationOffset(BigDecimal)} sets the activation offset at the task
     * mapping containers for the selected events. If the symbol of a schedulable entity matches a runnable name, the activation offset will be set for both, even if only one of
     * them is selected. (Matching works as for {@link ITaskMapper#combineViaSymbol(boolean)}.)</div>
     *
     * @param offsetInSeconds The activation offset (in seconds) which should be set.
     * @return A list of task mappings whose activation offset was set.
     *
     * @throws NullPointerException if the given offsetInSeconds is null.
     */
    @PublishedMethod
    List<ITaskMapping> setActivationOffset(@Nonnull BigDecimal offsetInSeconds);

    /**
     * <div class="extdoc" id="setOsSchedulePoint"><!--Label:IEventSelection.setOsSchedulePoint-->{@link #setOsSchedulePoint(String)} sets the OsSchedulePoint at the task mapping
     * containers for the selected events. If the symbol of a schedulable entity matches a runnable name, the schedule point value will be set for both, even if only one of them is
     * selected. (Matching works as for {@link ITaskMapper#combineViaSymbol(boolean)}.)</div>
     *
     * @param osSchedulePoint The OsSchedulePoint value which should be set.
     * @return A list of task mappings whose OsSchedulePoint was set.
     *
     * @throws NullPointerException if the given osSchedulePoint is null.
     */
    @PublishedMethod
    List<ITaskMapping> setOsSchedulePoint(@Nonnull String osSchedulePoint);

    /**
     * <div class="extdoc" id="getEvents"><!--Label:IEventSelection.getEvents-->{@link #getEvents()} allows access to the single events in the {@link IEventSelection}.</div>
     *
     * @return The collection of selected events.
     */
    @PublishedMethod
    Collection<? extends IEvent> getEvents();

    /**
     * <div class="extdoc" id="getTaskMappings"><!--Label:IEventSelection.getTaskMappings-->{@link #getTaskMappings()} retrieves all {@link ITaskMapping}s for the selected events
     * (see {@link #getEvents()}).<br>
     * <p>
     * Note: <br>
     * 1. In case of multi instantiation of component prototypes, the different instances share the same events, since the event is part of the internal behavior of the component
     * type. Therefore if the event is selected, {@link #getTaskMappings()} will always return the task mappings for all component prototypes. <br>
     * 2. Since this method can be run outside of a transaction, there might be selected events for which no task mapping container does exist yet. The container cannot be created
     * by calling {@link #getTaskMappings()}, so no task mapping can be returned. This happens if the system description is not synchronized, after changes in the structured
     * extract were done (see Automation Interface Documentation, chapter about Model Synchronization for examples how to synchronize).
     * </p>
     * </div>
     *
     * @return A list of the task mappings which references the selected events.
     */
    @PublishedMethod
    Collection<ITaskMapping> getTaskMappings();

}
