package com.vector.cfg.customersupport.srp.pai;

import java.nio.file.Path;
import java.util.Collection;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@PublishedFilter(MsrPlatform.class)
@ThreadSafe
public interface ICreateSRPApi {

    /**
     * <div class="extdoc" id="setFirstName">Use {@link #setFirstName(String)} or {@link #firstName(String)} to set the first name.<br>
     * <b>Mandatory</b></div>
     *
     * @param first the new first name
     */
    @PublishedMethod
    void setFirstName(@Nonnull String first);

    /**
     * {@link #setFirstName(String)}.
     *
     * @param first the first
     */
    @PublishedMethod
    void firstName(@Nonnull String first);

    /**
     * <div class="extdoc" id="setLastName">Use {@link #setLastName(String)} or {@link #lastName(String)} to set the last name.<br>
     * <b>Mandatory</b></div>
     *
     * @param last the new last name
     */
    @PublishedMethod
    void setLastName(@Nonnull String last);

    /**
     * {@link #setLastName(String)}.
     *
     * @param last the last
     */
    @PublishedMethod
    void lastName(@Nonnull String last);

    /**
     * <div class="extdoc" id="setEMail">Use {@link #setEMail(String)} or {@link #eMail(String)} to set the email.<br>
     * <b>Mandatory</b></div>
     *
     * @param mail the new e mail
     */
    @PublishedMethod
    void setEMail(@Nonnull String mail);

    /**
     * {@link #setEMail(String)}.
     *
     * @param mail the mail
     */
    @PublishedMethod
    void eMail(@Nonnull String mail);

    /**
     * <div class="extdoc" id="setProjectInformation">Use {@link #setProjectInformation(Collection)} or {@link #projectInformation(Collection)} to manually add the necessary
     * project informations in the .zip. This is optional. If no {@link #projectInformation(Collection)} is used, the system will only add the mandatory project informations. <br>
     * <b>Optional</b>
     * <ul>
     * <li>PC Info</li>
     * <li>SIP Info</li>
     * <li>Tool Version Info</li>
     * </ul>
     * </div>
     *
     * @param list the new project information
     */
    @PublishedMethod
    void setProjectInformation(@Nonnull Collection<EProjectInformationApi> list);

    /**
     * {@link #setProjectInformation(Collection)}.
     *
     * @param list the list
     */
    @PublishedMethod
    void projectInformation(@Nonnull Collection<EProjectInformationApi> list);

    /**
     * <div class="extdoc" id="setSaveLocation">Use this {@link #setSaveLocation(Path)} or {@link #saveLocation(Path)} to define the output location. If nothing is set, the system
     * will use the project location.<br>
     * <b>Optional</b></div>
     *
     * @param location the new save location
     */
    @PublishedMethod
    void setSaveLocation(@Nonnull Path location);

    /**
     * {@link #setSaveLocation(Path)}.
     *
     * @param location the location
     */
    @PublishedMethod
    void saveLocation(@Nonnull Path location);

    /**
     * Gets the save location.
     *
     * @return the save location
     */
    @KeepSecretFromPublishedApi
    Path getSaveLocation();

    /**
     * <div class="extdoc" id="addAdditionalFiles">Attach the given additional files.<br>
     * <b>Optional</b></div>
     */
    @PublishedMethod
    void addAdditionalFiles(Collection<Path> additionalFiles);

    /**
     * <div class="extdoc" id="setProblemDescription">Add the given problem description. Subsequent calls will overwrite previous descriptions.<br>
     * <b>Optional</b></div>
     */
    @PublishedMethod
    void setProblemDescription(String description);
}
