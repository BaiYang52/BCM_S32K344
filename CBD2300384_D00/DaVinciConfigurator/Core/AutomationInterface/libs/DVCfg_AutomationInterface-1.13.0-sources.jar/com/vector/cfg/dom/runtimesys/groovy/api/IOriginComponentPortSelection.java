package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.origin.IOriginComponentPort;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IOriginComponentPortSelection"><!--Label:IOriginComponentPortSelection-->{@link IOriginComponentPortSelection} represents a selection of
 * {@link IOriginComponentPort}s which can be used as additional information for other operations. The origin component ports selected here are ends of incomplete delegation
 * connections of the structured extract.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOriginComponentPortSelection {

    /**
     * <div class="extdoc" id="getOriginComponentPorts"><!--Label:IOriginComponentPortSelection.getOriginComponentPorts-->{@link #getOriginComponentPorts()} allows access to the
     * single origin component ports in the {@link IOriginComponentPortSelection}.</div>
     *
     * @return The collection of selected origin component ports.
     */
    @PublishedMethod
    Collection<IOriginComponentPort> getOriginComponentPorts();

    /**
     * <p>
     * <div class="extdoc" id=
     * "createFlatExtractDelegationPorts"><!--Label:IOriginComponentPortSelection.createFlatExtractDelegationPorts-->{@link #createFlatExtractDelegationPorts(Closure)} creates a
     * PortPrototype on the ecu composition of the FlatExtract for each selected origin component port using their port interfaces. If the naming is not specified, the names of
     * the created delegation ports are derived from the port interfaces. The direction of the ports has to be specified.</div>
     * </p>
     *
     * <p>
     * The origin component port selection will produce trace, info and warning logs. To see them, activate the
     * 'com.vector.cfg.dom.runtimesys.groovy.api.IOriginComponentPortSelection' logger with the appropriate log level.
     * </p>
     *
     * @return A list of the newly created delegation component ports in the flat extract.
     */
    @PublishedMethod
    List<IComponentPort> createFlatExtractDelegationPorts(@Nonnull @VDelegatesToWithClosureParam(IDelegationPortCreator.class) Closure<?> createPortCode);

}
