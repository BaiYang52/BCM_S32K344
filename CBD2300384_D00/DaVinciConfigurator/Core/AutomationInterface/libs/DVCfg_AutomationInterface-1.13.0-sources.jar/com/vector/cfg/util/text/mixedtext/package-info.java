/**
 * DaVinci Configurator {@link com.vector.cfg.util.text.mixedtext.IMixedText} API for text formatting and display to end users.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.text.mixedtext;