package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.connection.IConnector;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IComponentPortSelection"><!--Label:IComponentPortSelection-->{@link IComponentPortSelection} represents a selection of {@link IComponentPort}s and the
 * possible operations on these component ports.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPortSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:IComponentPortSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of component ports according
     * the component connection assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target component
     * ports can be defined and code to evaluate and change the auto-mapper results can be provided.
     * <p>
     * Narrowing down the target component ports may be useful to gain better matches for the auto-mapper: In case several target component ports match equally, no auto-mapping
     * is performed. So reducing the target component ports may improve the results of the auto-mapping.
     * </p>
     * <p>
     * The component port selection will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.IComponentPortSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate the matches.
     * @return A list of created connectors (mappings).
     */
    @PublishedMethod
    <T extends IConnector> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(IComponentPortAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:IComponentPortSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of component ports according the component
     * connection assistant default rules.</div>
     *
     * @return A list of created connectors (mappings).
     */
    @PublishedMethod
    <T extends IConnector> List<T> autoMap();

    /**
     * <div class="extdoc" id="terminate"> {@link #terminate()} terminates all selected {@link IComponentPort}s. If one of the selected ports is already terminated or connected
     * to another component port, the port will be ignored.
     * <p>
     * The termination of component ports disables the validation of these ports. In other words, these ports are acknowledged as not connected yet. This should give a better
     * overview of the open ports, which still have to be connected or need a data mapping.
     * </p>
     * </div>
     *
     * @return A collection containing all selected component ports which were terminated by this call.
     */
    @PublishedMethod
    Collection<IComponentPort> terminate();

    /**
     * <div class="extdoc" id="removePortTerminators"> {@link #removePortTerminators()} removes the port terminators of all selected component ports. If one of the selected
     * component ports is not terminated the method will ignore that port.
     * <p>
     * See {@link #terminate()} for more information about the purpose of terminating ports.
     * </p>
     * </div>
     *
     * @return A collection containing all selected component ports for which a port terminator has been removed.
     */
    @PublishedMethod
    Collection<IComponentPort> removePortTerminators();

    /**
     * <p>
     * <div class="extdoc" id="createDelegationPorts"><!--Label:IComponentPortSelection.createDelegationPorts-->{@link #createDelegationPorts(Closure)} creates a delegation port
     * for each selected component port using their port interfaces. <br>
     * If the naming is not specified, the names of the created delegation ports are derived from the port interfaces. The direction of the ports has to be specified.</div>
     * </p>
     *
     * <p>
     * Creating new delegation ports is currently restricted to sender/receiver, client/server and trigger ports.
     * </p>
     *
     * @return A list of the newly created delegation component ports.
     */
    @PublishedMethod
    List<IComponentPort> createDelegationPorts(@Nonnull @VDelegatesToWithClosureParam(IDelegationPortCreator.class) Closure<?> createDelegationPortCode);

    /**
     * <p>
     * <div class="extdoc" id="getComponentPorts"><!--Label:IComponentPortSelection.getComponentPorts-->{@link #getComponentPorts()} allows access to the single component ports
     * in the {@link IComponentPortSelection}.</div>
     * </p>
     *
     * @return The collection of selected component ports.
     */
    @PublishedMethod
    <T extends IComponentPort> Collection<T> getComponentPorts();

    /**
     * <div class="extdoc" id="unmap"><!--Label:IComponentPortSelection.unmap-->{@link #unmap()} unmaps the selected component ports of this selection from ALL connected ports.
     * In case that not all connections shall be removed the targets can be narrowed down using {@link #unmapFrom(Closure)}.</div>
     *
     * @return A collection of {@link IUnmappedPortsResult}s representing the {@link IComponentPort}s of each removed {@link IConnector}. <br>
     * That means also in case a selected component port was disconnected from multiple target ports, for each disconnected target port exactly one {@link IUnmappedPortsResult}.
     */
    @PublishedMethod
    Collection<IUnmappedPortsResult> unmap();

    /**
     * <div class="extdoc" id="unmapFrom"><!--Label:IComponentPortSelection.unmapFrom-->{@link #unmapFrom()} unmaps the selected component ports of this selection from the
     * connected ports. In opposite to {@link #unmap()} this method allows additional evaluation of the component port pairs that should be unmapped.</div>
     *
     * @return A collection of {@link IUnmappedPortsResult}s representing the {@link IComponentPort}s of each removed {@link IConnector}. <br>
     * That means also in case a selected component port was disconnected from multiple target ports, for each disconnected target port exactly one {@link IUnmappedPortsResult}.
     */
    @PublishedMethod
    Collection<IUnmappedPortsResult> unmapFrom(@Nonnull @VDelegatesToWithClosureParam(IComponentPortUnmapper.class) Closure<?> code);

}
