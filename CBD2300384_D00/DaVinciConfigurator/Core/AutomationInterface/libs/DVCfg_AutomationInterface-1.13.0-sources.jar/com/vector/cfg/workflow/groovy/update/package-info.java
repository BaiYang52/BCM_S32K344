/**
 * The Update Workflow API comprises modification of variants, modification of the input files list and the execution of an update workflow. The update workflow derives the
 * initial EcuC from the input files and updates the project accordingly.
 *
 * <div class="extdoc" id="UpdateWorkflow"><!--UpdateWorkflow-->The Update Workflow derives the initial EcuC from the input files and updates the project accordingly. The Update
 * Workflow API comprises modification of variants, modification of the input files list and execution of an update workflow. </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.groovy.update;