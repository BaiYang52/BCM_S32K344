package com.vector.cfg.project.settings.msr.groovy;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IProjectTargetApiEntryPoint} is the entry point for accessing project settings target interface.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IProjectTargetApiEntryPoint {

    /**
     * Use {@link #getTarget()} to specify the target project settings.
     *
     * <div class="extdoc" id="getTarget"><!--Label:IProjectTargetApiEntryPoint.getTarget-->Use {@link #getTarget()} or {@link #target(Closure)} to specify the target project
     * settings. </div>
     */
    @PublishedMethod
    IProjectTargetApi getTarget();

    /**
     * Use {@link #target(Closure)} to specify the target project settings in a scope-like way.
     *
     * @param code code providing the target project settings
     * @see #getTarget()
     */
    @PublishedMethod
    <T> T target(@VDelegatesToWithClosureParam(IProjectTargetApi.class) Closure<T> code);

}
