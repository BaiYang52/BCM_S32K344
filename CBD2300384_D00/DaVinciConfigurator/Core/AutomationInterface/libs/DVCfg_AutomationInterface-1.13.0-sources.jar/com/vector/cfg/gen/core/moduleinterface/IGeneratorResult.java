package com.vector.cfg.gen.core.moduleinterface;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * A GeneratorResult represents a result, which is shown in the GUI of the Cfg. A Result could be a ERROR, WARNING, IMPROVEMENT or INFO.
 *
 * <p>
 * Please use <code>com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder</code> to create instances of {@link IGeneratorResult}s.
 * </p>
 *
 * <div class="extdoc" id="Common">
 *
 * An {@link IGeneratorResult} is also an {@link IValidationResult} so we will to the terms interchangeably. You should always use {@link IGeneratorResult}s, because they
 * provide a broader API for the generator use case<!--LaTeX: \ifClassicDoc -->, such as API for the Definition model<!--LaTeX: (See \vref{sec:BswmdModel})--><!--LaTeX:\fi-->.
 *
 * The figure <!--LaTeX:\vref{fig:IGeneratorResultClasses}--> show the class hierarchy of {@link IGeneratorResult}s.
 *
 * <img src="{@docRoot} /../_doc/UML/IGeneratorResult/IGeneratorResultClasses.png" alt="IGeneratorResult and IValidationResult" id="fig:IGeneratorResultClasses "
 * data-latex-style="scale=0.7" />
 *
 * <pre>
 * <!--PlantUML: IGeneratorResultClasses
 * {@link IValidationResult} <|-_ {@link IGeneratorResult}
 * {@link IGeneratorResult} <.. GeneratorResultBuilder : creates
 * note right of GeneratorResultBuilder : Use this to create results
 *
 * -->
 * </pre>
 *
 * You must not implement the {@link IGeneratorResult} interface to make you own results!
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see GeneratorResultBuilder
 * @noimplement This interface is not intended to be implemented by clients. Please use GeneratorResultBuilder
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResult extends IValidationResult, IFormattable {
    /**
     * Gets the exception which has caused this generator result, or null if no exception has caused this result.
     *
     * @return The exception or <code>null</code>.
     */
    @PublishedMethod
    Throwable getException();

    /**
     * Gets the Result Id (Origin,Id, etc.) of this Result. The ResultId is used to group certain messages together.
     *
     * @return The ValidationResultId
     */
    @PublishedMethod
    @Override
    IValidationResultId getId();

    /**
     * Gets the description of the Result.
     *
     * @return The Description
     */
    @PublishedMethod
    @Override
    IMixedText getDescription();

    /**
     * Gets the Severity of the Result.
     *
     * <p>
     * The severity "<b>Improvement</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The settings are correct and valid but may not be optimal with respect to embedded code generation. E.g. modifying this value may reduce memory consumption or CPU
     * load.</li>
     * <li>The detection of Improvement may be executed during generation or in a separate step that has to be triggered by the user (e.g. "Find Improvements").</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Info</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Some settings have been adapted by a clearly defined rule (e.g. using of a default value). Applying this rule has not modified the behavior of the software.</li>
     * <li>General information for the user e.g. the finalization of the generation process.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Warning</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The configuration may be faulty or in some way incorrect but there are reasons why the user might require such a way of configuration.</li>
     * <li>The output files can be processed without problems (e.g. no compile errors...)</li>
     * <li>It may happen that the output files will lead to a non functioning system in case the warning is ignored by the user.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Input data is not consistent e.g. conflicting settings</li>
     * <li>Using the output files lead to problems in the following processing steps or in an invalid runtime behavior of the ECU.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Fatal Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The detected internal fatal error is so severe that processing (e.g. generation or validation) cannot be continued.</li>
     * </ul>
     * Hint: Do not report Fatal Errors!
     * </p>
     *
     *
     * @return The Severity of the result
     */
    @PublishedMethod
    @Override
    EValidationSeverityType getSeverity();

    /**
     * Gets the erroneous Configuration entities involved in the result.
     *
     * @return Collection of CEs.
     */
    @PublishedMethod
    @Override
    Collection<IDescriptor> getErroneousCEs();

    /**
     * Gets the solving actions registered to this Result.
     *
     * @return Collection of Solving Actions
     */
    @PublishedMethod
    @Override
    Collection<ISolvingAction> getSolvingActions();

    /**
     * Gets auto solving Action.
     *
     * @return A auto Solving Action
     */
    @PublishedMethod
    @Override
    ISolvingAction getAutoSolvingAction();

}
