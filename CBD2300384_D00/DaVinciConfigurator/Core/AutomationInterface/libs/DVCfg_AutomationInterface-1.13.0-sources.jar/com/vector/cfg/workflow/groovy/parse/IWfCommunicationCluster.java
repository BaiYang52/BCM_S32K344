package com.vector.cfg.workflow.groovy.parse;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IWfCommunicationCluster extends IWfReferrable {

    @PublishedMethod
    List<IWfReferrable> getPhysicalChannels();

    @PublishedMethod
    IWfReferrable getCommunicationController();

    @PublishedMethod
    IWfReferrable getCommunicationConnector();

}
