package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link ModelException} is the base {@link RuntimeException} of all exceptions thrown by the model. Either on read or write access.
 * <p>
 * Note: Transaction like UnitOfWorks have their own exception.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelException extends RuntimeException {

    private static final long serialVersionUID = -2645865136114090222L;

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelException() {
    }

    /**
     * Constructor.
     *
     * @param message the message
     */
    @PublishedMethod
    public ModelException(String message) {
        super(message);
    }

    /**
     * Constructor.
     *
     * @param message the message
     * @param innerEx the inner ex
     */
    @PublishedMethod
    public ModelException(String message, Throwable innerEx) {
        super(message, innerEx);
    }

}
