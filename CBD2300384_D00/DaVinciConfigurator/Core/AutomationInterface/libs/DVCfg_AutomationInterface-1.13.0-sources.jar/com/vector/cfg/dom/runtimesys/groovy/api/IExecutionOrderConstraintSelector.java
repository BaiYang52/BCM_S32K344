package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.eoc.IExecutionOrderConstraint;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IExecutionOrderConstraintSelector} Api allows the definition of predicates to select execution order constraints.
 * <p>
 * <div class="extdoc" id="IExecutionOrderConstraintSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and
 * 'and' predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExecutionOrderConstraintSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IExecutionOrderConstraintSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IExecutionOrderConstraintSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IExecutionOrderConstraintSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches execution order constraints with the given execution order constraint name.</div>
     *
     * @param name An execution order constraint name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches execution order constraints with the given execution order constraint name pattern.</div>
     *
     * @param namePattern An execution order constraint name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches execution order constraints for which the given closure results to true.</div>
     *
     * @param code The closure to select execution order constraints.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IExecutionOrderConstraint.class) Closure<Boolean> code);

    // -------------- internal API
    @KeepSecretFromPublishedApi
    List<IExecutionOrderConstraint> getSelectedExecutionOrderConstraints();

}
