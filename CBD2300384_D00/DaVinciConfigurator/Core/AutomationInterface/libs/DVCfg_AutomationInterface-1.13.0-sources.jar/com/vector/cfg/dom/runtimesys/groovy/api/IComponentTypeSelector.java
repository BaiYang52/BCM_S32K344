package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.sysdesc.api.component.IComponentType;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IComponentTypeSelector} Api allows the definition of predicates for component type selection.
 * <p>
 * <div class="extdoc" id="IComponentTypeSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ReworkThisAtNextBreakingChange("Remove methods using @Override annotation and adapt documentation links")
public interface IComponentTypeSelector extends IElementSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IComponentTypeSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IComponentTypeSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IComponentTypeSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches component types with the given component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="names">{@link #names(Collection)} matches component types with the given component type names. The order of the names is not relevant in any
     * kind.</div>
     *
     * @param names A collection of component type name.
     */
    @PublishedMethod
    void names(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches component types with the given component type name pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches component types with the given componet type autosar path.</div>
     *
     * @param asrPath A component type autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches component types with the given component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches component types for which a component prototype with the given component name exists.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches component types for which a component prototype with the given component name pattern
     * exists.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches component types for which the given closure results to true.</div>
     *
     * @param code The closure to select component types.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IComponentType.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="application">{@link #application()} matches component types which are application component types. Application component types are all component
     * types which are not service component types, as displayed in the ECU Software Components Editor, not ApplicationSwComponentTypes as defined by AUTOSAR.</div>
     */
    @PublishedMethod
    void application();

    /**
     * <div class="extdoc" id="service">{@link #service()} matches component types which are service component types.</div>
     */
    @PublishedMethod
    void service();

    /**
     * <div class="extdoc" id="parameter">{@link #parameter()} matches component types which are parameter (calibration) component types.</div>
     */
    @PublishedMethod
    void parameter();

    /**
     * <div class="extdoc" id="nvBlock">{@link #nvBlock()} matches component types which are nv block component types.</div>
     */
    @PublishedMethod
    void nvBlock();

    /**
     * <div class="extdoc" id="sensorActuator">{@link #sensorActuator()} matches component types which are sensor actuator component types.</div>
     */
    @PublishedMethod
    void sensorActuator();

    /**
     * <div class="extdoc" id="ioHwAbstraction">{@link #ioHwAbstraction()} matches component types which are I/O hardware abstraction component types, also called
     * EcuAbstractionSwComponentType.</div>
     */
    @PublishedMethod
    void ioHwAbstraction();

    /**
     * <div class="extdoc" id="complexDeviceDriver">{@link #complexDeviceDriver()} matches component types which are complex device driver component types.</div>
     */
    @PublishedMethod
    void complexDeviceDriver();

    /**
     * <div class="extdoc" id="serviceProxy">{@link #serviceProxy()} matches component types which are service proxy component types.</div>
     */
    @PublishedMethod
    void serviceProxy();

    /**
     * <div class="extdoc" id="instantiated">{@link #instantiated()} matches component types that are already instantiated. In other words matches if a component prototype of
     * that component type already exists.</div>
     */
    @PublishedMethod
    void instantiated();

    /**
     * <div class="extdoc" id="supportsMultipleInstantiation">{@link #supportsMultipleInstantiation()} matches component types which support multiple instantiation.</div>
     */
    @PublishedMethod
    void supportsMultipleInstantiation();

    /**
     * <div class="extdoc" id="put">{@link #put(List)} can be used to set {@link IComponentType}s into the selection. This is the most efficient way to create a selection from
     * existing objects. If further predicates are specified the predicates will be applied only on the component types that were given into this {@link #put(List)} method. The
     * iteration order is relevant for getting deterministic results on further usage of the selection API. This method should only be called once.</div>
     *
     * @throws SelectionException if the method is called more than once or if the given componentTypes are null.
     */
    @PublishedMethod
    void put(List<IComponentType> componentTypes);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IComponentType> getSelectedComponentTypes();

}
