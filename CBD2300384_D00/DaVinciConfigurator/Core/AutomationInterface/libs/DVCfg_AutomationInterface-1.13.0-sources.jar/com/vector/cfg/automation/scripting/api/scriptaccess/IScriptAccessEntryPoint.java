package com.vector.cfg.automation.scripting.api.scriptaccess;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScript;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IScriptAccessEntryPoint} is the entry point for {@link IScriptAccess} related API to retrieve existing {@link IScript}s and call {@link IScriptTask} from another
 * running {@link IScriptTask}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptAccessEntryPoint {

    /**
     * Returns the {@link IScriptAccess}.
     *
     * @return the script access
     */
    @PublishedMethod
    IScriptAccess getScripts();

    /**
     * Executes the specified closure with the {@link IScriptAccess} as delegate.
     *
     * @param code
     * @return the closures return value
     */
    @PublishedMethod
    <T> T scripts(@Nonnull @VDelegatesToWithClosureParam(IScriptAccess.class) Closure<T> code);
}
