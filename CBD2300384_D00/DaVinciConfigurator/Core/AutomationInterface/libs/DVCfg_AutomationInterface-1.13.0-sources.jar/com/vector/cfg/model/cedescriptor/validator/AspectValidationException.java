package com.vector.cfg.model.cedescriptor.validator;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class AspectValidationException extends Exception {
    private static final long serialVersionUID = 7959509844040004265L;

    /**
     * Constructor for AspectValidationException.
     *
     */
    @PublishedMethod
    public AspectValidationException() {
    }

    /**
     * Constructor for AspectValidationException.
     *
     * @param message
     */
    @PublishedMethod
    public AspectValidationException(String message) {
        super(message);
    }

    /**
     * Constructor for AspectValidationException.
     *
     * @param cause
     */
    @PublishedMethod
    public AspectValidationException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor for AspectValidationException.
     *
     * @param message
     * @param cause
     */
    @PublishedMethod
    public AspectValidationException(String message, Throwable cause) {
        super(message, cause);
    }

}
