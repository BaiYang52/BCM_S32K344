package com.vector.cfg.model.access;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation;DvCfgDevDocu">
 * <h3>DefRef Wildcards</h3> <!--LaTeX:\label{sec:IDefRefWildcard}--> The {@link DefRef} class supports so called wildcards, which could be used to match on multiple packages at
 * once, like the <code>/[MICROSAR]</code> wildcard matches on any DefRef package starting with <code>/MICROSAR</code>. E.g. <code>/MICROSAR, /MICROSAR/S12x, ...</code>.
 * <p>
 * Every wildcard is of type {@link IDefRefWildcard}. An {@link IDefRefWildcard} instance could be passed to the {@link DefRef#create(IDefRefWildcard, String)} method to create
 * a DefRef with wildcard information.
 * </p>
 *
 * <!--LaTeX:\includeJavaDoc{EDefRefWildcard/Common}-->
 *
 * <h4>Custom DefRef Wildcards</h4> You could create your own wildcard by implementing the interface {@link IDefRefWildcard}. Please choose a good name for your wildcard,
 * because this could be displayed to the user, e.g. in Validation results. The {@link #matches(DefRef)} method shall return true, if the passed DefRef matches the wildcard
 * constraints.
 * <p>
 * Every wildcard string shall have the notation <code>/[NameOfWildcard].<br/>E.g. /[MICROSAR], /[!MICROSAR]</code>.
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see DefRef
 * @see EDefRefWildcard
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDefRefWildcard {

    /**
     * Gets the user friendly wildcard string.
     *
     * <p>
     * Every wildcard string shall have the notation /[NameOfWildcard]. E.g. /[MICROSAR], /[!MICROSAR].
     * </p>
     *
     * @return the wildcard string
     */
    @PublishedMethod
    String getWildcardString();

    /**
     * Returns true in the wildcard matches the DefRef.
     *
     * <p>
     * <b>Attention:</b>You must not evaluate the DefRefStringWithoutPackagePart of the DefRef! The second part of the DefRef could be different (see isParentOf check!).
     * </p>
     *
     * @param defRefToMatch the DefRef to match
     * @return true, if the wildcard matches the defRef
     * @see DefRef
     */
    @PublishedMethod
    boolean matches(DefRef defRefToMatch);

    /**
     * Returns <code>true</code>, if the refinement search shall continue for this definition of this {@link IDefRefWildcard}. If the method returns <code>false</code>, the
     * refinement search algorithm will stop at this definition.
     *
     * <p>
     * This could be used to filter e.g. all /MICROSAR definition which also refine from /AUTOSAR, but /AUTOSAR shall be included in the Wildcard.
     * </p>
     *
     * @param moduleDefRefs The found refinement modules
     * @return true, if the refinement search shall continue with this definition
     *
     */
    @PublishedMethod
    boolean continueRefinementSearchFor(DefRef moduleDefRef);

}
