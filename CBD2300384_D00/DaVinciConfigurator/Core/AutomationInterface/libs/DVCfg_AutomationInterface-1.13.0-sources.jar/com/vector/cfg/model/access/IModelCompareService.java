package com.vector.cfg.model.access;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.base.api.compare.IModelComparator;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARRef;
import com.vector.cfg.model.mdf.model.autosar.base.MIARAnyInstanceRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfigurationRefConditional;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;

/**
 * This interface provides means for comparing model objects.
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ReworkThisAtNextBreakingChange("Remove this services and replace if by IAutosarModelComparator")
public interface IModelCompareService {

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIParameterValue par1, MIParameterValue par2);

    /**
     * Returns <code>true</code> if the specified parameters have the same value but doesn't take the definition into account. Returns also <code>true</code> if both arguments are
     * <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equalsValue(MIParameterValue par1, MIParameterValue par2);

    /**
     * Returns <code>true</code> if the specified parameter lists have the same number of instances and the same values. Additionally the types (MDF class) of all parameters must
     * be identical.
     *
     * @param orderIsRelevant specifies if the order of the instances is relevant
     * @param pars1
     * @param pars2
     * @return
     */
    @PublishedMethod
    boolean equalsValues(boolean orderIsRelevant, List<MIParameterValue> pars1, List<MIParameterValue> pars2);

    /**
     * Returns <code>true</code> if the specified objects have the same definition. Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param hasDef1 one of the objects to be checked
     * @param hasDef2 one of the objects to be checked
     * @return
     */
    @PublishedMethod
    boolean equalsDefinition(MIHasDefinition hasDef1, MIHasDefinition hasDef2);

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MINumericalValue par1, MINumericalValue par2);

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MITextualValue par1, MITextualValue par2);

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIEcucAddInfoParamValue par1, MIEcucAddInfoParamValue par2);

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIReferenceValue par1, MIReferenceValue par2);

    /**
     * Returns <code>true</code> if the specified parameters are equal (same value and definition). Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param par1 one of the parameters to be checked
     * @param par2 one of the parameters to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIInstanceReferenceValue par1, MIInstanceReferenceValue par2);

    /**
     * Returns <code>true</code> if the specified objects are equal. Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param iRef1 one of the instance refs to be checked
     * @param iRef2 one of the instance refs to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIARAnyInstanceRef iRef1, MIARAnyInstanceRef iRef2);

    /**
     * Returns <code>true</code> if the specified references are equal. Returns also <code>true</code> if both arguments are <code>null</code>.
     *
     * @param ref1 one of the references to be checked
     * @param ref2 one of the references to be checked
     * @return
     */
    @PublishedMethod
    boolean equals(MIARRef ref1, MIARRef ref2);

    /**
     * Calculates a hash code for the specified object.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param iRef is the instance ref, the hash code shall be calculated for
     * @return
     */
    @PublishedMethod
    int hashCode(MIARAnyInstanceRef iRef);

    /**
     * Calculates a hash code for the specified object.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param ref is the reference, the hash code shall be calculated for
     * @return
     */
    @PublishedMethod
    int hashCode(MIARRef ref);

    /**
     * Implements the usual compare semantic for the specified objects.
     *
     * @param iRef1 is one of the instance refs to be compared
     * @param iRef2 is one of the instance refs to be compared
     * @return
     */
    @PublishedMethod
    int compareTo(MIARAnyInstanceRef iRef1, MIARAnyInstanceRef iRef2);

    /**
     * Implements the usual compare semantic for the specified objects. For references this means comparing the value strings of the reference objects.
     *
     * @param ref1 is one of the references to be compared
     * @param ref2 is one of the references to be compared
     * @return
     */
    @PublishedMethod
    int compareTo(MIARRef ref1, MIARRef ref2);

    /**
     * Implements the usual compare semantic for the specified objects.
     *
     * @param ref1
     * @param ref2
     * @return
     */
    @KeepSecretFromPublishedApi
    int compareTo(MIModuleConfigurationRefConditional ref1, MIModuleConfigurationRefConditional ref2);

    /**
     * Returns a new {@link IModelComparator} instance.
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    IModelComparator newModelComparator();

}
