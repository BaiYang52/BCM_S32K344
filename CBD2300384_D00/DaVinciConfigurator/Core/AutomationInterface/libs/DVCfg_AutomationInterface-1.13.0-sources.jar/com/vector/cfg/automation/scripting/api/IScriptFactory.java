package com.vector.cfg.automation.scripting.api;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The {@link IScriptFactory} interface provides the entry point that Java code could provide script tasks.
 *
 * <div class="extdoc" id="Common"> Java code could not use the Groovy syntax to provide script tasks. So another way is needed for this. The {@link IScriptFactory} interface
 * provides the entry point that Java code could provide script tasks. The {@link #createScript(IScriptCreationApi)} method is called when the script is loaded.
 *
 * <p>
 * This interface is <b>not</b> necessary for Groovy clients.
 * </p>
 * </div>
 * <p>
 * Note: This interface is intended to be implemented by clients as entry point into the scripting system for java clients.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IScriptFactory {

    /**
     * The {@link #createScript(IScriptCreationApi)} method is called, when the script is loaded. The java code could use the {@link IScriptCreationApi} to create script tasks.
     *
     * <p>
     * The method is only called once during startup.
     * </p>
     *
     * @param creationApi the creation api
     */
    @PublishedMethod
    void createScript(IScriptCreationApi creationApi);
}
