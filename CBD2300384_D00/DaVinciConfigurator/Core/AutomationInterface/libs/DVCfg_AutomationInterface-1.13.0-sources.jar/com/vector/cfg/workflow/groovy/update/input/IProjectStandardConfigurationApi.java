package com.vector.cfg.workflow.groovy.update.input;

import java.util.List;
import java.util.function.Consumer;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.util.annotations.DeferredExecution;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * API for the modification of the list of Project Standard Configuration files.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectStandardConfigurationApi {
    /**
     * modifies the list of project standard configurations.
     *
     * <p>
     * <b>Note: This closure is deferred executed in the same thread as the script.</b>
     * </p>
     *
     * Example:
     *
     * <pre>
     * <code>
     standardConfigurationFiles{
        // clear the list of standard configurations
        it.clear()
        // adds a standard configurations
        it.add(standardConfigurationPath)
    }
     * </code>
     * </pre>
     *
     * @param code
     */
    @PublishedMethod
    void standardConfigurationFiles(
            @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @DelegatesTo(target = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>", strategy = Closure.DELEGATE_FIRST) @ClosureParams(value = FromString.class, options = "java.util.List<com.vector.cfg.persistency.groovy.api.IPersistablePath>") Closure<?> code);

    /**
     * See {@link IProjectStandardConfigurationApi#standardConfigurationFiles(Closure)} for more information.
     *
     * @param code
     */
    @PublishedMethod
    void standardConfigurationFiles(
            @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Consumer<List<IPersistablePath>> code);
}