package com.vector.cfg.project.evs.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IImportVariantApiEntryPoint {

    /**
     * <div class="extdoc" id="varimport"> Use the {@link IImportVariantApiEntryPoint#importVariant(Object, Object, Closure)} closure to import a predefined evaluate variant set
     * for a given project.</div>
     *
     * @param <T>         The ISelectVariantApi
     * @param dpaFilePath The project dpa file
     * @param evsFilePath The predefined evs file
     * @param code        The code
     * @return the ISelectVariantApi
     */
    @PublishedMethod
    <T> T importVariant(Object dpaFilePath, Object evsFilePath, @VDelegatesToWithClosureParam(IImportVariantApi.class) Closure<T> code);

    /**
     * see {@link #importVariant(Object, Object)} for more information.
     */
    @PublishedMethod
    void importVariant(Object dpaFilePath, Object evsFilePath);
}
