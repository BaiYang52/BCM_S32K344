package com.vector.cfg.model.access;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * This enum identifies ECUC parameter types.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EParameterType {

    /**
     * Specific types (can be detected if the parameters definition is available).
     */
    BOOLEAN("Boolean"),
    INTEGER("Integer"),
    FLOAT("Float"),
    ENUMERATION("Enumeration"),
    STRING("String"),
    LINKER_SYMBOL("Linker Symbol"),
    FUNCTION_NAME("Function Name"),
    MULTILINE_STRING("Multiline string"),
    REFERENCE("Reference"),
    SYMBOLIC_NAME_REFERENCE("Symbolic Name Reference"),
    CHOICE_REFERENCE("Choice Reference"),
    FOREIGN_REFERENCE("Foreign Reference"),
    INSTANCE_REFERENCE("Instance Reference"),
    ADD_INFO("Formated text"),

    /**
     * Unspecific types (if the parameters definition is not available).
     */
    NUMERIC("Numeric"),
    TEXT("Text"),

    /**
     * Undetected.
     */
    UNKNOWN("Unknown");

    private final String descriptiveName;

    EParameterType(String descriptiveName) {
        this.descriptiveName = descriptiveName;

    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }
}
