package com.vector.cfg.dom.runtimesys.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.connection.IConnector;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;

/**
 * <div class="extdoc" id="IUnmappedPortsResult"><!--Label:IUnmappedPortsResult-->{@link IUnmappedPortsResult} represents two {@link IComponentPort}s that were previously
 * connected by an {@link IConnector} and are disconnected (unmapped) now.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUnmappedPortsResult {

    /**
     * <p>
     * <div class="extdoc" id="getSourcePort"><!--Label:IUnmappedPortsResult.getSourcePort-->{@link #getSourcePort()} is a getter for the source component port which was
     * disconnected from a target component port (can be accessed via {@link #getTargetPort()}). </div>
     * </p>
     *
     * @return The source component port which was previously connected by an {@link IConnector} to the {@link #getTargetPort()}.
     */
    @PublishedMethod
    IComponentPort getSourcePort();

    /**
     * <p>
     * <div class="extdoc" id="getTargetPort"><!--Label:IUnmappedPortsResult.getTargetPort-->{@link #getTargetPort()} is a getter for the target component port which was
     * disconnected from a source component port (can be accessed via {@link #getSourcePort()}). </div>
     * </p>
     *
     * @return The target component port which was previously connected by an {@link IConnector} to the {@link #getSourcePort()}.
     */
    @PublishedMethod
    IComponentPort getTargetPort();

}
