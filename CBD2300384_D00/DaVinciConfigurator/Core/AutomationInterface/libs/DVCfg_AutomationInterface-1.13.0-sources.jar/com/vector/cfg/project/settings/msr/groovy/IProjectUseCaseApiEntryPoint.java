package com.vector.cfg.project.settings.msr.groovy;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common"> The {@link IProjectUseCaseApiEntryPoint} enables querying or modifying the "use case" project setting. Use case limits the application of
 * pre-configuration or recommended configuration in particular application cases. The following section describes how an use case can be accessed and modified. </div> <br>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IProjectUseCaseApiEntryPoint {

    /**
     * Use {@link #getUseCases()} to specify the use case project settings.
     *
     * <div class="extdoc" id="getUsecase"><!--Label:IProjectUseCaseApiEntryPoint.getUsecase-->Use {@link #getUseCases()} or {@link #useCases(Closure)} to access the use case context
     * of the project settings. </div>
     */
    @PublishedMethod
    IProjectUseCaseApi getUseCases();

    /**
     * Use {@link #useCases(Closure)} to access the use case project settings in a scope-like way.
     *
     * @param code code providing the project settings useCase
     * @see #getUseCases()
     */
    @PublishedMethod
    <T> T useCases(@VDelegatesToWithClosureParam(IProjectUseCaseApi.class) Closure<T> code);

}
