package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IExecutableEntity;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IExecutableEntitySelection"><!--Label:IExecutableEntitySelection-->{@link IExecutableEntitySelection} represents a selection of
 * {@link IExecutableEntity}s and the possible operations on these.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExecutableEntitySelection {

    /**
     * <div class="extdoc" id="mapToTask"><!--Label:IExecutableEntitySelection.mapToTask-->{@link #mapToTask(Closure)} tries to perform a task mapping for the selection of
     * executable entities (functions). Inside the closure the task mapping can be controlled, e.g. selecting the task to which the events (triggers) of the selected executable
     * entities should be mapped to and order the event's positions.</div>
     *
     * <p>
     * The executable entity selection will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.IExecutableEntitySelection}' logger with the appropriate log level.
     * </p>
     *
     * @param code The code to provide select a task and order the task mappings.
     * @return A list of created task mappings.
     * @throws Throws a {@link SelectionException} if more than one or none task is selected inside the closure.
     */
    @PublishedMethod
    List<? extends ITaskMapping> mapToTask(@Nonnull @VDelegatesToWithClosureParam(ITaskMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="setActivationOffset"><!--Label:IExecutableEntitySelection.setActivationOffset-->{@link #setActivationOffset(BigDecimal)} sets the activation offset
     * at the task mapping containers for the selected executable entities.</div> If the symbol of a schedulable entity matches a runnable name, the activation offset will be set
     * for both, even if only one of them is selected. (Matching works as for {@link ITaskMapper#combineViaSymbol(boolean)}.)
     *
     * @param offsetInSeconds The activation offset (in seconds) which should be set.
     * @return A list of task mappings whose activation offset was set.
     *
     * @throws NullPointerException if the given offsetInSeconds is null.
     */
    @PublishedMethod
    List<ITaskMapping> setActivationOffset(@Nonnull BigDecimal offsetInSeconds);

    /**
     * <div class="extdoc" id="setOsSchedulePoint"><!--Label:IExecutableEntitySelection.setOsSchedulePoint-->{@link #setOsSchedulePoint(String)} sets the OsSchedulePoint at the
     * task mapping containers for the selected executable entities.</div> If the symbol of a schedulable entity matches a runnable name, the OsSchedulePoint will be set for both,
     * even if only one of them is selected. (Matching works as for {@link ITaskMapper#combineViaSymbol(boolean)}.)
     *
     * @param setOsSchedulePoint The schedule point value which should be set.
     * @return A list of task mappings whose OsSchedulePoint was set.
     *
     * @throws NullPointerException if the given osSchedulePoint is null.
     */
    @PublishedMethod
    List<ITaskMapping> setOsSchedulePoint(@Nonnull String osSchedulePoint);

    /**
     * <div class="extdoc" id="getExecutableEntities"><!--Label:IExecutableEntitySelection.getExecutableEntities-->{@link #getExecutableEntities()} allows access to the single
     * executable entities in the {@link IExecutableEntitySelection}.</div>
     *
     * @return The collection of selected {@link IExecutableEntity}s.
     */
    @PublishedMethod
    Collection<? extends IExecutableEntity> getExecutableEntities();

    /**
     * <div class="extdoc" id="getTaskMappings"><!--Label:IExecutableEntitySelection.getTaskMappings-->{@link #getTaskMappings()} retrieves all {@link ITaskMapping}s for the
     * selected executable entities (see {@link #getExecutableEntities()}).<br>
     * </div>
     * <p>
     * Note: <br>
     * 1. In case of multi instantiation of component prototypes, the different instances share the same executable entities, since the executable entity is part of the internal
     * behavior of the component type. Therefore if the executable entity is selected, {@link #getTaskMappings()} will always return the task mappings for all component
     * prototypes.<br>
     * 2. Since this method can be run outside of a transaction, there might be selected executable entities for which no task mapping container does exist yet. The container
     * cannot be created by calling {@link #getTaskMappings()}, so no task mapping can be returned. This happens if the system description is not synchronized, after changes in the
     * structured extract were done (see Automation Interface Documentation, chapter about Model Synchronization for examples how to synchronize).
     * </p>
     *
     * @return A list of the task mappings which references events that trigger the selected executable entities.
     */
    @PublishedMethod
    Collection<ITaskMapping> getTaskMappings();

}
