package com.vector.cfg.consistency.groovy.extensions;

import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.ActiveProjectContextHolder;
import com.vector.cfg.consistency.core.impl.util.ConsistencyFilterUtil;
import com.vector.cfg.consistency.groovy.api.IValidationApi;
import com.vector.cfg.consistency.requester.util.ValidationResultUtil;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This class contains consistency-related groovy-extension-methods, e.g. for getting validation-results of an {@link MIObject} or {@link DefRef}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class GroovyConsistencyMethodExtensions {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GroovyConsistencyMethodExtensions.class);

    private GroovyConsistencyMethodExtensions() {
    }

    /**
     * <div class="extdoc" id="getValidationResultsExtDefRef"><code>DefRef.getValidationResults()</code> returns all validation-results which match the passed definition. So every
     * configuration element which matches the validation-result and is an instance of definition.
     *
     * The used project for this call is the active project, see <code>ScriptApi.getActiveProject()</code>.
     *
     * </div>
     *
     * @param defRef the def ref
     * @return the validation results
     */
    // DefRef
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final DefRef defRef) {
        final IValidationApi validationApi = ActiveProjectContextHolder.INSTANCE.getCurrentActiveProjectOfThisThreadChecked().getService(IValidationApi.class);
        return validationApi.getValidationResults()
                .stream()
                .filter(vr -> vr.matchErroneousCE(null, defRef))
                .sorted(validationResultComparator())
                .collect(Collectors.toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object.
     *
     * <div class="extdoc" id="getValidationResultsExtMiObject"><code>MIObject.getValidationResults()</code> returns the validation-results of an {@link MIObject}. These are those
     * results for which {@link IValidationResultUI#matchErroneousCE(MIObject)} returns true. </div>
     *
     * @param self the model object
     * @return the validation results
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final MIObject self) {

        final Stream<IValidationResultUI> stream = validationApi(self).getValidationResults().stream();
        return stream
                .filter(ConsistencyFilterUtil.filterValidationResultsMatchErroneousCE(self))
                .sorted(validationResultComparator())
                .collect(toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object and all its children.
     *
     * <div class="extdoc" id="getValidationResultsRecursiveMiObject"><code>MIObject.getValidationResultsRecursive()</code> returns the validation-results of an {@link MIObject}
     * and all its children. So this will return all results of the whole subtree, like an editor displays results at parent objects. </div>
     *
     * @param self the model object
     * @return the validation results
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResultsRecursive(final MIObject self) {

        final Stream<IValidationResultUI> stream = validationApi(self).getValidationResults().stream();
        return stream
                .filter(ConsistencyFilterUtil.filterValidationResultsMatchErroneousCEModelSubtreeRecursive(self))
                .sorted(validationResultComparator())
                .collect(toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object.
     *
     * <div class="extdoc" id="getValidationResultsExtViewedModelObject"><code>IViewedModelObject.getValidationResults()</code> returns the validation-results for the element
     * matching the model object and the model view, like BswmdModel objects. </div>
     *
     * <p>
     * The following condition must be true to match:
     *
     * <pre>
     * <code>IValidationResultUI.matchErroneousCE(theObject) &&
     * (
     *   IValidationResultUI.isGeneralVariantContext() ||
     *   IValidationResultUI.getPredefinedVariantContexts().contains(theView)
     * )</code>
     * </pre>
     * </p>
     *
     *
     * @param self the model object
     * @return the validation results
     * @see IValidationResultUI#matchErroneousCE(IViewedModelObject)
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final IViewedModelObject self) {
        final MIObject mdfObject = self.getMdfObject();
        final IModelView modelView = self.getCreationModelView();

        final Stream<IValidationResultUI> stream = validationApi(mdfObject).getValidationResults().stream();
        return stream
                .filter(ConsistencyFilterUtil.filterValidationResultsMatchErroneousCE(mdfObject))
                .filter(vr -> vr.isResultValidInModelView(modelView))
                .sorted(validationResultComparator())
                .collect(toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object and all its children.
     *
     * <div class="extdoc" id="getValidationResultsRecursiveViewedModelObject"><code>IViewedModelObject.getValidationResultsRecursive()</code> returns the validation-results of an
     * {@link MIObject} for the elements like BswmdModel objects all its children. This will also filter for the correct {@link IModelView}. So this will return all results of the
     * whole subtree, like an editor displays results at parent objects.
     *
     * </div>
     *
     * @param self the model object
     * @return the validation results
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResultsRecursive(final IViewedModelObject self) {
        final MIObject mdfObject = self.getMdfObject();
        final IModelView modelView = self.getCreationModelView();
        final Stream<IValidationResultUI> stream = validationApi(mdfObject).getValidationResults().stream();
        return stream
                .filter(ConsistencyFilterUtil.filterValidationResultsMatchErroneousCEModelSubtreeRecursive(mdfObject))
                .filter(vr -> vr.isResultValidInModelView(modelView))
                .sorted(validationResultComparator())
                .collect(toList());
    }

    /* ----------------------------------------------------------------------------------------------------
     * Helper methods
     */

    private static IValidationApi validationApi(final MIObject self) {
        return ModelUtil.getService(self, IValidationApi.class);
    }

    private static Comparator<IValidationResultUI> validationResultComparator() {
        return ValidationResultUtil.validationResultUIComparator();
    }

}
