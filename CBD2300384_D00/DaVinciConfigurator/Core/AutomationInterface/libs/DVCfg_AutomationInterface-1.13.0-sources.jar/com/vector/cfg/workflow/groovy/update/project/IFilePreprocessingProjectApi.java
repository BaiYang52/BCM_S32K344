package com.vector.cfg.workflow.groovy.update.project;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.update.IModuleDefinitionMappingApi;
import com.vector.cfg.workflow.groovy.update.IMultiDriverMappingApi;
import com.vector.cfg.workflow.groovy.update.ISelectiveUpdateApi;
import com.vector.cfg.workflow.groovy.update.IUpdateApi.IUpdateSettingsApi;
import com.vector.cfg.workflow.groovy.update.fileset.IFileSet;
import com.vector.cfg.workflow.groovy.update.fileset.IFileSetApi;

import groovy.lang.Closure;

/**
 * Allows to start only the file preprocessing part of the Update Workflow without the project update.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IFilePreprocessingProjectApi {

    /**
     * Gets a list of all available {@link IFileSet}.
     *
     * <div class="extdoc" id="getAvailableFileSets"> Use {@link #getAvailableFileSets()} to get a list with all available file sets. For non-Variant projects, only one file set
     * is available.<br>
     * </div>
     *
     * @return List of all {@link IFileSet}
     */
    @PublishedMethod
    List<IFileSet> getAvailableFileSets();

    /**
     * Get the {@link IFileSet} with the given name.<br>
     * <div class="extdoc" id="getFileSetByName"> Use {@link #getFileSetByName(String)} to get the file set with the given name. This method can be used to get the according
     * file set of one specific variant.<br>
     * </div><br>
     * throws WorkflowExecutionException if no {@link IFileSet} with the given name was found.
     *
     * @param name the name
     * @return the file set by name
     */
    @PublishedMethod
    IFileSet getFileSetByName(String name);

    /**
     * modifies the given file set.
     *
     * <pre>
     * <code>
     *        fileSet(myFileSet){
     *            inputFiles {
     *                clear()
     *            }
     *        }
     * </code>
     * </pre>
     *
     * @param <T> the generic type
     * @param fileSet the file set
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    <T> T fileSet(IFileSet fileSet, @VDelegatesToWithClosureParam(IFileSetApi.class) Closure<T> code);

    /**
     * modifies the existing file set. Call this method only in case there is only one file set available. (e.g. for non variant projects).
     *
     * <pre>
     * <code>
     *        fileSet(){
     *            inputFiles {
     *                clear()
     *            }
     *        }
     * </code>
     * </pre>
     */
    @PublishedMethod
    <T> T fileSet(@VDelegatesToWithClosureParam(IFileSetApi.class) Closure<T> code);

    /**
     * Configuration of common update settings.
     *
     * <p>
     * Usage example to set some update settings:
     *
     * <pre>
     * <code class="Java" id="description">
     * update(Paths.get("MyProject.dpa")){
     *   updateSettings{
     *     updateMode = ECUC_ONLY
     *     uuidUsageInStandardConfigurationEnabled = false
     *   }
     * }
     *
     * </code>
     * </pre>
     * </p>
     *
     * @param code the code
     */
    @PublishedMethod
    void updateSettings(@VDelegatesToWithClosureParam(IUpdateSettingsApi.class) Closure<?> code);

    /**
     * Configuration of the selective update setting.
     *
     * <p>
     * Usage example to set some selective update settings:
     *
     * <pre>
     * <code class="Java" id="selectiveUpdate">
     *  Use the selective update api to enable/disable the selective update.
     * </code>
     * </pre>
     * </p>
     *
     * @param <T> the generic type
     * @param value the value
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    <T> T selectiveUpdate(boolean value, @VDelegatesToWithClosureParam(ISelectiveUpdateApi.class) Closure<T> code);

    /**
     * Configuration of the selective update setting.
     *
     * <p>
     * Usage example to disable selective update:
     *
     * <pre>
     * <code class="Java" id="description">
     *  update(Paths.get("MyProject.dpa")) {
     *   selectiveUpdate(false)
     *  }
     * </code>
     * </pre>
     * </p>
     *
     * @param <T> the generic type
     * @param value the value
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    void selectiveUpdate(boolean value);

    /**
     * Configuration of the MultiDriver mappings. The configuration has to be done at the end of the 'update' closure to be sure that all input files are added before.
     *
     * <div class="extdoc" id="multiDriverMapping">
     * <p>
     * Usage example to configure the mappings (if available):
     *
     * <pre>
     * <code class="Java" id="description">
     *   filePreprocessing(Paths.get("MyProject.dpa")) {
     *
     *     if(isMultiDriverMappingAvailable()) {
     *
     *       multiDriverMapping {
     *         def cluster = getAllClusterPaths().get(0)
     *         def defRef = getAvailableDefinitionsForCluster(firstCluster).get(0)
     *
     *         mapClusterToDefinition(cluster, defRef)
     *
     *       }
     *     }
     *   }
     * </code>
     * </pre>
     * </p>
     * </div>
     *
     * @param <T> the genric type
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    <T> T multiDriverMapping(@VDelegatesToWithClosureParam(IMultiDriverMappingApi.class) Closure<T> code);

    /**
     * Checks if a MultiDriver mapping is available.
     *
     *
     * <h2>Is MultiDriver mapping available</h2>
     * <p>
     * <div class="extdoc" id="isMultiDriverMappingAvailable">Using {@link #isMultiDriverMappingAvailable()} will check if MultiDriver mappings are available in the given
     * project. </div>
     * </p>
     *
     * @return {@code true} if MultiDriver mappings are available otherwise {@code false}.
     */
    @PublishedMethod
    boolean isMultiDriverMappingAvailable();

    /**
     * Configuration of the module to definition mappings.
     *
     * <div class="extdoc" id="moduleDefinitionMapping">
     * <p>
     * Usage example to configure the mappings (if available):
     *
     * <pre>
     * <code class="Java" id="Module to definition mapping">
     *   filePreprocessing(Paths.get("MyProject.dpa")) {
     *
     *     if(hasAmbigiousModuleDefinitionMappings()) {
     *
     *       moduleDefinitionMapping {
     *         def moduleConfig = getAmbiguousModuleConfigs().get(0)
     *         def definitionList = getAvailableDefinitionsForModule(moduleConfig)
     *         if(!definitionList.isEmpty()) {
     *              def definition = definitionList.get(0)
     *              mapModuleToDefinition(moduleConfig, definition)
     *         }
     *       }
     *     }
     *   }
     * </code>
     * </pre>
     * </p>
     * </div>
     *
     * @param <T> <T> the generic type
     * @param code The code
     * @return The t
     */
    @PublishedMethod
    <T> T moduleDefinitionMapping(@VDelegatesToWithClosureParam(IModuleDefinitionMappingApi.class) Closure<T> code);

    /**
     * Checks if at least one single-instance module can not be resolved automatically and the mapping has to be set.
     *
     *
     * <h2>Has ambigious module definition mapping</h2>
     * <p>
     * <div class="extdoc" id="hasAmbigiousModuleDefinitionMappings">Using {@link #hasAmbigiousModuleDefinitionMappings()} will check if some single-instance modules can not be
     * mapped automatically to a definition. </div>
     * </p>
     *
     * @return {@code true} if ModuleConfigs need to be mapped, otherwise {@code false}.
     */
    @PublishedMethod
    boolean hasAmbigiousModuleDefinitionMappings();

}
