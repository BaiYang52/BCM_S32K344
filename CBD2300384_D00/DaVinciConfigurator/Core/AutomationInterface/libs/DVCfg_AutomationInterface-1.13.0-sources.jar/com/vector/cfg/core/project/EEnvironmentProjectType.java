package com.vector.cfg.core.project;

import java.util.Arrays;
import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.core.project.internal.EnvironmentProjectTypeUtils;

/**
 * <div class="extdoc" id="CommonModel" data-target-doc="ModelDocumentation">
 *
 * The {@link EEnvironmentProjectType} represents the possible project types.
 *
 * <pre>
 * <code class="Java" id="EEnvironmentProjectType usage sample">
 * final EEnvironmentProjectType projectType = projectContext.getService(IDpaAccessPublished.class).getProjectType();
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IDpaAccessPublished
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
@ThreadSafe
public enum EEnvironmentProjectType {

    STANDARD(
            EnvironmentProjectTypeUtils.standard,
            EnvironmentProjectTypeUtils.standard),

    /**
     * @deprecated Please use {@link #SOFTWARE_CLUSTER_CONNECTION}.
     */
    @Deprecated
    CLASSIC_PLATFORM_FLEXIBILITY(
            EnvironmentProjectTypeUtils.cpfSerialization,
            EnvironmentProjectTypeUtils.cpfLiteral),

    SOFTWARE_CLUSTER_CONNECTION(
            EnvironmentProjectTypeUtils.sccSerialization,
            EnvironmentProjectTypeUtils.sccLiteral);

    private final String serializationValue;

    private final String literalValue;

    EEnvironmentProjectType(final String serializationValue, final String literalValue) {
        this.serializationValue = serializationValue;
        this.literalValue = literalValue;
    }

    /**
     * Gets the literal value which is used for UI representation of the type.
     *
     * @return the literal value.
     */
    @KeepSecretFromPublishedApi
    public String getLiteralValue() {
        return literalValue;
    }

    /**
     * Gets the literal value which is used for serialization of the type.
     *
     * @return the literal value.
     */
    @KeepSecretFromPublishedApi
    public String getSerializationValue() {
        return serializationValue;
    }

    /**
     * Gets the corresponding ENUM value for the given literal value.
     *
     * @param the literal value.
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentProjectType#STANDARD} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentProjectType getItemForLiteralValue(String value) {
        if (value != null) {
            return Arrays.stream(EEnvironmentProjectType.values()).filter(type -> type.getLiteralValue().equalsIgnoreCase(value)).findAny().orElse(STANDARD);
        }
        return EEnvironmentProjectType.STANDARD;
    }

    /**
     * Gets the corresponding ENUM value for the given serialization literal value.
     *
     * @param the literal value.
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentProjectType#STANDARD} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentProjectType getItemForSerializationValue(String value) {
        if (value != null) {
            return Arrays.stream(EEnvironmentProjectType.values()).filter(type -> type.getSerializationValue().equalsIgnoreCase(value)).findAny().orElse(STANDARD);
        }
        return EEnvironmentProjectType.STANDARD;
    }

    /**
     * Gets the corresponding 'child' domains (sub-types) ({@link EEnvironmentProjectTypeDomain}).
     *
     * @return the corresponding {@link EEnvironmentProjectTypeDomain}s.
     */
    @KeepSecretFromPublishedApi
    public List<EEnvironmentProjectTypeDomain> getDomains() {
        switch (this) {
        case CLASSIC_PLATFORM_FLEXIBILITY:
        case SOFTWARE_CLUSTER_CONNECTION:
            return Arrays.asList(new EEnvironmentProjectTypeDomain[] {
                    EEnvironmentProjectTypeDomain.GLOBAL_RESOURCE_DB,
                    EEnvironmentProjectTypeDomain.SYSTEM_EXTRACT,
                    EEnvironmentProjectTypeDomain.HOST_APPLICATIVE_CLUSTER
            });
        case STANDARD:
        default:
            // Avoid returning an empty list here -> NONE is a sufficient indicator
            return Arrays.asList(new EEnvironmentProjectTypeDomain[] {
                    EEnvironmentProjectTypeDomain.NONE
            });
        }
    }

}
