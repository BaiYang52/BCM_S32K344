package com.vector.cfg.model.state;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interface specifies a type-safe published API for module configuration states.
 *
 * Instances of related CeState implementations can be created by means of {@link CeStatePublishedFactory}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModuleConfigurationStatePublished extends IHasContainerStatePublished {

    /**
     * Returns the same object as {@link #getSupervisedObject()} but type-safe.
     *
     * @return Never returns <code>null</code>
     */
    @PublishedMethod
    Optional<MIModuleConfiguration> getSupervisedModuleConfiguration();

}