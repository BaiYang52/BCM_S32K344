package com.vector.cfg.util.scripting.groovy;

import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.util.concurrent.Callable;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.codehaus.groovy.runtime.InvokerHelper;
import org.codehaus.groovy.runtime.MethodClosure;
import org.codehaus.groovy.runtime.ScriptBytecodeAdapter;
import org.codehaus.groovy.runtime.metaclass.MissingMethodExceptionNoStack;

import com.vector.annotations.obfuscation.Keep;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.davinci.util.base.VUtil;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common">
 * <h4>Creating Closure instances from Java lambdas</h4> The class {@link Closures} provides API to create {@link Closure} instances from Java {@link FunctionalInterface}s.
 *
 * <p>
 * The <code>from()</code> methods could be used to call Groovy API from Java classes, which only accepts {@link Closure} instances.
 * </p>
 *
 * <p>
 * Sample:
 *
 * <pre>
 * <code class="Java" id="Java Closure creation sample">
 *  Closure<?> c = Closures.from((param) -> {
 *    // Java lambda
 *  });
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see Closure
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class Closures {

    /**
     * Creates a {@link Closure} from {@link Runnable}.
     *
     * @param run the run
     * @return the closure
     */
    @PublishedMethod
    public static <R> Closure<R> from(Runnable run) {
        return uncheckedCast(new JavaLambdaMethodClosure(run, "run"));
    }

    /**
     * Creates a {@link Closure} from {@link Callable}.
     *
     * @param <T> the generic type
     * @param call the call
     * @return the closure
     */
    @PublishedMethod
    public static <T> Closure<T> from(Callable<T> call) {
        return uncheckedCast(new JavaLambdaMethodClosure(call, "call"));
    }

    /**
     * Creates a {@link Closure} from {@link Function}.
     *
     * @param <T> the type of the input to the function
     * @param <R> the type of the result of the function
     * @param func the function
     * @return the closure
     */
    @PublishedMethod
    public static <T, R> Closure<R> from(Function<T, R> func) {
        return uncheckedCast(new JavaLambdaMethodClosure(func, "apply"));
    }

    /**
     * Creates a {@link Closure} from {@link Function}.
     *
     * @param <T> the type of the first argument to the function
     * @param <U> the type of the second argument to the function
     * @param <R> the type of the result of the function
     * @param func the function
     * @return the closure
     */
    @PublishedMethod
    public static <T, U, R> Closure<R> from(BiFunction<T, U, R> func) {
        return uncheckedCast(new JavaLambdaMethodClosure(func, "apply"));
    }

    /**
     * Creates a {@link Closure} from {@link Consumer}.
     *
     * @param <T> the type of the input to the operation
     * @param consumer the consumer
     * @return the closure
     */
    @PublishedMethod
    public static <T, R> Closure<R> from(Consumer<T> consumer) {
        return uncheckedCast(new JavaLambdaMethodClosure(consumer, "accept"));
    }

    /**
     * Creates a {@link Closure} from {@link BiConsumer}.
     *
     * @param <T> the type of the first argument to the operation
     * @param <U> the type of the second argument to the operation
     * @param consumer the consumer
     * @return the closure
     */
    @PublishedMethod
    public static <T, U> Closure<?> from(BiConsumer<T, U> consumer) {
        return uncheckedCast(new JavaLambdaMethodClosure(consumer, "accept"));
    }

    /**
     * Creates a {@link Closure} from {@link Predicate}.
     *
     * @param <T> the type of the input to the predicate
     * @param predicate the predicate
     * @return the closure
     */
    @PublishedMethod
    public static <T> Closure<Boolean> fromPredicate(Predicate<T> predicate) {
        return uncheckedCast(new JavaLambdaMethodClosure(predicate, "test"));
    }

    /**
     * Creates a {@link Closure} from {@link Supplier}.
     *
     * @param <T> the type of results supplied by this supplier
     * @param supplier the supplier
     * @return the closure
     */
    @PublishedMethod
    public static <T> Closure<T> fromSupplier(Supplier<T> supplier) {
        return uncheckedCast(new JavaLambdaMethodClosure(supplier, "get"));
    }

    private Closures() {

    }

    @Keep
    private static class JavaLambdaMethodClosure extends MethodClosure {
        private static final long serialVersionUID = 4342166787895663824L;

        JavaLambdaMethodClosure(Object owner, String method) {
            super(owner, method);
        }

        @Override
        public Object call(Object... args) {
            try {
                return super.call(args);
            } catch (final MissingMethodExceptionNoStack ex) {
                VUtil.sneakyThrow(ScriptBytecodeAdapter.unwrap(ex));
                return null; //unreachable
            }
        }

        @SuppressWarnings("unused") // used by Groovy MOP. DO NOT DELETE
        public Object doCall(Object... arguments) {
            return InvokerHelper.invokeMethod(getOwner(), getMethod(), arguments);
        }

    }
}
