package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * PublishedApiVersionCheck indicates, that the class required a certain Version of a PublishedApi. The version indicates the "compiled" version against the {@link PublishedApi}
 * . The check will use the specified VersionRange of the {@link PublishedApiVersionInfo}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface PublishedApiVersionCheck {

    @PublishedMethod
    String version();

    /**
     * You can also use the fieldName attribute to specify the field which should be used to verify against the VersinRange.
     * <p>
     * If the fieldName is not empty, the field is used, instead of evaluating the version
     * </p>
     * <p>
     * The field must be a <code>private static final String</code>
     * </p>
     * 
     * @return the string
     */
    @PublishedMethod
    String fieldName() default "";

    /**
     * Domain type specifies the version of the specific {@link DomainType} like {@link DomainType#GENERATORS}.
     * 
     * There can be one VersionInfo for each {@link DomainType} in the system.
     * 
     * @return the domain type
     */
    @PublishedMethod
    DomainType domainType();

}
