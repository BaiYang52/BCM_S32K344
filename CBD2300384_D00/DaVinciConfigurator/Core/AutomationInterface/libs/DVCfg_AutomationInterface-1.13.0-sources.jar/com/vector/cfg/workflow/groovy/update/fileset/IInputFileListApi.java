package com.vector.cfg.workflow.groovy.update.fileset;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.groovy.update.fileset.inputfile.IInputFileApi;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IInputFileListApi {

    /**
     * Creates a new input file for the given file path and adds it to the list of input files of this file set.
     *
     * Example>
     *
     *
     * <pre>
     * <code>
     fileSet {
         inputFiles {

             clear()

             createInputFile(mySystemExtract.asPersistablePath())    {

             }
         }
     }
     *
     * </code>
     * </pre>
     *
     * <div class="extdoc" id="inputFiles"> Use {@link #createInputFile(IPersistablePath, Closure)} to create a new input file for the given path.<br>
     * </div>
     *
     *
     *
     *
     *
     * @param <T> the generic type
     * @param path the path
     * @param code the code
     * @return the t
     */
    @PublishedMethod
    <T> T createInputFile(IPersistablePath path, @VDelegatesToWithClosureParam(IInputFileApi.class) Closure<T> code);

    /**
     * removes all input files from this {@link IFileSet}.
     *
     * <div class="extdoc" id="clear"> Use {@link #clear()} to remove all existing input file from the input file list.<br>
     * </div>
     */
    @PublishedMethod
    void clear();

    /**
     * removes the input file with the given path from this {@link IFileSet}.
     *
     * <div class="extdoc" id="removeByPath"> Use {@link #removeByPath(IPersistablePath)} to remove the input file with the given path from the input file list. If the input file
     * is not part of this input file list no operation will be executed. </div>
     *
     * @param path the path
     */
    @PublishedMethod
    void removeByPath(IPersistablePath path);

}
