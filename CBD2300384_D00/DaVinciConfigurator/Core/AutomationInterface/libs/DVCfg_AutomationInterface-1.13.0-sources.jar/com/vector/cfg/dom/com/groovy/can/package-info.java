/**
 * The CanController API provides special support for CanController related use cases (e.g.: for optimizing acceptance filters).
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.com.groovy.can;