package com.vector.cfg.util.text.exception;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.text.log.IExceptionUserMessage;
import com.vector.cfg.util.text.log.IUserMessage;

/**
 * If an {@link Exception} implements the {@link IExceptionAggregatesCauseChainMessages} interface. The Exception marks itself, that the {@link IUserMessage#getUserMessage()}
 * will also contain all causes of the exception.
 *
 * <p>
 * This interface shall only be implemented by sub classes of {@link Throwable}!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by PublishedApi clients.
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExceptionAggregatesCauseChainInUserMessage extends IUserMessage, IExceptionUserMessage {

}
