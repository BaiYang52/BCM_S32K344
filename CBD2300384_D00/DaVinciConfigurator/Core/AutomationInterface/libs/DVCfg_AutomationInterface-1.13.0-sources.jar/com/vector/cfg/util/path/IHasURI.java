package com.vector.cfg.util.path;

import java.net.URI;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IHasURI} instance could be used to convert the source object to an {@link URI}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasURI {

    /**
     * Returns the {@link URI} of the object.
     *
     * @return the URI representing this object's path
     */
    @PublishedMethod
    URI toUri();
}
