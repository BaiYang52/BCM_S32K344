package com.vector.cfg.util.text.mixedtext.parts;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.mixedtext.IFormatSpec;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMixedTextStringPart extends IMixedTextPart {

    @PublishedMethod
    @Override
    IMixedTextStringPart createNewFormattedPart(IFormatSpec newSpec);
}
