package com.vector.cfg.model.formula;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.asr.formula.api.IFormulaExpression;

/**
 * The {@link IFormulaError} is used to represent error of the {@link IFormulaExpression} inside of the {@link ModelFormulaException}. An {@link ModelFormulaException} can have
 * multiple {@link IFormulaError}s. The error can be an syntactic, semantic, type (casting), internal or runtime evaluation error.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IFormulaError extends IHasFormulaString {

    /**
     * Gets the message of the error.
     *
     * @return the message
     */
    @PublishedMethod
    String getMessage();

    /**
     * Returns the start index where the error had occurred in the {@link #getFormulaString()}.
     *
     * @return the start index
     */
    @PublishedMethod
    int getStartIndex();

    /**
     * Returns the stop index (inclusive) where the error had occurred in the {@link #getFormulaString()}.
     *
     * @return the stop index
     */
    @PublishedMethod
    int getStopIndex();

}
