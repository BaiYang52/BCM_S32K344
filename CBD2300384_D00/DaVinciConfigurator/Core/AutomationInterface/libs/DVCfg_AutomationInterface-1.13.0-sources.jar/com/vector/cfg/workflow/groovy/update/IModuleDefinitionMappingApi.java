package com.vector.cfg.workflow.groovy.update;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 * API to configure the module to definition mappings.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IModuleDefinitionMappingApi {

    /**
     * <div class="extdoc" id="getAvailableDefinitionsForModule"> Use {@link #getAvailableDefinitionsForModule(String)} to get a list of definitions as DefRef for the given
     * ModuleConfig.</div>
     *
     * @param moduleConfigShortName
     * @return The list of all available definitions for the given ModuleConfig.
     */
    @PublishedMethod
    List<DefRef> getAvailableDefinitionsForModule(String moduleConfigShortName);

    /**
     * <div class="extdoc" id="getAmbiguousModuleConfigs"> Use {@link #getAmbiguousModuleConfigs()} to get a list of all ambiguous single-instance modules that cannot be
     * resolved automatically. The list will return the ModuleConfig short names.</div>
     *
     * @return The list of all ambiguous ModuleConfigs.
     */
    @PublishedMethod
    List<String> getAmbiguousModuleConfigs();

    /**
     * <div class="extdoc" id="mapModuleToDefinition"> Use {@link #mapModuleToDefinition(String, DefRef)} to map the ModuleConfig to its definition as {@link DefRef}.</div>
     *
     * @param moduleConfigShortName The ModuleConfig short name.
     * @param definition The definition as {@link DefRef}.
     */
    @PublishedMethod
    void mapModuleToDefinition(String moduleConfigShortName, DefRef definition);

}
