package com.vector.cfg.workflow.diff.groovy.projectcompare;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IProjectCompareEntryPoint"><!--IProjectCompareEntryPoint-->The entry point for the project compare API is {@link IProjectCompareEntryPoint}.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectCompareEntryPoint {

    /**
     * Allows accessing the {@link IProjectCompare} like a property.
     *
     * @return the {@link IProjectCompare}
     */
    @PublishedMethod
    IProjectCompare getProjectCompare();

    /**
     * Allows accessing the {@link IProjectCompare} in a scope-like way.
     *
     * @param code the code (a {@link Closure}) working with the {@link IProjectCompare}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T projectCompare(@VDelegatesToWithClosureParam(IProjectCompare.class) Closure<T> code);
}
