/**
 * Automation scripting API for convenient bswmd model access in Groovy code clients.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel.groovy.api;