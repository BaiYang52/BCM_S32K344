package com.vector.cfg.workflow.groovy.update.fileset.inputfile;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * <div class="extdoc" id="InputFileApi"> The {@link IInputFileApi} is the entry point to define and modify an input file.<br>
 * </div>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IInputFileApi {

    /**
     * returns all available ecu instances for this input file.
     *
     * <div class="extdoc" id="getAvailableEcuInstances"> Use {@link #getAvailableEcuInstances()} to get all available ecu instances for this input file.</div>
     *
     * @return all available ecu instances.
     */
    @PublishedMethod
    List<String> getAvailableEcuInstances();

    /**
     * Sets the ecu instance for this input file. The available ecu instances can be retrieved with {@link #getAvailableEcuInstances()}.
     *
     * <div class="extdoc" id="setEcuInstance"> Use {@link #setEcuInstance()} to set the ecu instance for this input file.</div>
     *
     * @param value
     */
    @PublishedMethod
    void setEcuInstance(String value);

    /**
     * Sets the file category for this input file. The available file categories can be retrieved with {@link #getAvailableFileCategories()}. This method call overwrites all
     * already set file categories.
     *
     * <div class="extdoc" id="setFileCategory"> Use {@link #setFileCategory(EInputFileCategory)} to set one file category. This overwrites all already set file categories.
     * </div>
     *
     * @param value
     */
    @PublishedMethod
    void setFileCategory(EInputFileCategory value);

    /**
     * Sets the file categories for this input file. The available file categories can be retrieved with {@link #getAvailableFileCategories()}. This method call overwrites all
     * already set file categories.
     *
     * <div class="extdoc" id="setFileCategoryList"> Use {@link #setFileCategory(List)} to set one or multiple file categories. This overwrites all already set file categories.
     * </div>
     *
     * @param value
     */
    @PublishedMethod
    void setFileCategory(List<EInputFileCategory> value);

    /**
     * returns all available and allowed file categories for this input file.
     *
     * <div class="extdoc" id="getAvailableFileCategories"> Use {@link #getAvailableFileCategories()} to get a all available {@link EInputFileCategory} for this input
     * file.</div>
     *
     * @return all available file categories.
     */
    @PublishedMethod
    List<EInputFileCategory> getAvailableFileCategories();

    /**
     * Sets the ImportDissAndRids option.
     *
     * <div class="extdoc" id="setImportDidsAndRids"> Use {@link #setImportDidsAndRids(Boolean)} to import DIDs and RIDs as single signal for DCM (backward compatibility). This
     * settings is only necessary for diagnostic data input files. </div>
     *
     * @param value
     */
    @PublishedMethod
    void setImportDidsAndRids(Boolean value);

    /**
     * Sets the generic legacy diagnostic data import option.
     *
     * <div class="extdoc" id="setGenericLegacyDiagImport"> Use {@link #setGenericLegacyDiagImport(Boolean)} to enable or disable the generic diagnostic data import. This
     * setting is only necessary for legacy diagnostic data input files. </div>
     *
     * @param value
     */
    @PublishedMethod
    void setGenericLegacyDiagImport(Boolean value);

    /**
     * returns all available and allowed ecu instances for Diagnostic Data input file.
     *
     * <div class="extdoc" id="getAvailableDiagEcuInstances"> Use {@link #getAvailableDiagEcuInstances()} to get all available ecu instances for this diagnostic data input
     * file.</div>
     *
     * @return
     */
    @PublishedMethod
    List<String> getAvailableDiagEcuInstances();

    /**
     * Set the Diagnostic Ecu Instance.
     *
     * * <div class="extdoc" id="setDiagDataEcuInstanceWithClosure"> Use {@link #setDiagDataEcuInstance(String, Closure)} to specify the Diagnostic Ecu Instance and the variant
     * setting.</div>
     *
     * @param ecuInstance
     * @param code
     */
    @PublishedMethod
    void setDiagDataEcuInstance(String ecuInstance, @VDelegatesToWithClosureParam(IDiagDataApi.class) Closure<?> code);

    /**
     * Set the Diagnostic Ecu Instance.
     *
     * * <div class="extdoc" id="setDiagDataEcuInstance"> Use {@link #setDiagDataEcuInstance(String)} to specify the Diagnostic Ecu Instance.</div>
     *
     * @param ecuInstance
     */
    @PublishedMethod
    void setDiagDataEcuInstance(String ecuInstance);

}
