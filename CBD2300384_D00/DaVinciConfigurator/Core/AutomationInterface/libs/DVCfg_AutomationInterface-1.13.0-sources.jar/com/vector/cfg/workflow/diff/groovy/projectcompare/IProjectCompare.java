package com.vector.cfg.workflow.diff.groovy.projectcompare;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.IAutoMergeApi;
import com.vector.cfg.workflow.diff.groovy.projectcompare.compare.ICompareApi;

import groovy.lang.Closure;

/**
 * {@link IProjectCompare} is the entry point for the comparison API.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectCompare {

    /**
     * Allows accessing the {@link IAutoMergeApi} like a property.
     *
     * @return the {@link IAutoMergeApi}
     */
    @PublishedMethod
    IAutoMergeApi getAutoMerge();

    /**
     * Allows accessing the {@link IAutoMergeApi} in a scope-like way.
     *
     * @param code the code (a {@link Closure}) working with the {@link IAutoMergeApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T autoMerge(@VDelegatesToWithClosureParam(IAutoMergeApi.class) Closure<T> code);

    /**
     * Allows accessing the {@link ICompareApi} like a property.
     *
     * @return the {@link ICompareApi}
     */
    @PublishedMethod
    ICompareApi getCompare();

    /**
     * Allows accessing the {@link ICompareApi} in a scope-like way.
     *
     * @param code the code (a {@link Closure}) working with the {@link ICompareApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T compare(@VDelegatesToWithClosureParam(ICompareApi.class) Closure<T> code);
}
