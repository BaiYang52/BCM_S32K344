package com.vector.cfg.workflow.groovy.update;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.access.DefRef;

/**
 * API to configure the MultiDriver mappings.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IMultiDriverMappingApi {

    /**
     * <div class="extdoc" id="getAllClusterPaths"> Use {@link #getAllClusterPaths()} to get a list of AsrPath with all clusters.</div>
     *
     * @return list of Clusters as {@link AsrPath}.
     */
    @PublishedMethod
    List<AsrPath> getAllClusterPaths();

    /**
     * <div class="extdoc" id="getAvailableDefinitionsForCluster"> Use {@link #getAvailableDefinitionsForCluster(AsrPath)} to get a list of definitions as DefRef for the given
     * cluster.</div>
     *
     * @param clusterPath as {@link AsrPath}.
     * @return list of definitions as {@link DefRef}.
     */
    @PublishedMethod
    List<DefRef> getAvailableDefinitionsForCluster(AsrPath clusterPath);

    /**
     * <div class="extdoc" id="getAllClusterPaths1"> Use {@link #mapClusterToDefinition(AsrPath, AsrPath)} to map the cluster to its definition as AsrPath.</div>
     *
     * @param clusterPath to map as {@link AsrPath}.
     * @param definitionPath to map as {@link AsrPath}.
     */
    @PublishedMethod
    void mapClusterToDefinition(AsrPath clusterPath, AsrPath definitionPath);

    /**
     * <div class="extdoc" id="getAllClusterPaths2"> Use {@link #mapClusterToDefinition(AsrPath, DefRef)} to map the cluster to its definition as DefRef.</div>
     *
     * @param clusterPath to map as {@link AsrPath}.
     * @param definitionPath to map as {@link AsrPath}.
     */
    @PublishedMethod
    void mapClusterToDefinition(AsrPath clusterPath, DefRef definitionRef);

}
