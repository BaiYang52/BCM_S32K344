package com.vector.cfg.core.project;

import java.util.Arrays;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.core.project.internal.EnvironmentProjectTypeUtils;

/**
 *
 * <div class="extdoc" id="CommonModel" data-target-doc="ModelDocumentation">
 *
 * The {@link EEnvironmentProjectTypeDomain} represents the possible project type domains.
 *
 * <pre>
 * <code class="Java" id="EEnvironmentProjectTypeDomain usage sample">
 * final EEnvironmentProjectTypeDomain projectTypeDmoain = projectContext.getService(IDpaAccessPublished.class).getProjectTypeDomain()();
 * </code>
 * </pre>
 *
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IDpaAccessPublished
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
@ThreadSafe
public enum EEnvironmentProjectTypeDomain {

    NONE("", ""),

    GLOBAL_RESOURCE_DB(
            EnvironmentProjectTypeUtils.globalResDbSerialization,
            EnvironmentProjectTypeUtils.globalResDbLiteral),

    SYSTEM_EXTRACT(
            EnvironmentProjectTypeUtils.systemExtractSerialization,
            EnvironmentProjectTypeUtils.systemExtractLiteral),

    HOST_APPLICATIVE_CLUSTER(
            EnvironmentProjectTypeUtils.hostApplicativeClusterSerialization,
            EnvironmentProjectTypeUtils.hostApplicativeClusterLiteral);

    private final String serializationValue;

    private final String literalValue;

    EEnvironmentProjectTypeDomain(final String serializationValue, final String literalValue) {
        this.serializationValue = serializationValue;
        this.literalValue = literalValue;
    }

    /**
     * Gets the literal value which is used for UI representation of the domain (sub-type).
     *
     * @return the literal value.
     */
    @KeepSecretFromPublishedApi
    public String getLiteralValue() {
        return literalValue;
    }

    /**
     * Gets the literal value which is used for serialization of the domain (sub-type).
     *
     * @return the literal value.
     */
    @KeepSecretFromPublishedApi
    public String getSerializationValue() {
        return serializationValue;
    }

    /**
     * Gets the corresponding 'parent' project type ({@link EEnvironmentProjectType}).
     *
     * @return the corresponding {@link EEnvironmentProjectType}.
     */
    @KeepSecretFromPublishedApi
    public EEnvironmentProjectType getProjectType() {
        switch (this) {
        case GLOBAL_RESOURCE_DB:
        case HOST_APPLICATIVE_CLUSTER:
        case SYSTEM_EXTRACT:
            return EEnvironmentProjectType.SOFTWARE_CLUSTER_CONNECTION;
        case NONE:
        default:
            return EEnvironmentProjectType.STANDARD;
        }
    }

    /**
     * Gets the corresponding ENUM value for the given literal value.
     *
     * @param the literal value.
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentProjectTypeDomain#NONE} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentProjectTypeDomain getItemForLiteralValue(String value) {
        if (value != null) {
            return Arrays.stream(EEnvironmentProjectTypeDomain.values()).filter(type -> type.getLiteralValue().equalsIgnoreCase(value)).findAny().orElse(NONE);
        }
        return EEnvironmentProjectTypeDomain.NONE;
    }

    /**
     * Gets the corresponding ENUM value for the given serialization value.
     *
     * @param the literal value.
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentProjectTypeDomain#NONE} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentProjectTypeDomain getItemForSerializationValue(String value) {
        if (value != null) {
            return Arrays.stream(EEnvironmentProjectTypeDomain.values()).filter(type -> type.getSerializationValue().equalsIgnoreCase(value)).findAny().orElse(NONE);
        }
        return EEnvironmentProjectTypeDomain.NONE;
    }

}
