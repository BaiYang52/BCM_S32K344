package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.connection.IConnector;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;

/**
 * <div class="extdoc" id="ISelectedComponentPorts"><!--ISelectedComponentPorts-->{@link ISelectedComponentPorts} represents a selection of {@link IComponentPort}s and provides
 * simple APIs for further actions (e.g. connecting them to other ports).</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISelectedComponentPorts {

    /**
     * <p>
     * <div class="extdoc" id="connectTo"><!--Label:ISelectedComponentPorts.connectTo-->{@link #connectTo(List)} creates {@link IConnector}s between the {@link IComponentPort}s
     * which are represented by this {@link ISelectedComponentPorts} with the given targetPorts. The ports are connected using the index. The first port of this
     * {@link ISelectedComponentPorts} will be connected to the first target port, the second to the second target port and so on. <br>
     *
     * In case you want to ignore already connected port pairs please use {@link #assureConnectedTo(List)}. <br>
     *
     * If you want to connect ports using name matching please use {@link IRuntimeSystemApi#selectComponentPorts(groovy.lang.Closure)}.</div>
     * </p>
     *
     * @param targetPorts The target {@link IComponentPort}s for the new connectors. The order is relevant, the ports will be connected via index to the selected ports.
     *
     * @exception SelectionException If incompatible port pairs were found or a connection for at least one of the pairs does already exist. See Automation Interface
     * Documentation for more details about the checks.
     *
     * @return The created {@link IConnector}s.
     */
    @PublishedMethod
    List<IConnector> connectTo(@Nonnull List<IComponentPort> targetPorts);

    /**
     * <p>
     * <div class="extdoc" id="assureConnectedTo"><!--Label:ISelectedComponentPorts.assureConnectedTo-->{@link #assureConnectedTo(List)} checks whether the
     * {@link IComponentPort}s represented by this {@link ISelectedComponentPorts} are already connected to the given targetPorts matching them via index. In contrast to
     * {@link #connectTo(List)} this method does nothing if the ports are already connected. If the ports are not connected a new connector will be created.</div>
     * </p>
     *
     * @param targetPorts The target {@link IComponentPort}s for the ports represented by this {@link ISelectedComponentPorts}. The order is relevant, the ports will be
     * connected via index to the selected ports.
     *
     * @exception SelectionException If incompatible port pairs were found. See Automation Interface Documentation for more details about the checks.
     *
     * @return Only newly created connectors for the port pairs that were not connected yet. For already connected pairs nothing will be returned. So if an empty list is
     * returned by this method, then all port pairs were already connected.
     */
    @PublishedMethod
    List<IConnector> assureConnectedTo(@Nonnull List<IComponentPort> targetPorts);

}
