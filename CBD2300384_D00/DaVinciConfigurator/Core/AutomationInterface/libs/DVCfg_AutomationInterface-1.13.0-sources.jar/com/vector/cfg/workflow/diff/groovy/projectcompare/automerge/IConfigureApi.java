package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge;

import java.nio.file.Path;
import java.util.function.Predicate;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.result.IMergeResult;

import groovy.lang.Closure;

/**
 * {@link IConfigureApi} is the entry point for auto-merge related settings.
 *
 * <div class="extdoc" id="Common">To configure the automatic merge related settings the {@link IConfigureApi} is used. It allows to make detailed settings for the comparison.
 * Also it allows to set the conflict resolution strategy when resolving the differences.
 *
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IConfigureApi {

    /**
     * <div class="extdoc" id="disableUuidsForObjectIdentification">
     * <h5>UUID object identification</h5> {@link #setDisableUuidsForObjectIdentification(Path)} disables or enables the UUID usage for the object identification during comparison.
     * In case of {@code true} the UUID usage will be disabled (this is the default behavior). If {@code false} the UUID will be used for object identification.
     *
     * </div>
     *
     * @param value when {@code true} the UUID usage will be disabled (default). If {@code false} the UUID usage will be enabled.
     */
    @PublishedMethod
    void setDisableUuidsForObjectIdentification(boolean value);

    /**
     * <div class="extdoc" id="conflictDontSolve">
     * <h5>DONT_SOLVE</h5> describes a global conflict resolution approach where no conflicted differences are resolved.
     *
     * </div>
     *
     */
    @PublishedField
    EConflictResolutionApproach DONT_SOLVE = EConflictResolutionApproach.DONT_SOLVE;

    /**
     * <div class="extdoc" id="conflictUseMine">
     * <h5>USE_MINE</h5> describes a global conflict resolution approach where conflicted differences are resolved by using the value of project MINE.
     *
     * </div>
     *
     */
    @PublishedField
    EConflictResolutionApproach USE_MINE = EConflictResolutionApproach.USE_MINE;

    /**
     * <div class="extdoc" id="conflictUseOther">
     * <h5>USE_OTHER</h5> describes a global conflict resolution approach where conflicted differences are resolved by using the value of project OTHER.
     *
     * </div>
     *
     */
    @PublishedField
    EConflictResolutionApproach USE_OTHER = EConflictResolutionApproach.USE_OTHER;

    /**
     * <div class="extdoc" id="conflictResolutionApproach">
     * <h5>Conflict resolution apporach</h5> {@link #setConflictResolutionApproach(EConflictResolutionApproach)} is used to set the global conflict resolution approach.
     *
     * </div>
     *
     * @param approach the global conflict resolution approach to use. See also {@link #DONT_SOLVE}, {@link #USE_MINE}, {@link #USE_OTHER}.
     */
    @PublishedMethod
    void setConflictResolutionApproach(EConflictResolutionApproach approach);

    /**
     * <div class="extdoc" id="projectOther">
     * <h5>OTHER</h5> {@link #setProjectOther(Path)} is used to set the absolute path to project OTHER which is used for comparison with project MINE.
     *
     * </div>
     *
     * @param projectOther the project OTHER used for comparison.
     */
    @PublishedMethod
    void setProjectOther(Path projectOther);

    /**
     * <div class="extdoc" id="projectBase">
     * <h5>BASE</h5> {@link #setProjectBase(Path)} is used to set the absolute path to project BASE which is used for comparison and to determine how a possible difference can be
     * auto resolved.
     *
     * </div>
     *
     * @param projectBase the project BASE used for comparison.
     */
    @PublishedMethod
    void setProjectBase(Path projectBase);

    /**
     * <div class="extdoc" id="importPlatformFunctionDefinition">The method {@link #importPlatformFunctionDefinition(String)} is used to add the platform function definition
     * identified by the given name to the definitions which will be imported during the auto-merge process.
     *
     * </div>
     *
     * @param functionName the name of the function definition to import.
     */
    @PublishedMethod
    void importPlatformFunctionDefinition(String functionName);

    /**
     * <div class="extdoc" id="filterPlatformFunction">The method {@link #filterPlatformFunction(String)} is used to extend the platform function filter by the given name of the
     * function.
     *
     * </div>
     *
     * @param functionName the name of the function definition to filter for.
     */
    @PublishedMethod
    void filterPlatformFunction(String functionName);

    /**
     * <div class="extdoc" id="scopeEcucEcuExOnly">
     * <h5>ECUC_ECUEX_ONLY</h5> describes the scope in which only ECUC and Extract of System Description relevant data is compared (no comparison of DaVinci Developer Workspace).
     *
     * </div>
     *
     */
    @PublishedField
    EComparisonScope ECUC_ECUEX_ONLY = EComparisonScope.ECUC_ECUEX_ONLY;

    /**
     * <div class="extdoc" id="scopeEcucEcuExDevWs">
     * <h5>ECUC_ECUEX_DEV_WS</h5> describes the scope in which ECUC, Extract of System Description and DaVinci Developer Workspace relevant data is compared.
     *
     * </div>
     *
     */
    @PublishedField
    EComparisonScope ECUC_ECUEX_DEV_WS = EComparisonScope.ECUC_ECUEX_DEV_WS;

    /**
     * <div class="extdoc" id="comparisonScope">
     * <h5>Comparison Scope</h5> {@link #setComparisonScope(EComparisonScope)} sets the comparison scope to use.
     *
     * </div>
     *
     * @param scope the scope to use.
     */
    @PublishedMethod
    void setComparisonScope(EComparisonScope scope);

    /**
     * <div class="extdoc" id="compareProjectSettings">
     * <h5>Project Settings</h5> {@link #setCompareProjectSettings(boolean)} activates or disables the comparison of project settings. {@code true} when project settings should be
     * compared. Otherwise {@code false}.
     *
     * </div>
     *
     * @param consider {@code true} to enable comparison of project settings. Otherwise {@code false}.
     */
    @PublishedMethod
    void setCompareProjectSettings(boolean consider);

    /**
     * <div class="extdoc" id="setCompareEcuExtract">
     * <h5>ECU Extract of System Description</h5> {@link #setCompareEcuExtract(boolean)} activates or disables the comparison of the ECU Extract of System Description. {@code true}
     * when extract should be compared. Otherwise {@code false}.
     *
     * </div>
     *
     * @param consider {@code true} to enable comparison of the ECU Extract of System Description. Otherwise {@code false}.
     */
    @PublishedMethod
    void setCompareEcuExtract(boolean consider);

    /**
     * <div class="extdoc" id="evaluateMergeResultDaVinciConfigurator">
     * <h5>DaVinci Configurator Classic merge result</h5> {@link #evaluateMergeResultDaVinciConfigurator(Predicate)} specifies a {@link Predicate} to evaluate the merge result of
     * the DaVinci Configurator Classic.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the merge result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateMergeResultDaVinciConfigurator(Predicate<IMergeResult> resultPredicate);

    /**
     * <div class="extdoc" id="evaluateMergeResultDaVinciConfigurator">
     * <h5>DaVinci Configurator Classic merge result</h5> {@link #evaluateMergeResultDaVinciConfigurator(Predicate)} specifies a {@link Predicate} to evaluate the merge result of
     * the DaVinci Configurator Classic.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the merge result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateMergeResultDaVinciConfigurator(@VDelegatesToWithClosureParam(IMergeResult.class) Closure<Boolean> resultPredicate);

    /**
     * <div class="extdoc" id="evaluateMergeResultDaVinciDeveloper">
     * <h5>DaVinci Developer merge result</h5> {@link #evaluateMergeResultDaVinciDeveloper(Predicate)} specifies a {@link Predicate} to evaluate the merge result of the DaVinci
     * Developer.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the merge result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateMergeResultDaVinciDeveloper(Predicate<IMergeResult> resultPredicate);

    /**
     * <div class="extdoc" id="evaluateMergeResultDaVinciDeveloper">
     * <h5>DaVinci Developer merge result</h5> {@link #evaluateMergeResultDaVinciDeveloper(Predicate)} specifies a {@link Predicate} to evaluate the merge result of the DaVinci
     * Developer.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the merge result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateMergeResultDaVinciDeveloper(@VDelegatesToWithClosureParam(IMergeResult.class) Closure<Boolean> resultPredicate);

    /**
     * <div class="extdoc" id="moduleToMerge">
     * <h5>Module configurations to merge</h5> {@link #moduleToMerge(String)} adds the module configuration identified by the given short name to the collection of the modules to
     * be considered for the merge. This will restrict the default selection behavior.
     *
     * </div>
     *
     * @param moduleShortName the short name of the module configuration to merge.
     */
    @PublishedMethod
    void moduleToMerge(String moduleShortName);

    /**
     * <div class="extdoc" id="setCreateMergeResultHtmlReport">
     * <h5>HTML Report for merge result</h5> {@link #setCreateMergeResultHtmlReport(boolean)} activates or disables the creation of a HTML report for the merge result (of not
     * automatically resolved differences). {@code true} when report should be created. Otherwise {@code false}.
     *
     * </div>
     *
     * @param createReport {@code true} to force the generation of the HTML report. Otherwise {@code false}.
     */
    @PublishedMethod
    void setCreateMergeResultHtmlReport(boolean createReport);
}
