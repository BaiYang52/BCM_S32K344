package com.vector.cfg.dom.runtimesys.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Exception for not correct usage of the in the AutomationAPI offered selections with in the runtime system domain API. E.g. selecting more than one task for the task mapping
 * or trying to connect two PPorts within an AssemblySwConnector.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class SelectionException extends IllegalArgumentException {

    private static final long serialVersionUID = 1L;

    @PublishedMethod
    public SelectionException(String message) {
        super(message);
    }
}
