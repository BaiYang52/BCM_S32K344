package com.vector.cfg.model.cedescriptor;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IDescriptorFactory {

    /**
     * creates a builder where aspects could be set.
     *
     * @param parent
     * @return
     */
    @PublishedMethod
    IDescriptorBuilder createBuilder(IDescriptor parent);

    /**
     * creates a builder where aspects could be set.
     *
     * @param parent
     * @return
     */
    @PublishedMethod
    IDescriptorBuilder createBuilder(IDescriptorBuilder parent);

    /**
     * creates a builder where aspects, except MdfObjectAspect and perhaps DefRefAspect, could be set.
     *
     * It is also possible to create an IDescriptorBuilder for an invisible or deleted object.
     *
     * @param context
     * @return
     */
    @PublishedMethod
    <T extends MIObject> IDescriptorBuilder createBuilder(T context);
}
