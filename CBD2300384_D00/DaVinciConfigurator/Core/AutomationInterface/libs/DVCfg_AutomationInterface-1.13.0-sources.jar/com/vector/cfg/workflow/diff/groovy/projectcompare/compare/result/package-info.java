/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
package com.vector.cfg.workflow.diff.groovy.projectcompare.compare.result;