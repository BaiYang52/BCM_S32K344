package com.vector.cfg.dom.com.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="IJ1939RCApi" data-target-doc="AutomationInterfaceDocumentation"><!--Label:IJ1939RCApi--> {@link IJ1939RCApi} provides high convenience support for
 * J1939RC related use cases.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IJ1939RCApi {

    /**
     * <div class="extdoc" id="executeAllValidationRules"><!--Label:IJ1939RCApi.executeAllValidationRules-->{@link #executeAllValidationRules()} checks the current EcuC
     * configuration and sets the J1939 Requestable Flag on the PDU if necessary. <br>
     * </div>
     *
     * @return {@code true} if all validation rules has been executed successfully, otherwise {@code false}.
     */
    @PublishedMethod
    boolean executeAllValidationRules();

}
