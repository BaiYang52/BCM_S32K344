package com.vector.cfg.model.cedescriptor;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepInterfacesSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.aspect.IDefRefAspect;
import com.vector.cfg.model.cedescriptor.aspect.IMdfFeatureAspect;
import com.vector.cfg.model.cedescriptor.aspect.IMdfMetaClassAspect;
import com.vector.cfg.model.cedescriptor.aspect.IMdfObjectAspect;
import com.vector.cfg.util.IProjectContext;

/**
 * <div class="extdoc" id="IDescriptorCommon" data-target-doc="AutomationInterfaceDocumentation">An {@link IDescriptor} is a construct that can be used to "point to" some
 * location in the model. A descriptor can have several kinds of aspects to describe where it points to. Aspect kinds are e.g. {@link IMdfObjectAspect}, {@link IDefRefAspect},
 * {@link IMdfMetaClassAspect}, {@link IMdfFeatureAspect}.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
@KeepInterfacesSecretFromPublishedApi(IDescriptorInternal.class)
public interface IDescriptor extends IDescriptorInternal {

    /**
     * <div class="extdoc" id="getParent" data-target-doc="AutomationInterfaceDocumentation">A descriptor has a parent descriptor. This allows to describe a hierarchy. <br/>
     * E.g. if you want to express that something with definition X is missing as a child of the existing MDF object Y. In this example you have a descriptor with an
     * {@link IDefRefAspect} containing the definition X. This descriptor that has a parent descriptor with an {@link IMdfObjectAspect} containing the object Y.
     * <p/>
     * The term descriptor refers to a descriptor together with its parent-descriptor hierarchy. </div>
     *
     * @return the parent
     */
    @PublishedMethod
    IDescriptor getParent();

    /**
     * <div class="extdoc" id="getAspect" data-target-doc="AutomationInterfaceDocumentation">{@link #getAspect(Class)} gets a particular aspect if available, otherwise
     * null.</div>
     *
     * @param <T> the generic type
     * @param aspectClass the aspect class
     * @return the aspect
     */
    @PublishedMethod
    <T extends IDescriptorAspect> T getAspect(Class<T> aspectClass);

    /**
     * Returns the {@link IProjectContext} of this descriptor.
     *
     * @return the active project.
     */
    @PublishedMethod
    default IProjectContext getProjectContext() {
        return DescriptorUtil.getProjectContext(this);
    }
}
