package com.vector.cfg.gen.core.moduleinterface.genservices.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.genservices.IGenServiceRegistry;
import com.vector.cfg.model.access.DefRef;

/**
 * The {@link GenServiceContributionException} is thrown by the {@link IGenServiceRegistry}, if something at contribution time has failed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenServiceContributionException extends Exception {

    private static final long serialVersionUID = -2087469274432722635L;

    // private static final ILogger logger = Logger.INSTANCE.createLogger(GenServiceContributionException.class);

    private final DefRef defRef;

    /**
     * Instantiates a new gen service contribution exception.
     *
     * @param moduleDefRef the module def ref
     * @param message the message
     * @param cause the cause
     */
    @PublishedMethod
    public GenServiceContributionException(DefRef moduleDefRef, String message, Throwable cause) {
        super(message, cause);

        defRef = moduleDefRef;

    }

    /**
     * Instantiates a new gen service contribution exception.
     *
     * @param moduleDefRef the module def ref
     * @param message the message
     */
    @PublishedMethod
    public GenServiceContributionException(DefRef moduleDefRef, String message) {
        super(message);

        defRef = moduleDefRef;
    }

    /**
     * Gets the {@link DefRef} of the Contribution. Normally this is the {@link DefRef} of the {@link IGeneratorPackage}.
     *
     * @return the {@link DefRef} of the Contribution.
     */
    @PublishedMethod
    public DefRef getDefRef() {
        return defRef;
    }

}
