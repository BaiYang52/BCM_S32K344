package com.vector.cfg.project.settings.msr.groovy;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * * <div class="extdoc" id="Common">{@link IVectorEmbeddedProjectApi} is the entry point for accessing and modifying the Vector Embedded Project or Sub Project Name and their
 * values.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IVectorEmbeddedProjectApi {

    /**
     * {@link #getVectorEmbeddedProject()} returns the value of the Vector Embedded Project property.
     *
     * <div class="extdoc" id="getVectorEmbeddedProject">
     * <h5>Get Vector Embedded Project</h5> {@link #getVectorEmbeddedProject()} returns the value of the Vector Embedded Project property. Note: This function will return null if
     * no vectorEmbeddedProject has been configured.</div>
     *
     * @return the value of the vectorEmbeddedProject property as a {@link String }
     */
    @PublishedMethod
    String getVectorEmbeddedProject();

    /**
     * {@link #getVectorEmbeddedSubProject()} returns the value of the Sub Project Name property.
     *
     * <div class="extdoc" id="getVectorEmbeddedSubProject">
     * <h5>Get Vector Embedded Subproject</h5> {@link #getVectorEmbeddedSubProject()} returns the value of the Sub Project Name property. Note: This function will return null if no
     * Sub Project Name has been configured.</div>
     *
     * @return the value of the vectorEmbeddedSubProject property as a {@link String}
     */

    @PublishedMethod
    String getVectorEmbeddedSubProject();

    /**
     * {@link #setVectorEmbeddedProject(String)} Sets the value of the Vector Embedded Project property.
     *
     * <div class="extdoc" id="setVectorEmbeddedProject">
     * <h5>Set Vector Embedded Project</h5> {@link #setVectorEmbeddedProject(String)} Sets the value of the Vector Embedded Project property.</div>
     *
     */

    @PublishedMethod
    void setVectorEmbeddedProject(String embeddedProjectName);

    /**
     * {@link #setVectorEmbeddedSubProject(String)} Sets the value of the Sub Project Name property.
     *
     * <div class="extdoc" id="setVectorEmbeddedSubProject">
     * <h5>Set Vector Embedded Subproject</h5> {@link #setVectorEmbeddedSubProject(String)} Sets the value of the Sub Project Name property.</div>
     *
     */

    @PublishedMethod
    void setVectorEmbeddedSubProject(String embeddeddSubProjectName);

    /**
     * Alias for {@link #setVectorEmbeddedProject(String)}.
     *
     * @param value allowed object is {@link String }
     *
     */

    @PublishedMethod
    void vectorEmbeddedProject(@Nonnull String embeddedProjectName);

    /**
     * Alias for {@link #setVectorEmbeddedSubProject(String)}.
     *
     * @param value allowed object is {@link String }
     *
     */

    @PublishedMethod
    void vectorEmbeddedSubProject(@Nonnull String embeddeddSubProjectName);

}
