package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The {@link IAbstractComponentPortSelector} API defines predicates for component port selector APIs.
 * <p>
 * <div class="extdoc" id="IAbstractComponentPortSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAbstractComponentPortSelector extends IElementSelector {

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches component ports with the given port name.</div>
     *
     * @param name A port name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="names">{@link #names(Collection)} matches component ports with the given port names. The order of the names is not relevant in any kind.</div>
     *
     * @param names A collection of port names.
     */
    @PublishedMethod
    void names(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches component ports with the given port name pattern.</div>
     *
     * @param namePattern A port name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches component ports with the given port autosar path.</div>
     *
     * @param asrPath A port autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches component ports with the given port autosar path pattern.</div>
     *
     * @param asrPathPattern A port autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches component ports with the given component name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="components">{@link #components(Collection)} matches component ports with the given component names. The order of the names is not relevant in any
     * kind.</div>
     *
     * @param names A collection of component names.
     */
    @PublishedMethod
    void components(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches component ports with the given component name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentAsrPath">{@link #componentAsrPath(String)} matches the component ports with the given component autosar path.</div>
     *
     * @param asrPath A component autosar path.
     */
    @PublishedMethod
    void componentAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentAsrPathPattern">{@link #componentAsrPath(Pattern)} matches component ports with the given component autosar path pattern.</div>
     *
     * @param asrPathPattern A component asr path pattern.
     */
    @PublishedMethod
    void componentAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches component ports whose component type's name equals the given component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches component ports whose component type's name matches the given component type name
     * pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches the component ports whose component type's autosar path equals the given
     * component type autosar path.</div>
     *
     * @param asrPath A component type type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches component ports whose component type's autosar path matches the given
     * component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="provided">{@link #provided()} matches provided component ports (p-port).</div>
     */
    @PublishedMethod
    void provided();

    /**
     * <div class="extdoc" id="required">{@link #required()} matches required component ports (r-port).</div>
     */
    @PublishedMethod
    void required();

    /**
     * <div class="extdoc" id="providedRequired">{@link #providedRequired()} matches provided-required component ports (pr-port).</div>
     */
    @PublishedMethod
    void providedRequired();

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches component ports whose port has a sender/receiver port interface.</div>
     */
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches component ports whose port has a client/server port interface.</div>
     */
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches component ports whose port has a trigger port interface.</div>
     */
    @PublishedMethod
    void trigger();

}
