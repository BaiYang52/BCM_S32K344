package com.vector.cfg.dom.runtimesys.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link ITimingExtensionsUpdateApiEntryPoint} is the entry point for accessing the update of timing extensions of the Cfg5 workspace.
 * <div class="extdoc" id="ITimingExtensionsUpdateApiEntryPoint"><!--Label:ITimingExtensionsUpdateApiEntryPoint-->The timing extensions update API is specifically designed to
 * provide a comfortable way of merging the timing extensions from the TA Tool Suite back into the Cfg5 model.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITimingExtensionsUpdateApiEntryPoint {

    /**
     * {@link #getTimingExtensionsUpdate()} allows accessing the {@link ITimingExtensionsUpdateApi} like a property.
     * <div class="extdoc" id="getTimingExtensionsUpdate"><!--Label:ITimingExtensionsUpdateApiEntryPoint.getTimingExtensionsUpdate-->{@link #getTimingExtensionsUpdate()} allows
     * accessing the {@link ITimingExtensionsUpdateApi} like a property.</div>
     *
     * @return the {@link ITimingExtensionsUpdateApi}
     */
    @PublishedMethod
    ITimingExtensionsUpdateApi getTimingExtensionsUpdate();

    /**
     * {@link #timingExtensionsUpdate(Closure)} allows accessing the {@link ITimingExtensionsUpdateApi} in a scope-like way.
     * <div class="extdoc" id="timingExtensionsUpdate"><!--Label:ITimingExtensionsUpdateApiEntryPoint.timingExtensionsUpdate-->{@link #timingExtensionsUpdate(Closure)} allows
     * accessing the {@link ITimingExtensionsUpdateApi} in a scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link ITimingExtensionsUpdateApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T timingExtensionsUpdate(@VDelegatesToWithClosureParam(ITimingExtensionsUpdateApi.class) Closure<T> code);

}
