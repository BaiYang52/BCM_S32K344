package com.vector.cfg.project.settings.msr.groovy;

import java.util.Collection;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Represents the UseCase project setting.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IUseCase {

    /**
     * Returns the name of the use case.
     *
     * <div class="extdoc" id="getName">
     * <h5>Name</h5> {@link #getName()} returns the the name of the current use case. </div>
     *
     * @return The {@link IUseCase} name
     */
    @PublishedMethod
    String getName();

    /**
     * Alias for {@link #setDerivative(String)}.
     */
    @PublishedMethod
    void value(String value);

    /**
     * Sets the use case value.
     *
     * <div class="extdoc" id="setValue">
     * <h5>Value</h5> The {@link #setValue(String)} sets the use case value. The value to set must be one of the returned list by {@link #getAvailableUseCaseValues()}.</div>
     *
     * @param The new value for the given use case
     */
    @PublishedMethod
    void setValue(String value);

    /**
     * Returns the value of the current {@link IUseCase}.
     *
     * <div class="extdoc" id="getValue">
     * <h5>Value</h5> {@link #getValue()} returns the value of the current use case.</div>
     *
     * @return Current {@link IUseCase} value
     */
    @PublishedMethod
    String getValue();

    /**
     * Returns a {@link IUseCase}.
     *
     * <div class="extdoc" id="getAvailableValues">
     * <h5>Available values</h5> The {@link #getAvailableValues()}  returns an immutable list of available values for the {@link IUseCase}. </div>
     *
     * @return Immutable list of valid values for the {@link IUseCase}
     */
    @PublishedMethod
    Collection<String> getAvailableValues();
}
