package com.vector.cfg.dom.diagnostics.groovy.events;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;

/**
 * {@link INewDemEventApi} provides means for creating new Dem events.
 *
 * <div class="extdoc" id="INewDemEventApi"><!--Label:INewDemEventApi-->{@link INewDemEventApi} provides means for creating new Dem events.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface INewDemEventApi {

    @PublishedField
    EWwhObdDtcClass CLASS_A = EWwhObdDtcClass.CLASS_A;

    @PublishedField
    EWwhObdDtcClass CLASS_B1 = EWwhObdDtcClass.CLASS_B1;

    @PublishedField
    EWwhObdDtcClass CLASS_B2 = EWwhObdDtcClass.CLASS_B2;

    @PublishedField
    EWwhObdDtcClass CLASS_C = EWwhObdDtcClass.CLASS_C;

    @PublishedField
    EWwhObdDtcClass NO_CLASS = EWwhObdDtcClass.CLASS_NOCLASS;

    /**
     * Alias for {@link #setEventName(String)}.
     *
     * @param eventName The shortname of the Dem event.
     * @return The newly created Dem event
     */
    @PublishedMethod
    INewDemEventApi eventName(String eventName);

    @PublishedMethod
    void setEventName(String eventName);

    /**
     * Alias for {@link #setDtc(Object)}.
     *
     * @param dtc The DTC for the new Dem event
     */
    @PublishedMethod
    INewDemEventApi dtc(Object dtc);

    @PublishedMethod
    void setDtc(Object dtc);

    /**
     * Alias for {@link #setObd2Dtc(Object)}.
     *
     * @param obd2Dtc
     */
    @PublishedMethod
    INewDemEventApi obd2Dtc(Object obd2Dtc);

    /**
     * Setter for the DTC of OBD2 relevant events.
     * <p>
     * OBD2 relevant events, must specify this parameter. It requires that the Dem supports OBD and the legislation is set to OBD2
     *
     * @param obd2dtc
     */
    @PublishedMethod
    void setObd2Dtc(Object obd2dtc);

    /**
     * Alias for {@link #setWwhObdDtcClass(EWwhObdDtcClass)}.
     *
     * @param wwhObdDtcClass The DTC class, which is necessary for WWH-OBD relevant events
     */
    @PublishedMethod
    INewDemEventApi wwhObdDtcClass(EWwhObdDtcClass wwhObdDtcClass);

    /**
     * Setter for DTC class of WWH-OBD relevant events.
     * <p>
     * If the Dem supports OBD and the legislation is set to WWH-OBD, the event (the DemDTCClass to be precise) must specify it's DTC Class. A value that differs from
     * {@link EWwhObdDtcClass#CLASS_NOCLASS} specifies, that this event is relevant for WWH-OBD.
     *
     * @param wwhObdDtcClass The DTC class, which is necessary for WWH-OBD relevant events
     */
    @PublishedMethod
    void setWwhObdDtcClass(EWwhObdDtcClass wwhObdDtcClass);

    /**
     * Alias for {@link #setSpn(Object)}.
     *
     * @param spn The SPN portion of the J1939 DTC.
     */
    @PublishedMethod
    INewDemEventApi spn(Object spn);

    /**
     * Setter for the SPN of a J1939 DTC.
     *
     * @param spn The SPN portion of the J1939 DTC.
     */
    @PublishedMethod
    void setSpn(Object spn);

    /**
     * Alias for {@link #setFmi(Object)}.
     *
     * @param fmi The FMI portion of the J1939 DTC.
     */
    @PublishedMethod
    INewDemEventApi fmi(Object fmi);

    /**
     * Setter for the FMI of the J1939 DTC.
     *
     * @param fmi The FMI portion of the J1939 DTC.
     */
    @PublishedMethod
    void setFmi(Object fmi);

    /**
     * Alias for {@link #setNodeAddress(MIContainer)}.
     *
     * @param nodeAddress The node address container used by this Dem event.
     */
    @PublishedMethod
    INewDemEventApi nodeAddress(MIContainer nodeAddress);

    /**
     * Setter for the node address container, used by a J1939 Dem event.
     *
     * @param nodeAddress The node address container used by this Dem event.
     */
    @PublishedMethod
    void setNodeAddress(MIContainer nodeAddress);

}
