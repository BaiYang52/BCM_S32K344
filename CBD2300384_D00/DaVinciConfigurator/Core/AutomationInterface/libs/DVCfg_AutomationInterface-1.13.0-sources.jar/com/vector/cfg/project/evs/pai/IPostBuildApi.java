package com.vector.cfg.project.evs.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * This context class defines the post build type of variant.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IPostBuildApi {

    /**
     * <div class="extdoc" id="configureVariants"> Use {@link IPostBuildApi#postBuild(Object, Closure)} to configure a post build variant.</div>
     *
     * @param dpaFilePath The project dpa file path
     * @param code        Providing the {@link IModeTypeApi}
     * @throws EvsException if any error occurs.
     *
     * @return
     */
    @PublishedMethod
    <T> T postBuild(@VDelegatesToWithClosureParam(IModeTypeApi.class) Closure<T> code);
}
