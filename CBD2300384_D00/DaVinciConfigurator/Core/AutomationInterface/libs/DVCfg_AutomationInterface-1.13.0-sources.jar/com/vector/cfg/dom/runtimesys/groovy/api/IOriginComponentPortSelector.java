package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.sysdesc.api.origin.IOriginComponentPort;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IOriginComponentPortSelector} Api allows the definition of predicates for the selection of origin component ports.
 * <p>
 * <div class="extdoc" id="IOriginComponentPortSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ReworkThisAtNextBreakingChange("Remove methods using @Override annotation and adapt documentation links")
public interface IOriginComponentPortSelector extends IAbstractComponentPortSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @Override
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IPortInterfaceSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches origin component ports with the given port name.</div>
     *
     * @param name A port name.
     */
    @Override
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="names">{@link #names(Collection)} matches origin component ports with the given port names. The order of the names is not relevant in any
     * kind.</div>
     *
     * @param names A collection of port names.
     */
    @Override
    @PublishedMethod
    void names(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches origin component ports with the given port name pattern.</div>
     *
     * @param namePattern A port name pattern.
     */
    @Override
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches origin component ports with the given port autosar path.</div>
     *
     * @param asrPath A port autosar path.
     */
    @Override
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches origin component ports with the given port autosar path pattern.</div>
     *
     * @param asrPathPattern A port autosar path pattern.
     */
    @Override
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches origin component ports with the given component name.</div>
     *
     * @param name A component name.
     */
    @Override
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="components">{@link #components(Collection)} matches origin component ports with the given component names. The order of the names is not relevant
     * in any kind.</div>
     *
     * @param names A collection of component names.
     */
    @Override
    @PublishedMethod
    void components(@Nonnull Collection<String> names);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches origin component ports with the given component name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @Override
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentAsrPath">{@link #componentAsrPath(String)} matches the origin component ports with the given component autosar path.</div>
     *
     * @param asrPath A component autosar path.
     */
    @Override
    @PublishedMethod
    void componentAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentAsrPathPattern">{@link #componentAsrPath(Pattern)} matches origin component ports with the given component autosar path pattern.</div>
     *
     * @param asrPathPattern A component asr path pattern.
     */
    @Override
    @PublishedMethod
    void componentAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches origin component ports whose component type's name equals the given component type
     * name.</div>
     *
     * @param name A component type name.
     */
    @Override
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches origin component ports whose component type's name matches the given component type
     * name pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @Override
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches origin component ports whose component type's autosar path equals the given
     * component type autosar path.</div>
     *
     * @param asrPath A component type type autosar path.
     */
    @Override
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches origin component ports whose component type's autosar path matches the
     * given component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @Override
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches origin component ports for which the given closure results to true.</div>
     *
     * @param code The closure to select origin component ports.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IOriginComponentPort.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="provided">{@link #provided()} matches provided origin component ports (p-port).</div>
     */
    @Override
    @PublishedMethod
    void provided();

    /**
     * <div class="extdoc" id="required">{@link #required()} matches required origin component ports (r-port).</div>
     */
    @Override
    @PublishedMethod
    void required();

    /**
     * <div class="extdoc" id="providedRequired">{@link #providedRequired()} matches provided-required origin component ports (pr-port).</div>
     */
    @Override
    @PublishedMethod
    void providedRequired();

    /**
     * <div class="extdoc" id="innerTopLevelDelegation">{@link #innerTopLevelDelegation()} matches origin component ports on the highest hierarchy level. In other words the
     * component of the matched ports is instantiated directly inside the top level composition (ECU Composition).</div>
     */
    @PublishedMethod
    void innerTopLevelDelegation();

    /**
     * <div class="extdoc" id="senderReceiver">{@link #senderReceiver()} matches origin component ports whose port has a sender/receiver port interface.</div>
     */
    @Override
    @PublishedMethod
    void senderReceiver();

    /**
     * <div class="extdoc" id="clientServer">{@link #clientServer()} matches origin component ports whose port has a client/server port interface.</div>
     */
    @Override
    @PublishedMethod
    void clientServer();

    /**
     * <div class="extdoc" id="trigger">{@link #trigger()} matches origin component ports whose port has a trigger port interface.</div>
     */
    @Override
    @PublishedMethod
    void trigger();

    /**
     * <div class="extdoc" id="ofFlatExtractPort">{@link #ofFlatExtractPort()} retrieves the origin component ports of the given flatComponentPort.</div>
     */
    @PublishedMethod
    void ofFlatExtractPort(@Nonnull IComponentPort flatComponentPort);

    /**
     * <div class="extdoc" id="completed">{@link #completed()} matches origin component ports which are completed.<br>
     * <p>
     * An {@link IOriginComponentPort} is completed if an only if all of its flat extract ports and additionally all of the delegation ports which are connected to these flat
     * extract ports are completed. (See {@link IComponentPort} for definition of completed state for flat extract ports.)
     * </p>
     * </div>
     */
    @PublishedMethod
    void completed();

    /**
     * <div class="extdoc" id="notCompleted">{@link #notCompleted()} matches origin component ports which are not completed.<br>
     * <p>
     * See {@link #completed()} for the conditions an origin port has to meet to be a completed port.
     * </p>
     * </div>
     */
    @PublishedMethod
    void notCompleted();

    /**
     * <div class="extdoc" id="put">{@link #put(List)} can be used to set {@link IOriginComponentPort}s into the selection. This is the most efficient way to create a selection
     * from existing objects. If further predicates are specified the predicates will be applied only on the origin component ports that were given into this {@link #put(List)}
     * method. The iteration order is relevant for getting deterministic results on further usage of the selection API. This method should only be called once.</div>
     *
     * @throws SelectionException if the method is called more than once or if the given originComponentPorts are null.
     */
    @PublishedMethod
    void put(List<IOriginComponentPort> originComponentPorts);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IOriginComponentPort> getSelectedOriginComponentPorts();
}
