package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class UnexpectedTypeException extends ModelException {

    private static final long serialVersionUID = 7164452307655536524L;

    private final Class<?> expectedType;

    private final Class<?> actualType;

    /**
     * Constructor.
     *
     * @param message
     */
    @PublishedMethod
    public UnexpectedTypeException(String message, Class<?> expectedType, Class<?> actualType) {
        super(formatMessage(message, expectedType, actualType));
        this.expectedType = expectedType;
        this.actualType = actualType;
    }

    private static String formatMessage(String message, Class<?> expectedType, Class<?> actualType) {
        final StringBuilder msg = new StringBuilder(message);
        msg.append(" - expected type: ");
        msg.append(expectedType.getName());
        msg.append(" - actual type: ");
        msg.append(actualType.getName());
        return msg.toString();
    }

    @PublishedMethod
    public Class<?> getExpectedType() {
        return expectedType;
    }

    @PublishedMethod
    public Class<?> getActualType() {
        return actualType;
    }

}
