package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@link PublishedApiFor} annotation allows to publish classes and interfaces which cannot be directly annotated with the {@link PublishedApi} annotation. <br>
 * In other words the class or interface passed as value to this annotation will be part of the published API. This might be helpfull for example for generated classes. <br>
 *
 * <p>
 * Note: The class or interface carrying the {@link PublishedApiFor} annotation will not and should not be published itself. Therefore annotating a class or interface with
 * {@link PublishedApiFor} and {@link PublishedApi} at the same time is not allowed and will be checked by the compiler.
 *
 * However the {@link PublishedApiFor} annotation can be combined with {@link PublishedApiDomain} and {@link PublishedBeta} annotations.
 * </p>
 *
 * For more information about the Published API see {@link PublishedApi} documentation.
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.TYPE)
public @interface PublishedApiFor {

    Class<?> value();
}
