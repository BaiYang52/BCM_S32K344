package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.asr.base.MBIReferrable;

/**
 * Thrown to indicate that a {@link MBIReferrable} object has no determinable autosar path.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ReferrableHasNoAutosarPathException extends ModelInconsistencyException {

    private static final long serialVersionUID = -6250273989567268891L;

    private final MBIReferrable mdfObject;

    /**
     * Constructor.
     *
     * @param mdfObject the MBIReferrable which has no autosar path.
     * @param ex
     */
    @KeepSecretFromPublishedApi
    public ReferrableHasNoAutosarPathException(MBIReferrable mdfObject, Throwable ex) {
        super("The AUTOSAR path is missing for " + checkMdfObjNonNull((MIObject) mdfObject).toString() + ".", ex);

        this.mdfObject = mdfObject;
    }

    @KeepSecretFromPublishedApi
    public MBIReferrable getCe() {
        return mdfObject;
    }
}
