package com.vector.cfg.persistency.location;

import java.net.URI;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.base.MIARElement;
import com.vector.cfg.model.mdf.model.autosar.base.MIARPackage;
import com.vector.cfg.model.persistency.IPersistencyLocation;
import com.vector.cfg.persistency.base.locations.EPersistencyLocationType;
import com.vector.cfg.util.version.IVersion;

/**
 * <div class="extdoc" id="General" data-target-doc="ModelDocumentation"> A {@link IPersistencyLocationPublished} represents a location which stores its data in an ARXML file.
 * <span class="javadocOnly">Instances of this type can be created by using the {@link IPersistencyLocationCreatorPublished}.</span >
 * <p>
 * <b>Remark:</b> The {@link IPersistencyLocationCreatorPublished} guarantees that only one instance exists per file.
 * </p>
 *
 * There are the following methods to create model elements within a location (See JavaDoc for more details):
 * <ul>
 * <li>{@link #createUniqueMappedAutosarElement(Class, AsrPath)}</li>
 * <li>{@link #createUniqueMappedAutosarObject(Class, MIObject, String)}</li>
 * <li>{@link #createUniqueMappedAutosarPackage(AsrPath)}</li>
 * </ul>
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface IPersistencyLocationPublished extends Comparable<IPersistencyLocationPublished> {

    /**
     * Returns the URI representation of the persistency location.
     *
     * @return the URI representing the {@link IPersistencyLocation}s path
     */
    @PublishedMethod
    URI toUri();

    /**
     * Returns <code>true</code> if the persistency location is in read-only state. This includes {@code #isUnconditionallyReadOnly()}.
     *
     * @return
     */
    @PublishedMethod
    boolean isReadOnly();

    /**
     * Returns <code>true</code> if the persistency location is readable.
     *
     * @return
     */
    @PublishedMethod
    boolean canRead();

    /**
     * Returns <code>true</code> if the persistency location exists.
     *
     * @return
     */
    @PublishedMethod
    boolean exists();

    /**
     * Returns the full AUTOSAR version of this location.
     *
     * @return
     */
    @PublishedMethod
    IVersion getAutosarVersion();

    /**
     * Sets the AUTOSAR version of this location if its version currently <code>null</code>. If the specified version if <code>null</code> it will be ignored.
     *
     * @param version
     */
    @PublishedMethod
    void setAutosarVersionIfMissing(IVersion version);

    /**
     * Return <code>true</code> if the {@link IPersistencyLocation} location is reloadable.
     *
     * @return
     */
    @PublishedMethod
    boolean isReloadable();

    /**
     * This method creates an new instance of the specified AUTOSAR element type, adds it to the model tree below the specified parent package and maps it uniquely to this
     * location. If the parent package doesn't exist it will be created too.
     *
     * @param mdfType           is the MDF type of the new object
     * @param parentPackagePath is an AUTOSAR path specifying the parent package of the new object
     * @return The new autosar element
     */
    @PublishedMethod
    @Nonnull
    <T extends MIARElement> T createUniqueMappedAutosarElement(@Nonnull Class<T> mdfType, @Nonnull AsrPath parentPackagePath);

    /**
     * This method creates an new instance of the specified AUTOSAR package, adds it to the model tree and maps it uniquely to this location. All non-existing parent packages will
     * be created too.
     *
     * @param packagePath is an AUTOSAR path specifying the new package
     * @return The new autosar package
     * @throws IllegalArgumentException if the specified AUTOSAR package already exists
     */
    @PublishedMethod
    @Nonnull
    MIARPackage createUniqueMappedAutosarPackage(@Nonnull AsrPath packagePath);

    /**
     * This method creates an new instance of the specified AUTOSAR object type, adds it to the model tree below the specified parent and maps it uniquely to this location.
     *
     * @param type       is the MDF type of the new object
     * @param parent     is the parent object
     * @param mdfFeature is the MDF feature name of the parent object the child shall be added to
     * @return The new object
     */
    @PublishedMethod
    @Nonnull
    <T extends MIObject> T createUniqueMappedAutosarObject(@Nonnull Class<T> mdfType, @Nonnull MIObject parent, @Nonnull String mdfFeature);

    /**
     * Gets the location type.
     *
     * @return the location type
     */
    @PublishedMethod
    @Nullable
    EPersistencyLocationType getLocationType();
}
