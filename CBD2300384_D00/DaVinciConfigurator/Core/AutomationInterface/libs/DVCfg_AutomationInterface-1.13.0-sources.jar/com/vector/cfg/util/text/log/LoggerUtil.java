package com.vector.cfg.util.text.log;

import static com.vector.cfg.util.text.format.Formatting.formatObject;

import java.io.File;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.string.StringUtil;
import com.vector.cfg.util.text.format.FormattingService;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class LoggerUtil {

    private static final String UNKNOWN_METHOD = "Unknown()";

    /**
     * Traces the method call with the method name at the beginning.
     *
     * @param logger the logger
     * @param arguments the arguments of the called method
     */
    @KeepSecretFromPublishedApi
    public static void traceMethodCall(ILogger logger, Object... arguments) {
        if (logger.isTraceEnabled()) {
            final String method = getMethodName(2);
            arguments = processArguments(arguments);
            logger.trace(method + " called with args ({0})" + formatObject(arguments));
        }
    }

    /**
     * traceFormat util method generates a trace message with the method name as prefix.
     *
     * <p>
     * The following types are resolved internally:
     * <ul>
     * <li>IDebugable -> toDebugString()</li>
     * <li>File -> getAbsolutePath()</li>
     * </ul>
     * </p>
     *
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void traceFormat(String pattern, Object... arguments) {
     *         LoggerUtil.traceFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param pattern the pattern
     * @param arguments the arguments
     * @deprecated use {@link ILogger#traceFormat(String, Object...)} instead
     */
    @PublishedMethod
    @Deprecated
    public static void traceFormat(ILogger logger, String pattern, Object... arguments) {
        if (logger.isTraceEnabled()) {
            final String method = getMethodName(3);

            arguments = processArguments(arguments);
            logger.trace(method + ": " + MessageFormat.format(pattern, arguments));
        }
    }

    /**
     * traceFormat util method generates a trace message with the method name as prefix.
     *
     * <p>
     * The following types are resolved internally:
     * <ul>
     * <li>IDebugable -> toDebugString()</li>
     * <li>File -> getAbsolutePath()</li>
     * </ul>
     * </p>
     *
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void traceFormat(String pattern, Object... arguments) {
     *         LoggerUtil.traceFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param pattern the pattern
     * @param arguments the arguments
     */
    @PublishedMethod
    public static void traceFormat(ILogger logger, Throwable ex, String pattern, Object... arguments) {
        if (logger.isTraceEnabled()) {
            final String method = getMethodName(3);

            arguments = processArguments(arguments);
            logger.trace(method + ": " + MessageFormat.format(pattern, arguments), ex);
        }
    }

    /**
     * traceFormat util method generates a trace message with the method name as prefix.
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void traceFormat(String message) {
     *         LoggerUtil.traceFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param message the message
     * @deprecated use {@link ILogger#traceFormat(String, Object...)} instead
     */
    @PublishedMethod
    @Deprecated
    public static void traceFormat(ILogger logger, String message) {
        if (logger.isTraceEnabled()) {
            final String method = getMethodName(3);
            logger.trace(method + ": " + message);
        }
    }

    /**
     * debugFormat util method generates a debug messages.
     *
     * <p>
     * The following types are resolved internally:
     * <ul>
     * <li>IDebugable -> toDebugString()</li>
     * <li>File -> getAbsolutePath()</li>
     * </ul>
     * </p>
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void debugFormat(String message) {
     *         LoggerUtil.debugFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param pattern the pattern
     * @param arguments the arguments
     * @deprecated use {@link ILogger#traceFormat(String, Object...)} instead
     */
    @Deprecated
    @PublishedMethod
    public static void debugFormat(ILogger logger, String pattern, Object... arguments) {
        if (logger.isDebugEnabled()) {
            arguments = processArguments(arguments);

            logger.debug(MessageFormat.format(pattern, arguments));
        }
    }

    /**
     * debugFormat util method generates a debug messages.
     *
     * <p>
     * The following types are resolved internally:
     * <ul>
     * <li>IDebugable -> toDebugString()</li>
     * <li>File -> getAbsolutePath()</li>
     * </ul>
     * </p>
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void debugFormat(String message) {
     *         LoggerUtil.debugFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param pattern the pattern
     * @param arguments the arguments
     *
     */
    @PublishedMethod
    public static void debugFormat(ILogger logger, Throwable ex, String pattern, Object... arguments) {
        if (logger.isDebugEnabled()) {
            arguments = processArguments(arguments);

            logger.debug(MessageFormat.format(pattern, arguments), ex);
        }
    }

    /**
     * debugFormat util method generates a debug messages.
     * <p>
     * Please do not call this method directly in your class use the method like this in your class:
     *
     * <pre>
     * <code>
     *     private static void debugFormat(String message) {
     *         LoggerUtil.debugFormat(logger, pattern, arguments);
     *     }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param logger the logger
     * @param message the message
     * @deprecated use {@link ILogger#traceFormat(String, Object...)} instead
     */
    @Deprecated
    @PublishedMethod
    public static void debugFormat(ILogger logger, String message) {
        if (logger.isDebugEnabled()) {
            logger.debug(message);
        }
    }

    /**
     * Format string.
     *
     * <p>
     * The following types are resolved internally:
     * <ul>
     * <li>IDebugable -> toDebugString()</li>
     * <li>File -> getAbsolutePath()</li>
     * </ul>
     * </p>
     *
     * @param pattern the pattern
     * @param arguments the arguments
     * @return the string
     * @deprecated Use the {@link FormattingService} instead.
     */
    @PublishedMethod
    @Deprecated
    public static String formatString(String pattern, Object... arguments) {
        arguments = processArguments(arguments);
        return MessageFormat.format(pattern, arguments);
    }

    private static Object[] processArguments(Object[] arguments) {
        final Object[] newArray = new Object[arguments.length];

        int x = 0;
        for (final Object obj : arguments) {
            newArray[x] = processArgument(obj);
            x++;
        }
        return newArray;
    }

    private static Object processArgument(Object obj) {
        try {
            final Object out;
            if (obj instanceof IDebugable) {
                out = ((IDebugable) obj).toDebugString();

            } else if (obj instanceof Throwable) {
                final Throwable ex = (Throwable) obj;
                out = Throwables.getStackTraceAsString(ex);

            } else if (obj instanceof File) {
                out = ((File) obj).getAbsolutePath();

            } else if (obj instanceof Path) {
                out = ((Path) obj).toAbsolutePath();

            } else if (obj instanceof Collection<?>) {
                out = "(" + FormattingService.INSTANCE.formatCollection((Collection<?>) obj, StringUtil.LINE_SEPARATOR) + ")";

            } else if (obj instanceof Object[]) {
                out = "(" + FormattingService.INSTANCE.formatCollection((Arrays.asList((Object[]) obj)), StringUtil.LINE_SEPARATOR) + ")";

            } else if (obj instanceof Iterable<?>) {
                final Collection<?> list = ImmutableList.copyOf((Iterable<?>) obj);
                out = "(" + FormattingService.INSTANCE.formatCollection(list, StringUtil.LINE_SEPARATOR) + ")";

            } else if (obj instanceof Iterator<?>) {
                final Collection<?> list = ImmutableList.copyOf((Iterator<?>) obj);
                out = "(" + FormattingService.INSTANCE.formatCollection(list, StringUtil.LINE_SEPARATOR) + ")";

            } else {
                out = FormattingService.INSTANCE.formatObject(obj);
            }
            return out;
        } catch (final RuntimeException ex) {
            return "Exception occured on logging: " + processArgument(ex);
        }
    }

    /*
     * Private Section
     */
    private static String getMethodName(int depthCorrection) {
        try {
            final StackTraceElement[] ste = Thread.currentThread().getStackTrace();

            final int requestedPosition = depthCorrection + 1;

            if (ste.length <= requestedPosition || requestedPosition < 0) {
                return UNKNOWN_METHOD;
            }

            return ste[requestedPosition].getMethodName() + "()";
        } catch (final Exception ex) {
            return UNKNOWN_METHOD;
        }
    }

    private LoggerUtil() {

    }

}
