package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.util.Collection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IHasDescription;
import com.vector.cfg.consistency.contribution.IHasSolvingActionGroups;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.helper.validationresults.ISolvingActionGroup;
import com.vector.cfg.consistency.core.impl.shared.ProjectService;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.operations.IModelOperationsPublished;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.IModelSimpleAccess;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.IProjectService;
import com.vector.cfg.util.collections.CollectionUtil;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="Common">
 * <h5>Creation of SolvingActions</h5> The {@link SolvingActionBuilder} provides an API to construct an {@link ISolvingAction}, which provides certain features:
 * <ul>
 * <li>You can define the {@link IModelView}, which shall be active during {@link #run()}</li>
 * <li>You can use the provided {@link IProjectService}s, without retrieving them, like:
 * <ul>
 * <li>modelOperations: {@link IModelOperationsPublished}</li>
 * <li>mca: {@link IModelCheckedAccess}</li>
 * <li>msa: {@link IModelSimpleAccess}</li>
 * <li>ma: {@link IModelAccess}</li>
 * <li>modelViewMgr: {@link IModelViewManager}</li>
 * </ul>
 * </li>
 * <li>You can override the {@link #getDescription()} to lazily provide a description, instead during construction time.</li>
 * </ul>
 *
 * The sample code constructs a {@link ISolvingAction}, which simply sets a float parameter to the value 3.
 *
 * <pre>
 * <code class="Java" id="Sample code to construct an ISolvingAction with SolvingActionBuilder">
 *  final ValidationResultBuilder valBuilder = ...;
 *
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext, "Set value to 3") {
 *
 *    &#64;Override
 *    public void run() {
 *        ma.setAsFloat(param1, 3);
 *    }
 *
 *  }.build();
 *
 *  valBuilder.addSolvingAction(sa);
 * </code>
 * </pre>
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="PostBuildSelectable">
 *
 * For the Post-build selectable use case, you could also explicitly pass an {@link IModelView}, which will be active during the {@link #run()} method call.
 *
 * <pre>
 * <code class="Java" id="Construct an ISolvingAction with an ModelView">
 *  final IModelView variantFrontLeft = ...;
 *
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext,
 *          "Set value to 3 in Variant Front Left",
 *          variantFrontLeft) {
 *
 *    &#64;Override
 *    public void run() {
 *        ma.setAsFloat(param1, 3);
 *    }
 *
 *  }.build();
 *
 * </code>
 * </pre>
 *
 *
 * You can use {@link ProjectService}s in the run method like in the sample below:
 *
 * <pre>
 * <code class="Java" id="Usage of ProjectServices in the SolvingActionBuilder">
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext, "Create and set all values to 3") {
 *
 *    &#64;Override
 *    public void run() {
 *        //Use of the modelOperations
 *        final MIParameterValue param1 = modelOperations.createParameterByDefinition(parent, DEFREF);
 *        final MIParameterValue param2 = modelOperations.createParameterByDefinition(parent, DEFREF);
 *
 *        //Use the ModelAccess
 *        ma.setAsFloat(param1, 3);
 *
 *        //Use the ModelViewManager
 *        IInvariantEcucDefView ecucDefView = modelViewMgr.getInvariantEcucDefView();
 *    }
 *
 *  }.build();
 *
 * </code>
 * </pre>
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="IHasSolvingActionGroups"> The {@link SolvingActionBuilder} also supports the
 * {@link IHasSolvingActionGroups} interface. Use {@link #assignToSolvingActionGroup(ISolvingActionGroup)} to make an assignment.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public abstract class SolvingActionBuilder implements Runnable, IHasDescription {

    @Nonnull
    private final IModelView viewToActivate;

    @Nullable
    private final String description;

    @PublishedField
    protected final IModelOperationsPublished modelOperations;

    @PublishedField
    @PublishedFilter(MsrPlatform.class)
    protected final IModelCheckedAccess mca;

    @PublishedField
    @PublishedFilter(MsrPlatform.class)
    protected final IModelSimpleAccess msa;

    @PublishedField
    protected final IModelAccess ma;

    @PublishedField
    protected final IModelViewManager modelViewMgr;

    private Builder<ISolvingActionGroup> solvingActionGroupListBuilder;

    /**
     * Create a {@link SolvingActionBuilder} with the passed description.
     *
     * <p>
     * The {@link IModelView} context is the {@link IModelView}, which is passed as parameter to this constructor.
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     * @param description    The Description of the {@link ISolvingAction}
     * @param viewToActivate The {@link IModelView}, which is active during {@link #run()}
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext, String description, IModelView viewToActivate) {
        checkNotNull(projectContext);

        this.description = description;
        modelOperations = projectContext.getService(IModelOperationsPublished.class);
        ma = projectContext.getService(IModelAccess.class);
        mca = projectContext.getService(IModelCheckedAccess.class);
        msa = projectContext.getService(IModelSimpleAccess.class);

        modelViewMgr = projectContext.getService(IModelViewManager.class);

        if (viewToActivate == null) {
            this.viewToActivate = modelViewMgr.getCurrentlyActiveView();
        } else {
            this.viewToActivate = viewToActivate;
        }

    }

    /**
     * Create a {@link SolvingActionBuilder} with the passed description.
     *
     * <p>
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during this constructor call!
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     * @param description    The Description of the {@link ISolvingAction}
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext, String description) {
        this(projectContext, description, null);

    }

    /**
     * Create a {@link SolvingActionBuilder} with no description.
     *
     * <p>
     * Caution: You have to override the {@link #getDescription()} method to return a Description, if you use this constructor!
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext) {
        this(projectContext, null, null);
    }

    /**
     * Adds a solving action group assignment to this solving action.
     *
     * @param solvingActionGroup the solving action group
     * @return the solving action builder
     */
    @PublishedMethod
    public SolvingActionBuilder assignToSolvingActionGroup(ISolvingActionGroup solvingActionGroup) {
        checkNotNull(solvingActionGroup);
        if (solvingActionGroupListBuilder == null) {
            solvingActionGroupListBuilder = ImmutableList.builder();
        }
        solvingActionGroupListBuilder.add(solvingActionGroup);
        return this;
    }

    /**
     * Adds solving action group assignments to this solving action.
     *
     * @param solvingActionGroups the solving action groups
     * @return the solving action builder
     */
    @PublishedMethod
    public SolvingActionBuilder assignToSolvingActionGroups(Collection<ISolvingActionGroup> solvingActionGroups) {
        checkNotNull(solvingActionGroups);
        if (solvingActionGroupListBuilder == null) {
            solvingActionGroupListBuilder = ImmutableList.builder();
        }
        solvingActionGroupListBuilder.addAll(solvingActionGroups);
        return this;
    }

    /**
     * Creates the {@link ISolvingAction}, with the specified execution code.
     *
     * @return the new {@link ISolvingAction} created from the builder.
     */
    @PublishedMethod
    public final ISolvingAction build() {
        final String descLoc = getDescription();
        checkNotNull(descLoc, "You must set a description in the constructor, or by overriding the method getDescription().");
        checkArgument(!descLoc.isEmpty());

        final ISolvingAction sa = SolvingActions.createSolvingActionWrapper(descLoc, this, CollectionUtil.nullToEmpty(solvingActionGroupListBuilder));
        return SolvingActions.executeInView(viewToActivate, sa);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Note: You could override this method, to lazily create the description. Then please use the {@link #SolvingActionBuilder(IProjectContext)} constructor.
     * </p>
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        return description;
    }

}
