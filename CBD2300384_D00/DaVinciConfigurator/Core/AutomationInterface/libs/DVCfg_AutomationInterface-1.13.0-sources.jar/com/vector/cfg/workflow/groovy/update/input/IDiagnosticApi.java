package com.vector.cfg.workflow.groovy.update.input;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.persistency.IPersistablePath;
import com.vector.cfg.util.annotations.DeferredExecution;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * Modifies the diagnostic input files.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDiagnosticApi {
    /**
     * modifies the list of diagnostic extracts.
     *
     * @param code the code {@link Closure} working with {@link IDiagnosticExtractApi}.
     * @return the result of the code {@link Closure}
     */
    @PublishedMethod
    <T> T extract(@VDelegatesToWithClosureParam(IDiagnosticExtractApi.class) Closure<T> code);

    /**
     * modifies the list of diagnostic extracts.
     *
     * @return the {@link IDiagnosticExtractApi}.
     */
    @PublishedMethod
    IDiagnosticExtractApi getExtract();

    /**
     * modifies the list of diagnostic legacy files.
     *
     * @param code the code {@link Closure} working with {@link IDiagnosticLegacyApi}.
     * @return the result of the code {@link Closure}
     */
    @PublishedMethod
    <T> T legacy(@VDelegatesToWithClosureParam(IDiagnosticLegacyApi.class) Closure<T> code);

    /**
     * modifies the list of diagnostic legacy files.
     *
     * @return the {@link IDiagnosticLegacyApi}.
     */
    @PublishedMethod
    IDiagnosticLegacyApi getLegacy();

    /**
     * Modifies the list of diagnostic extracts and selects the ecuInstance.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDiagnosticExtractApi extends IExtractApiBase {
        //no further functionality required
    }

    /**
     * Modifies the list of legacy diagnostic files and selects the ecuInstance.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDiagnosticLegacyApi {

        /**
         * sets an odx- or cdd-file as legacy diagnostic input file.
         *
         * Example:
         *
         * <pre>
         * <code>
         * setDiagnosticDescriptionFile(myOdxOrCddFilePath) {
         *   ecuInstanceAndVariantSelection{
         *      getAvailableEcuInstances.byName("myInstanceName").getVariants.byName("myVariantName")
         *   }
         *   singleSignelDidRid = true;
         *   stateDescriptionFilePath = pathToTheStateDescriptionFile;
         *
         * }
         * </code>
         * </pre>
         *
         * @param filePath the file path
         * @param code the code
         * @return the i legacy diag file
         */
        @PublishedMethod
        ILegacyDiagFile setDiagnosticDescriptionFile(IPersistablePath filePath, @VDelegatesToWithClosureParam(ILegacyDiagFileApi.class) Closure<?> code);

        /**
         * See {@link IDiagnosticLegacyApi#setDiagnosticDescriptionFile(Path, Closure)} for more information.
         *
         * @param filePath
         * @param code
         * @return
         */
        @PublishedMethod
        ILegacyDiagFile setDiagnosticDescriptionFile(IPersistablePath filePath, Consumer<ILegacyDiagFileApi> code);

        /**
         * removes the legacy diagnostic input file.
         */
        @PublishedMethod
        void clearDiagnosticDescriptionFile();

        /**
         * getter for the legacy diagnostic input file.
         *
         * @return the legacy diagnostic input file or <code>null</code> if not present.
         */
        @PublishedMethod
        ILegacyDiagFile getDiagnosticDescriptionFileOrNull();
    }

    /**
     * Represents a legacy diagnostic file.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface ILegacyDiagFile {

    }

    /**
     * Modifies a legacy diagnostic file
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface ILegacyDiagFileApi {

        /**
         * selects the ecuInstance of the extracts to import.
         *
         * <p>
         * <b>Note: This closure is deferred executed in the same thread as the script.</b>
         * </p>
         *
         *
         * <pre>
         * <code>
        ecuInstanceSelection{
            return availableEcuInstances.byName("myInstanceName").getVariants.byName("myVariantName");
        }
         * </code>
         * </pre>
         *
         * @param code
         */
        @PublishedMethod
        void ecuInstanceAndVariantSelection(
                @DeferredExecution(description = "This closure is deferred executed in the same thread as the script.") @VDelegatesToWithClosureParam(IEcuInstanceAndVariantSelectionApi.class) Closure<IDiagUpdateEcuVariant> code);

        /**
         * See {@link IExtractApiBase#ecuInstanceSelection(Closure)} for more information.
         *
         * @param code
         */
        @PublishedMethod
        void ecuInstanceAndVariantSelection(
                @DeferredExecution(description = "This consumer is deferred executed in the same thread as the script.") Function<IEcuInstanceAndVariantSelectionApi, IDiagUpdateEcuVariant> code);

        /**
         * Sets the patch file path. The patch file contains modifications to be applied before processing the diagnostic description. The file is provided by Vector if required.
         * No not change the content.
         *
         * @param patchFilePath the new patch file path
         */
        @PublishedMethod
        void setPatchFilePath(IPersistablePath patchFilePath);

        /**
         * Sets the single signal did rid. Import DIDs and RIDs as single signal for DCM (backward compatibility).
         *
         * @param singleSignelDidRid the new single signal did rid
         */
        @PublishedMethod
        void setSingleSignalDidRid(boolean singleSignalDidRid);

        /**
         * Sets the state description file path. If an ODX2.0.1 Diagnostic Description File is used, an additional State Description is required.
         *
         * @param stateDescriptionFilePath the new state description file path
         */
        @PublishedMethod
        void setStateDescriptionFilePath(IPersistablePath stateDescriptionFilePath);

        /**
         * Creates the state description by template.
         *
         * @param templatePath the template path
         * @param newStateDescriptionPath the new state description path
         * @return the new StateDescriptionPath
         * @deprecated Use {@link #createStateDescriptionByTemplate(Path, Path)} instead.
         */
        @ReworkThisAtNextBreakingChange("typo in method name change name")
        @PublishedMethod
        @Deprecated
        Path createStateDescriptionByTempate(Path templatePath, Path newStateDescriptionPath);

        /**
         * Creates the state description by template.
         *
         * @param templatePath the template path
         * @param newStateDescriptionPath the new state description path
         * @return the new StateDescriptionPath
         */
        @PublishedMethod
        Path createStateDescriptionByTemplate(Path templatePath, Path newStateDescriptionPath);
    }

    /**
     * Represents an item with a name.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDiagUpdateNamedItem {
        /**
         * getter for the name.
         *
         * @return the name of the item.
         */
        @PublishedMethod
        String getName();
    }

    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface INamedItemList<I extends IDiagUpdateNamedItem> extends List<I> {

        /**
         * Returns an item with the given name.
         *
         * @param name the name
         * @return the item
         * @throws IllegalArgumentException if the list contains no item with the given name.
         */
        @PublishedMethod
        I byName(String name);

        /**
         * By name or null.
         *
         * @param name the name
         * @return the item or <code>null</code> if the list contains no item with the given name.
         */
        @PublishedMethod
        I byNameOrNull(String name);
    }

    /**
     * Represents an ecu variant for variant selection of legacy diag files.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDiagUpdateEcuVariant extends IDiagUpdateNamedItem {

    }

    /**
     * Represents an ecu instance for ecu instance selection.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDiagUpdateEcuInstance extends IDiagUpdateNamedItem {

        /**
         * Gets the variants of this ecuInstance.
         *
         * @return the list of variants.
         */
        @PublishedMethod
        INamedItemList<? extends IDiagUpdateEcuVariant> getVariants();
    }

    /**
     * Api for the selection of an Ecu and Variant.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IEcuInstanceAndVariantSelectionApi {
        @PublishedMethod
        INamedItemList<? extends IDiagUpdateEcuInstance> getAvailableEcuInstances();

    }

}