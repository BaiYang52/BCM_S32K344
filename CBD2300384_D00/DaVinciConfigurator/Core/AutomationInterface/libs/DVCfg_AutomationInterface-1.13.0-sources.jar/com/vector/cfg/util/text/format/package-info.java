/**
 * DaVinci Configurator formatting API and {@link com.vector.cfg.util.text.format.IFormatter} types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.text.format;