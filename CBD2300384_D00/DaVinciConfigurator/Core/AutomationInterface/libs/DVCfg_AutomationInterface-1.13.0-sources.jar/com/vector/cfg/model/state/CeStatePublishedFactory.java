package com.vector.cfg.model.state;

import java.lang.ref.WeakReference;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.internal.state.CeStateSystem;
import com.vector.cfg.model.internal.state.CeStateUser;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This class implements a factory which allows creating CeState objects for code generators.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//@CHECKSTYLE:OFF Naming violation
public enum CeStatePublishedFactory {
    //@CHECKSTYLE:ON
    INSTANCE;

    /**
     * Creates a CeState system object.
     *
     * @param obj
     * @return
     * @throws IllegalArgumentException if the specified object reference is <code>null</code>
     */
    @PublishedMethod
    public ICeStatePublished createCeStateSystem(MIObject obj) {
        return createCeState(obj, false);
    }

    @KeepSecretFromPublishedApi
    public ICeStatePublished createCeState(MIObject obj, boolean isUserCeStateEnabled) {
        if (obj == null) {
            throw new IllegalArgumentException("Null argument");
        }
        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(obj);
        final WeakReference<MIObject> ref = new WeakReference<>(obj);

        if (isUserCeStateEnabled) {
            return new CeStateUser(projectContext, ref);
        } else {
            return new CeStateSystem(projectContext, ref);
        }
    }

    /**
     * Creates a CeState object for a parameter.
     *
     * @param parameter
     * @return
     * @throws IllegalArgumentException if the specified object reference is <code>null</code>
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    public IParameterStatePublished createParameterStateSystem(MIParameterValue parameter) {
        if (parameter == null) {
            throw new IllegalArgumentException("Null argument");
        }
        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(parameter);
        final WeakReference<MIObject> ref = new WeakReference<>(parameter);
        final IParameterStatePublished state = new CeStateSystem(projectContext, ref);
        return state;
    }

    /**
     * Creates a CeState object for a container.
     *
     * @param container
     * @return
     * @throws IllegalArgumentException if the specified object reference is <code>null</code>
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    public IContainerStatePublished createContainerStateSystem(MIContainer container) {
        if (container == null) {
            throw new IllegalArgumentException("Null argument");
        }
        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(container);
        final WeakReference<MIObject> ref = new WeakReference<>(container);
        final IContainerStatePublished state = new CeStateSystem(projectContext, ref);
        return state;
    }

    /**
     * Creates a CeState object for a module configuration.
     *
     * @param moduleConfiguration
     * @return
     * @throws IllegalArgumentException if the specified object reference is <code>null</code>
     */
    @PublishedMethod
    @PublishedFilter(MsrPlatform.class)
    public IModuleConfigurationStatePublished createModuleConfigurationStateSystem(MIModuleConfiguration moduleConfiguration) {
        if (moduleConfiguration == null) {
            throw new IllegalArgumentException("Null argument");
        }
        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(moduleConfiguration);
        final WeakReference<MIObject> ref = new WeakReference<>(moduleConfiguration);
        final IModuleConfigurationStatePublished state = new CeStateSystem(projectContext, ref);
        return state;
    }

}
