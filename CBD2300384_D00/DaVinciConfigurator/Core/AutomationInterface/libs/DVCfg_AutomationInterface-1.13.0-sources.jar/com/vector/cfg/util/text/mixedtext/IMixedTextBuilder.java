package com.vector.cfg.util.text.mixedtext;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * An {@link IMixedTextBuilder} can be used to easily create text that consists of plain text and enhanced text representations of objects in the Cfg environment. So basically
 * you don't have to take care for formating and stringifying objects, but just append everything you want. If something is not supported or does not work as expected, let me
 * know (visbrh)<BR>
 * Features:
 * <ul>
 * <li>Connecting spaces are automatically added</li>
 * <li>When adding a {@link MIParameterValue} one can specify to also add its value into the text</li>
 * <li>Unneeded whitespace will be truncated</li>
 * <li>The resulting {@link IMixedText} allows further formating and access to the whole plain string or to its individual (object) parts</li>
 * </ul>
 *
 * Create a new {@link IMixedTextBuilder} like this MixedText.newBuilder();
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMixedTextBuilder {
    /**
     * Append text. If the previous or following
     *
     * @param text
     * @return itself
     */
    @PublishedMethod
    IMixedTextBuilder append(String text/* , false */);

    @PublishedMethod
    IMixedTextBuilder append(String text, boolean dontAddConnectingSpace);

    @PublishedMethod
    IMixedTextBuilder append(Object object);

    /**
     * Appends a {@link DefRef} object to the {@link IMixedTextBuilder}. If no formatString is specified the {@link IDefRefPart#DEFREF_FORMAT_NORMAL} format string is used.
     *
     * @param object the DefRef to add
     * @param formatPattern The formatPattern. The string must be one of the elements in {@link IDefRefPart}.
     * @return this builder
     */
    @PublishedMethod
    IMixedTextBuilder append(Object object, String formatPattern);

    @PublishedMethod
    IMixedTextBuilder append(IMixedText mixedText/* , false */);

    @PublishedMethod
    IMixedTextBuilder append(IMixedText mixedText, boolean dontAddConnectingSpace);

    /**
     * Each format item takes the following form and consists of the following components:
     * <p>
     * <b>{index[:formatString]}</b> <br />
     * formatString = letter {letter | digit | _}*(','letter {letter | digit | _}*)* <br />
     * The matching braces ("{" and "}") are required.
     * </p>
     *
     * <p>
     * <b>Index Component</b><br />
     * The mandatory index component, also called a parameter specifier, is a number starting from 0 that identifies a corresponding item in the list of objects. That is, the
     * format item whose parameter specifier is 0 formats the first object in the list, the format item whose parameter specifier is 1 formats the second object in the list, and
     * so on.
     *
     * Each format item can refer to any object in the list. For example, if there are three objects, you can format the second, first, and third object by specifying a
     * composite format string like this: "{1} {0} {2}". An object that is not referenced by a format item is ignored. A IllegalArgumentException results if a parameter
     * specifier designates an item outside the bounds of the list of objects.
     *
     *
     * <p>
     * <b>Format Options</b><br />
     * Formatting options are published and documented via classes that follow this naming convention MixedTextFormat*. Look out for classes with this name to find formatting
     * options for a particular object type.<br />
     * Exemplary Format Strings:<br />
     * <ul>
     * <li>MIParameterValue :
     * <ul>
     * <li>noValue</li>
     * <li>onlyValue</li>
     * </ul>
     * </li>
     * <li>IFormattable :
     * <ul>
     * <li>The Format pattern is passed to the Formattable object, so every object can implement its own Format options.</li>
     * </ul>
     * </li>
     * </ul>
     * </p>
     *
     * <p>
     * <b>Escaping Braces</b><br />
     * Opening and closing braces are interpreted as starting and ending a format item. Consequently, you must use an escape sequence to display a literal opening brace or
     * closing brace. Specify two opening braces ("{{") in the fixed text to display one opening brace ("{"), or two closing braces ("}}") to display one closing brace ("}").
     * Braces in a format item are interpreted sequentially in the order they are encountered. Interpreting nested braces is not supported.
     * </p>
     *
     * <p>
     * <b>Newlines</b><br />
     * The format string can contain the pattern {nl} to indicate a newlines in the output string. All {nl} will be replaced by the platform dependent newline characters.
     * </p>
     *
     * @param formatPattern A composite format string.
     * @param arguments An array of objects to format.
     * @return This mixedTextBuilder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the formatPattern is null</li>
     * <li>if the formatPattern is invalid</li>
     * </ul>
     */
    @PublishedMethod
    IMixedTextBuilder appendFormat(String formatPattern, Object... arguments);

    @PublishedMethod
    IMixedText flushResult();
}
