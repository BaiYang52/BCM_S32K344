package com.vector.cfg.model.access.ecuconfiguration.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationClass;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucContainer}</b> is the base interface of all container wrappers. It provides the following method(s): </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucContainer extends IEcucHasDefinition, IReferrable {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    MIContainer getEcucObject();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucContainerDefinition getEcucDefinition();

    /**
     * <div class="extdoc" id="getEffectiveMultiplicityConfigurationClass"> The {@link #getEffectiveMultiplicityConfigurationClass()} method walks up the model tree to find the
     * related module configuration. Then it uses the module implementation configuration variant to return the selected configuration class as specified in the container
     * definition.
     * <p>
     * This method never returns <code>null</code>. In case the detection of the configuration class fails (e.g. if the related module configuration cannot be detected), this
     * method returns {@link EEcucConfigurationClass#PRE_COMPILE} by default. It also never returns {@link EEcucConfigurationClass#LINK}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getEffectiveMultiplicityConfigurationClass();

    /**
     * <div class="extdoc" id="getEffectiveMultiplicityConfigurationClassDefRef"> The {@link #getEffectiveMultiplicityConfigurationClass(DefRef)} method walks up the model tree to
     * find the related module configuration. Then it uses the module implementation configuration variant to return the selected configuration class of the specified parameter
     * definition.
     * <p>
     * This method never returns <code>null</code>. In case the detection of the configuration class fails (e.g. if the related module configuration cannot be detected), this
     * method returns {@link EEcucConfigurationClass#PRE_COMPILE} by default. It also never returns {@link EEcucConfigurationClass#LINK}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param parameterDef is the definition of a parameter
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getEffectiveMultiplicityConfigurationClass(DefRef parameterDef);

    /**
     * <div class="extdoc" id="getEffectiveValueConfigurationClass"> The {@link #getEffectiveValueConfigurationClass(DefRef)} method walks up the model tree to find the related
     * module configuration. Then it uses the module implementation configuration variant to return the selected configuration class of the specified parameter definition.
     * <p>
     * This method never returns <code>null</code>. In case the detection of the configuration class fails (e.g. if the related module configuration cannot be detected), this
     * method returns {@link EEcucConfigurationClass#PRE_COMPILE} by default. It also never returns {@link EEcucConfigurationClass#LINK}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param parameterDef is the definition of a parameter
     * @return
     */
    @PublishedMethod
    EEcucConfigurationClass getEffectiveValueConfigurationClass(DefRef parameterDef);

    /**
     * <div class="extdoc" id="supportsVariantMultiplicity"> The {@link #supportsVariantMultiplicity()} method returns <code>true</code> if the related module configuration
     * supports variance and this containers definition support variant multiplicity. If <code>true</code> is returned this means that different variants may contain different
     * number of instances of this container.
     * <p>
     * If the container has no definition, this method returns <code>false</code>.
     * </p>
     * <p>
     * This method is for post-build selectable only!
     * </p>
     * </div>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantMultiplicity();

}
