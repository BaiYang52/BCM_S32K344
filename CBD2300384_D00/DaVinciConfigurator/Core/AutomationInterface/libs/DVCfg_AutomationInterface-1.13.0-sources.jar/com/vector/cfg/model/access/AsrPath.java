package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nullable;

import ru.novosoft.mdf.ext.MDFObject;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.exceptions.InvisibleVariantObjectException;
import com.vector.cfg.model.exceptions.ModelCeAlreadyRemovedException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.testing.IMockProvider;

/**
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see DefRef
 * @see TypedAsrPath
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ReworkThisAtNextBreakingChange("Make this class abstract since we want TypedAsrPath instances only")
public class AsrPath {

    /**
     * The Constant INVALID_ASRPATH describes an AUTOSAR path, which will never be equal to any other autosar paths.
     */
    @PublishedField
    public static final AsrPath INVALID_ASRPATH = create("/INVALID-PACKAGE/INVALID-SHORTNAME");

    @Nullable // Null when it has no parent
    private final AsrPath parent = INVALID_ASRPATH;

    AsrPath() {
    }

    /**
     * TypedAsrPath MUST override. Rework at next breaking change: make method abstract.
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    protected com.vector.cfg.model.base.api.access.AsrPath getDelegateAsrPath() {
        return null;
    }

    /*
     * Factory methods
     */
    /**
     * Constructs an AUTOSAR path from a MDF model object.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param referrable The model object,
     * @return The AsrPath object
     *
     * @exception IllegalArgumentException
     *                                            <ul>
     *                                            <li>if the mdfObj is null</li>
     *                                            </ul>
     * @exception ModelCeHasNoDefinitionException
     *                                            <ul>
     *                                            <li>if the mdfObj has no AUTOSAR path</li>
     *                                            </ul>
     * @exception ModelCeAlreadyRemovedException
     *                                            <ul>
     *                                            <li>if the mdfObj is already removed</li>
     *                                            </ul>
     *
     * @see #tryCreate(MIReferrable)
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final T referrable) {
        return new TypedAsrPath<>(com.vector.cfg.model.base.api.access.AsrPath.create(referrable));
    }

    /**
     * Constructs an AUTOSAR path from a MDF model object.
     *
     * <p>
     * The {@link AsrPath#tryCreate(MIReferrable)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param mdfObj The model object,
     * @return The AsrPath object or <code>null</code> if the mdfObj has no AUTOSAR path.
     *
     * @see #create(MIReferrable)
     * @deprecated This method will be removed in a future release, use {@link TypedAsrPath#tryCreate(String,Class)}
     */
    @Deprecated
    @PublishedMethod
    public static AsrPath tryCreate(final MIReferrable mdfObj) {
        if (mdfObj == null) {
            return null;
        }

        if (mdfObj instanceof IMockProvider) {
            return handleMockedMDFObjects((IMockProvider) mdfObj);
        }

        if (ModelAccessUtil.isRemovedOnly(mdfObj)) {
            return null;
        }

        final String autosarPath;
        try {
            autosarPath = ModelUtil.getReferrableAccess(mdfObj).getAutosarPath(mdfObj);
        } catch (final IllegalStateException | InvisibleVariantObjectException ex) {
            /*
             * No Path
             */
            return null;
        }
        @SuppressWarnings("unchecked")
        final Class<? extends MIReferrable> clazz = mdfObj.mdfGetInterfaceClass();
        return create(autosarPath, clazz);
    }

    /**
     * Tries to create a {@link TypedAsrPath} from the mocked {@link IMockProvider}.
     *
     *
     * @param mdfObj the MockObject
     * @return the {@link TypedAsrPath} of the mocked obj or NULL.
     *         <ul>
     *         <li>if the mdfObj does not support {@link TypedAsrPath}s</li>
     *         </ul>
     */
    private static AsrPath handleMockedMDFObjects(final IMockProvider mdfObj) {
        AsrPath asrPath = mdfObj.get(TypedAsrPath.class);
        if (asrPath == null) {
            asrPath = mdfObj.get(AsrPath.class);
        }

        return asrPath;
    }

    /**
     * Constructs an AUTOSAR path by a path string and a parent AsrPath object. The path String can be absolute or relative to the parent object.
     *
     * @param parentAsrPath   The parent AsrPath
     * @param childPathString The path string of the child
     *
     * @return The child AsrPath object
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the parentAsrPath is null</li>
     *                                     <li>if the childPathString is null</li>
     *                                     <li>if the childPathString is empty</li>
     *                                     <li>if the childPathString is absolute and is no child of the parent object</li>
     *                                     <li>if the childPathString ends with '/'</li>
     *                                     </ul>
     * 
     * @deprecated This method will be removed in a future release, use {@link TypedAsrPath#create(AsrPatj,String,Class)}
     */
    @Deprecated
    @PublishedMethod
    public static AsrPath create(final AsrPath parentAsrPath, final String childPathString) {
        if (parentAsrPath == null) {
            throw new IllegalArgumentException("parentDefRefObj is null.");
        }
        return new TypedAsrPath<>(
                com.vector.cfg.model.base.api.access.AsrPath.create(com.vector.cfg.model.base.api.access.AsrPath.create(parentAsrPath.getAutosarPathString()), childPathString,
                        MIReferrable.class));

    }

    /**
     * Constructs an AUTOSAR path by a path string and a parent AsrPath object. The path String can be absolute or relative to the parent object.
     *
     * @param parentAsrPath   The parent AsrPath
     * @param childPathString The path string of the child
     *
     * @return The child AsrPath object
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the parentAsrPath is null</li>
     *                                     <li>if the childPathString is null</li>
     *                                     <li>if the metaModelClass is null</li>
     *                                     <li>if the childPathString is empty</li>
     *                                     <li>if the childPathString is absolute and is no child of the parent object</li>
     *                                     <li>if the childPathString ends with '/'</li>
     *                                     </ul>
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final AsrPath parentAsrPath, final String childPathString, final Class<T> metaModelClass) {
        return new TypedAsrPath<>(com.vector.cfg.model.base.api.access.AsrPath.create(com.vector.cfg.model.base.api.access.AsrPath.create(parentAsrPath.getAutosarPathString()),
                childPathString, metaModelClass));
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString     The path string starting with a '/'
     * @param metaModelClass The metaModelClass for the specified path.
     * @return the {@link AsrPath} for the passed pathString
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the pathString is null</li>
     *                                     <li>if the metaModelClass is null</li>
     *                                     <li>if the pathString is empty</li>
     *                                     <li>if the pathString is not an absolute path</li>
     *                                     <li>if the pathString ends with '/'</li>
     *                                     </ul>
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final String pathString, final Class<T> metaModelClass) {
        return new TypedAsrPath<>(com.vector.cfg.model.base.api.access.AsrPath.create(pathString, metaModelClass));
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     * @return the {@link AsrPath} for the passed pathString
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the pathString is null</li>
     *                                     <li>if the pathString is empty</li>
     *                                     <li>if the pathString is not an absolute path</li>
     *                                     <li>if the pathString ends with '/'</li>
     *                                     </ul>
     * 
     * @deprecated This method will be removed in a future release, use {@link TypedAsrPath#create(String,Class)}
     */
    @Deprecated
    @PublishedMethod
    public static AsrPath create(final String pathString) {
        return create(pathString, MIReferrable.class);
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     *
     * @return The AsrPath object or <code>null</code> if the passed pathString is invalid
     *
     * @see #create(MIReferrable)
     *
     * @deprecated This method will be removed in a future release, use {@link TypedAsrPath#create(String,Class)}
     */
    @Deprecated
    @PublishedMethod
    public static AsrPath tryCreate(String pathString) {
        if (pathString == null) {
            return null;
        }

        try {
            return create(pathString);
        } catch (final IllegalArgumentException ex) {
            /*
             * No valid Path
             */
            return null;
        }
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString     The path string starting with a '/'
     * @param metaModelClass The metaModelClass for the specified path.
     * @return The AsrPath object or <code>null</code> if the passed pathString is invalid
     *
     * @see #create(MIReferrable)
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> tryCreate(final String pathString, final Class<T> metaModelClass) {
        if (pathString == null) {
            return null;
        }

        try {
            return create(pathString, metaModelClass);
        } catch (final IllegalArgumentException ex) {
            /*
             * No valid Path
             */
            return null;
        }
    }

    /*
     * Public methods
     */

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return getDelegateAsrPath().hashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == INVALID_ASRPATH || obj == INVALID_ASRPATH) {
            /*
             * A INVALID_ASRPATH is never equal to anything!
             */
            return false;
        }

        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }

        if (!(obj instanceof AsrPath)) {
            return false;
        }

        final AsrPath other = (AsrPath) obj;
        return getDelegateAsrPath().equals(other.getDelegateAsrPath());
    }

    /**
     * Gets the AUTOSAR path string of this {@link AsrPath}.
     *
     * @return the path string
     */
    @PublishedMethod
    public String getAutosarPathString() {
        return getDelegateAsrPath().getAutosarPathString();
    }

    /**
     * Returns the shortnames of the AUTOSAR path in the order they occur in the path.
     *
     * @return
     */
    @PublishedMethod
    public List<String> getShortnames() {
        return getDelegateAsrPath().getShortnames();
    }

    /**
     * Checks if <code>this</code> object is parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child AsrPath
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the presumableChild is null</li>
     *                                     </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @PublishedMethod
    public boolean isParentOf(final AsrPath presumableChild) {
        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        return getDelegateAsrPath().isParentOf(presumableChild.getDelegateAsrPath());
    }

    /**
     * Checks if <code>this</code> object is the immediate parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child AsrPath
     * @return <code>true</code>, if the parameter is a immediate child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the presumableChild is null</li>
     *                                     </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     * @see #isParentOf(AsrPath)
     * @see #isParentOf(MIObject)
     */
    @PublishedMethod
    public boolean isImmediateParentOf(final AsrPath presumableChild) {
        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        return getDelegateAsrPath().isImmediateParentOf(presumableChild.getDelegateAsrPath());
    }

    /**
     * Checks if <code>this</code> object is parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child ModelObject
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the presumableChild is null</li>
     *                                     </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @PublishedMethod
    public boolean isParentOf(final MIObject presumableChild) {
        return getDelegateAsrPath().isParentOf(presumableChild);
    }

    /**
     * Returns a parent {@link AsrPath} Object. The last part of this {@link AsrPath} object is truncated.
     *
     * @return The parent {@link AsrPath}, or null, when there is no parent {@link AsrPath}.
     */
    @PublishedMethod
    public AsrPath getParentAsrPath() {
        final com.vector.cfg.model.base.api.access.AsrPath parentAsrPath = getDelegateAsrPath().getParentAsrPath();
        if (parentAsrPath == null) {
            return null;
        }
        return new TypedAsrPath<>(uncheckedCast(parentAsrPath));
    }

    /**
     * Gets the last Shortname of the {@link AsrPath}.
     *
     * @return The last Shortname of this {@link AsrPath}.
     */
    @PublishedMethod
    public String getLastShortname() {
        return getDelegateAsrPath().getLastShortname();
    }

    /**
     * Returns the immediate child if the this {@link AsrPath}, if this object is parent of the indirectChild.
     *
     * @param indirectChild
     * @return the immediate child {@link AsrPath} of this object.
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if indirectChild is null</li>
     *                                     </ul>
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if presumed indirectChild DefRef is no child of this Parent object.</li>
     *                                     </ul>
     */
    @PublishedMethod
    public AsrPath getImmediateChild(final AsrPath indirectChild) {
        return new TypedAsrPath<>(uncheckedCast(getDelegateAsrPath().getImmediateChild(indirectChild.getDelegateAsrPath())));
    }

    /**
     * Constructs a {@link TypedAsrPath} by this {@link AsrPath} object.
     *
     * @param metaModelClass The metamodel class of the AUTOSAR path. E.g. MIContainer.class
     *
     * @return the created {@link TypedAsrPath}
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the metaModelClass is null</li>
     *                                     </ul>
     */
    @PublishedMethod
    public <METACLASS_TYPE extends MIReferrable> TypedAsrPath<METACLASS_TYPE> createTypedAsrPath(final Class<METACLASS_TYPE> metaModelClass) {
        return create(getAutosarPathString(), metaModelClass);
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject.
     *
     *
     * <p>
     * Note: This method is an implicit null and {@link MIReferrable} check. This means, if it returns true, the modelObject is an instance of {@link MIReferrable}.
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject.
     *
     */
    @PublishedMethod
    public boolean isPathOf(final MIObject modelObject) {
        return getDelegateAsrPath().isPathOf(modelObject);
    }

    /**
     * @deprecated Do not use
     *
     * @param modelObject
     * @return
     */
    @PublishedMethod
    @Deprecated
    @ReworkThisAtNextBreakingChange("Remove it completely")
    protected boolean isPathOfInternal(final MIObject modelObject) {
        if (this == INVALID_ASRPATH) {
            return false;
        }
        if (modelObject instanceof MIReferrable) {
            final MIReferrable ref = (MIReferrable) modelObject;
            if (this.getLastShortname().equals(ref.getName())) {
                final MDFObject parentMdf = modelObject.refImmediateComposite();
                if (parentMdf instanceof MIReferrable) {
                    final AsrPath parentAsrPath = this.getParentAsrPath();
                    if (parentAsrPath != null && parentAsrPath.isPathOf((MIReferrable) parentMdf)) {
                        return true;
                    }
                }
                if (parentMdf instanceof MIAUTOSAR) {
                    if (this.getParentAsrPath() == null) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of classToCheck.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject  The modelObject to check.
     * @param classToCheck The class which the modelObject must be an instance of.
     * @return <code>true</code>, if this is the AUTOSAR path of the modelObject and it is instance of classToCheck.
     * @see #isPathOf(MIObject)
     *
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if the classToCheck is null</li>
     *                                     </ul>
     */
    @PublishedMethod
    public <T extends MIReferrable> boolean isPathOf(final MIObject modelObject, final Class<T> classToCheck) {
        return getDelegateAsrPath().isPathOf(modelObject, classToCheck);
    }

    /**
     * @deprecated Do not use
     *
     * @param modelObject
     * @return
     */
    @PublishedMethod
    @Deprecated
    @ReworkThisAtNextBreakingChange("Remove it completely")
    protected <T extends MIReferrable> boolean isPathOfInternal(final MIObject modelObject, final Class<T> classToCheck) {
        if (classToCheck == null) {
            throw new IllegalArgumentException("classToCheck is null.");
        }

        /*
         * Check Definition
         */
        if (!isPathOfInternal(modelObject)) {
            return false;
        }

        if (classToCheck.isInstance(modelObject)) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of modelObjectClass. If the check is true, the method returns the object
     * casted to modelObjectClass. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>object</code>, if this is the AUTOSAR path of the modelObject and it is instance of modelObjectClass. Otherwise null.
     * @see #isDefinitionOf(MIObject)
     *
     */
    @PublishedMethod
    public <T extends MIReferrable> T asPathOf(final MIObject modelObject, final Class<T> classToCheck) {
        return getDelegateAsrPath().asPathOf(modelObject, classToCheck);
    }

    /**
     * @deprecated Do not use
     *
     * @param modelObject
     * @return
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Deprecated
    @ReworkThisAtNextBreakingChange("Remove it completely")
    protected <T extends MIReferrable> T asPathOfInternal(final MIObject modelObject, final Class<T> classToCheck) {

        checkNotNull(classToCheck);
        /*
         * Check Definition and class
         */
        if (!isPathOfInternal(modelObject, classToCheck)) {
            return null;
        }
        /*
         * Cast element
         */
        return (T) modelObject;
    }

    /**
     * Returns the absolute AUTOSAR path in string representation.
     *
     * <p>
     * Attention: Do not use toString to retrieve the AUTOSAR path string from a {@link AsrPath} object. Please use {@link #getAutosarPathString()}.
     * </p>
     *
     * @return The DefRef representation
     */
    @PublishedMethod
    @Override
    public String toString() {
        return getDelegateAsrPath().toString();
    }

    /**
     * Returns the MDF AUTOSAR object for this path.
     *
     * Returns null, if no MDF AUTOSAR object exists.
     *
     * @return The MDF AUTOSAR object, or null if no object exists.
     *
     * @exception IllegalArgumentException
     *                                            <ul>
     *                                            <li>if projectContext is null</li>
     *                                            </ul>
     * @exception MultipleVariantObjectsException
     *                                            <ul>
     *                                            <li>if more than one object have been found. Better use {@link #getAutosarObjects(IProjectContext)} in variant contexts!</li>
     *                                            </ul>
     */
    @PublishedMethod
    public MIReferrable getAutosarObject(final IProjectContext projectContext) {
        return uncheckedCast(getDelegateAsrPath().getAutosarObject(projectContext));
    }

    /**
     * Returns all MDF AUTOSAR objects for this path.
     *
     * Returns an empty list, if no MDF AUTOSAR object exists.
     *
     * @return The MDF AUTOSAR objects, or an empty list if no object exists (never <code>null</code>)
     *
     * @exception IllegalArgumentException
     *                                     <ul>
     *                                     <li>if projectContext is null</li>
     *                                     </ul>
     */
    @PublishedMethod
    public Collection<MIReferrable> getAutosarObjects(final IProjectContext projectContext) {
        return uncheckedCast(getDelegateAsrPath().getAutosarObjects(projectContext));
    }

}
