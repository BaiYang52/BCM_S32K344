package com.vector.cfg.persistency.location;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.project.EEnvironmentTargetType;
import com.vector.cfg.model.persistency.IPersistencyLocation;
import com.vector.cfg.persistency.base.locations.EPersistencyLocationType;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.version.IVersion;

/**
 * <div class="extdoc" id="General" data-target-doc="ModelDocumentation"> With the {@link IPersistencyLocationCreatorPublished} instances of the type
 * {@link IPersistencyLocationPublished} can be created specified by a {@link Path} and a {@link EPersistencyLocationType}.
 *
 * </div>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see EEnvironmentTargetType
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
@ThreadSafe
public interface IPersistencyLocationCreatorPublished {

    /**
     * Creates a {@link IPersistencyLocationCreatorPublished}.
     *
     * @param projectContex the project contex
     * @return the creator
     */
    @PublishedMethod
    @Nonnull
    static IPersistencyLocationCreatorPublished create(@Nonnull IProjectContext projectContex) {
        return projectContex.getService(IPersistencyLocationCreatorPublished.class);
    }

    /**
     * Creates or gets a already existing {@link IPersistencyLocationPublished} specified by a {@link Path}, a AUTOSAR version and a {@link EPersistencyLocationType}. If the
     * location is already existing and this method is called with another AUTOSAR version, the version in the location will be overridden.
     *
     * <p>
     * The passed path can be a simple filename, a relative path or a absolute path. This depends on the passed {@link EPersistencyLocationType}.
     * </p>
     *
     * @param path           the path
     * @param autosarVersion the autosar version
     * @param type           the persistency location type
     * @return the location
     */
    @PublishedMethod
    @Nonnull
    IPersistencyLocationPublished getOrCreateLocation(@Nonnull Path path, @Nonnull IVersion autosarVersion, @Nonnull EPersistencyLocationType type);

    /**
     * Creates a {@link IPersistencyLocationManagerPublished} instance specified by the given {@link IPersistencyLocation}.
     * 
     * @param persistencyLocation The {@link IPersistencyLocation}.
     * @return The {@link IPersistencyLocationManagerPublished} instance.
     */
    @KeepSecretFromPublishedApi
    @Nonnull
    IPersistencyLocationPublished getOrCreateLocation(@Nonnull IPersistencyLocation persistencyLocation);

}
