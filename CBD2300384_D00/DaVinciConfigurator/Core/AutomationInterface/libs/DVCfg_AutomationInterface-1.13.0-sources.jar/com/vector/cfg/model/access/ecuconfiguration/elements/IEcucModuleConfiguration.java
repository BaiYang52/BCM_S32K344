package com.vector.cfg.model.access.ecuconfiguration.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucModuleDefinition;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucModuleConfiguration}</b> is the base interface of all module configuration wrappers. It provides the following method(s):
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucModuleConfiguration extends IEcucHasDefinition, IReferrable {

    /**
     * Returns <code>true</code> if the modules definition (BSWMD file) has AUTOSAR schema >= 4.2.1.
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    boolean isDefinitionSchema421OrNewer();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    MIModuleConfiguration getEcucObject();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucModuleDefinition getEcucDefinition();

    /**
     * Returns <code>true</code> if this module configuration contains an explicit specification of the config variant.
     * <p>
     * This is for post-build loadable only!
     * </p>
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    boolean hasConfigurationVariant();

    /**
     * Removes the modules implementation config variant value. Usual client code and generators never need this functionality. Its provided for core intern use cases, e.g. in the
     * update workflow and for tests only.
     */
    @KeepSecretFromPublishedApi
    void removeConfigurationVariant();

    /**
     * <div class="extdoc" id="getConfigurationVariant"> The {@link #getConfigurationVariant()} method returns the modules configuration variant.
     * <p>
     * This method never returns <code>null</code>. If the module has no value specified, this method returns a default value as follows:
     * <ul>
     * <li>{@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}, if it is contained in the supported config variants of the related module definition</li>
     * <li>otherwise {@link EEcucConfigurationVariant#VARIANT_LINK_TIME}, if it is contained in the supported config variants of the related module definition</li>
     * <li>otherwise {@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}, if it is contained in the supported config variants of the related module definition</li>
     * <li>otherwise {@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}, even if not contained in the supported config variants of the related module definition or if the
     * definition is not available</li>
     * </ul>
     *
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the module configurations implementation config variant defined if this module implements post-build loadable
     * and/or selectable. With AUTOSAR 4.2.1 the implementation config variant defines only if the module implements post-build loadable. The post-build selectable aspect has been
     * separated from this definition. This method handles the loadable semantic, independent of the AUTOSAR version.
     * </p>
     * <p>
     * This is for post-build loadable only!
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    EEcucConfigurationVariant getConfigurationVariant();

    /**
     * <div class="extdoc" id="setConfigurationVariant"> The {@link #setConfigurationVariant(EEcucConfigurationVariant)} method sets the specified implementation configuration
     * variant.
     * <p>
     * This is for post-build loadable only!
     * </p>
     * <p>
     * Supported values are
     * <ul>
     * <li>{@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_LINK_TIME}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}</li>
     * </ul>
     * </p>
     * <p>
     * <b>Remarks concerning AUTOSAR versions:</b>
     * <ul>
     * <li>If the modules definition has schema version 4.2.1 or higher, the specified value is being written directly to the model</li>
     * <li>If the modules definition has a schema version lower than 4.2.1, the modules implementation configuration variant in the MDF model encodes both, post-build loadable and
     * post-build selectable. The following behavior is being implemented in this case:</li> <!--LaTeX: \begin{scriptsize} -->
     * <table border="1" frame="border">
     * <col align="left"/> <col align="left"/> <col align="left"/> <col align="left"/>
     * <tr>
     * <th>Current model value</th>
     * <th>Parameter</th>
     * <th>Result in the model</th>
     * </tr>
     * <tr>
     * <td>PRE_COMPILE</td>
     * <td>PRE_COMPILE</td>
     * <td>PRE_COMPILE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>LINK_TIME</td>
     * <td>LINK_TIME</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>POST_BUILD_LOADABLE</td>
     * </tr>
     * <tr>
     * <td>LINK_TIME</td>
     * <td>PRE_COMPILE</td>
     * <td>PRE_COMPILE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>LINK_TIME</td>
     * <td>LINK_TIME</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>POST_BUILD_LOADABLE</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>PRE_COMPILE</td>
     * <td>PRE_COMPILE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>LINK_TIME</td>
     * <td>LINK_TIME</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>POST_BUILD_LOADABLE</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD_SELECTABLE</td>
     * <td>PRE_COMPILE</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>LINK_TIME</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>POST_BUILD</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD</td>
     * <td>PRE_COMPILE</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>LINK_TIME</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>POST_BUILD</td>
     * </tr>
     * </table>
     * <!--LaTeX: \end{scriptsize} -->
     * </ul>
     * </p>
     * </div>
     *
     * @param configurationVariant
     * @throws IllegalArgumentException if an unsupported value of {@link EEcucConfigurationVariant} was specified
     */
    @PublishedMethod
    void setConfigurationVariant(EEcucConfigurationVariant configurationVariant);

    /**
     * Returns <code>true</code> if this module configuration contains an explicit specification of post-build variance support.
     * <p>
     * This is for post-build selectable only!
     * </p>
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    boolean hasPostBuildVarianceSupportFlag();

    /**
     * Removes the post-build variance support flag explicitly. Usual client code and generators never need this functionality. Its provided for core intern use cases, e.g. in the
     * update workflow and for tests only.
     */
    @KeepSecretFromPublishedApi
    void removePostBuildVarianceSupportFlag();

    /**
     * <div class="extdoc" id="supportsPostBuildVariance"> The {@link #supportsPostBuildVariance()} method returns <code>true</code> if this module configuration supports
     * post-build selectable.
     * <p>
     * This is for post-build selectable only!
     * </p>
     * <p>
     * What this method actually does:
     * <ul>
     * <li>It checks if the related definition specifies post-build selectable as supported</li>
     * <li>It checks if the module configuration implements post-build variance. That's <code>true</code> in the following cases
     * <ul>
     * <li>If the modules definition has schema version 4.2.1 or higher: Check if the modules ADMIN-DATA flag "postBuildVariantSupport" is <code>true</code> (false is default if
     * this flag is missing)</li>
     * <li>If the modules definition has a schema version lower than 4.2.1: Check if the modules implementation configuration variant contains one of the following values
     * VARIANT_POST_BUILD_SELECTABLE or VARIANT_POST_BUILD</li>
     * </ul>
     * </li>
     * </ul>
     * It returns <code>true</code> if both conditions are <code>true</code>.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsPostBuildVariance();

    /**
     * <div class="extdoc" id="setPostBuildVarianceSupport"> The {@link #setPostBuildVarianceSupport(boolean)} method sets the post-build support flag in the module configuration.
     * <p>
     * This is for post-build selectable only!
     * </p>
     * <p>
     * <b>Remarks concerning AUTOSAR versions:</b>
     * <ul>
     * <li>If the modules definition has schema version 4.2.1 or higher, this method sets the modules ADMIN-DATA flag "postBuildVariantSupport" to the specified value. <br>
     * </li>
     * <li>If the modules definition has a schema version lower than 4.2.1, the modules implementation configuration variant in the MDF model encodes both, post-build loadable and
     * post-build selectable. The following behavior is being implemented in this case: <!--LaTeX: \begin{small} -->
     * <table border="1" frame="border">
     * <col align="left"/> <col align="left"/> <col align="left"/> <col align="left"/>
     * <tr>
     * <th>Current model value</th>
     * <th>Parameter</th>
     * <th>Result in the model</th>
     * </tr>
     * <tr>
     * <td>PRE_COMPILE</td>
     * <td>true</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>false</td>
     * <td>PRE_COMPILE</td>
     * </tr>
     * <tr>
     * <td>LINK_TIME</td>
     * <td>true</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>false</td>
     * <td>LINK_TIME</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD_LOADABLE</td>
     * <td>true</td>
     * <td>POST_BUILD</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>false</td>
     * <td>POST_BUILD_LOADABLE</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD_SELECTABLE</td>
     * <td>true</td>
     * <td>POST_BUILD_SELECTABLE</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>false</td>
     * <td>PRE_COMPILE</td>
     * </tr>
     * <tr>
     * <td>POST_BUILD</td>
     * <td>true</td>
     * <td>POST_BUILD</td>
     * </tr>
     * <tr>
     * <td></td>
     * <td>false</td>
     * <td>POST_BUILD_LOADABLE</td>
     * </tr>
     * </table>
     * <!--LaTeX: \end{small} --></li>
     * </ul>
     * </p>
     * </div>
     *
     * @param supportsPostBuildVariance
     */
    @PublishedMethod
    void setPostBuildVarianceSupport(boolean supportsPostBuildVariance);

    /**
     * Returns the post-build settings of this module configuration.
     * <p>
     * This method doesn't investigate the modules definition. So the behavior is as follows:
     * <ul>
     * <li>The configuration variant contains the value specified in the implementation config variant (the PB-L part of it).
     * <li>If the implementation config variant is <code>null</code>, the returned configuration variant value is also <code>null</code>
     * <li>The PBS Boolean value contains an actually available PBS-support flag in the module configuration without checking the module definition.
     * <li>If this flag is not available, this Boolean value is <code>null</code>
     * </ul>
     * </p>
     * <p>
     * This method is intended to be used core internally for raw access only! E.g. in the update workflow, the consistency and the GUI.
     * </p>
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    ModuleConfigurationPostBuildSettings getPostBuildSettings();

}
