package com.vector.cfg.persistency.project;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.cfg.automation.scripting.base.services.ScriptTaskTypeSignature.signatureOf;

import java.util.EnumSet;

import com.google.common.base.Strings;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IProjectScriptTaskType;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EPersistencyAutomationScriptTaskTypes implements IProjectScriptTaskType {

    DV_AFTER_PROJECT_SAVE("After save project", signatureOf(EnumSet.of(EScriptTaskTypeFeature.AUTOMATIC_EXECUTION), Void.class, String.class));

    private String name;

    private IScriptTaskTypeSignature sig;

    EPersistencyAutomationScriptTaskTypes(String name, IScriptTaskTypeSignature sig) {
        checkArgument(!Strings.isNullOrEmpty(name));
        this.name = name;
        this.sig = checkNotNull(sig);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getUserReadableName() {
        return name;
    }

    @Override
    @PublishedMethod
    public IScriptTaskTypeSignature getSignature() {
        return sig;
    }

    @Override
    @PublishedMethod
    public boolean hasShowableResult() {
        return false;
    }
}
