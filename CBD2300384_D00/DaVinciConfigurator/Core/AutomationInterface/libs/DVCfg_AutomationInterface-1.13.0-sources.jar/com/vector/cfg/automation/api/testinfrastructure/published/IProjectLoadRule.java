package com.vector.cfg.automation.api.testinfrastructure.published;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.rules.TestRule;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.testinfrastructure.published.internal.ProjectLoadRule;
import com.vector.cfg.automation.scripting.api.project.IProject;
import com.vector.cfg.automation.scripting.api.project.IProjectRef;
import com.vector.cfg.util.IProjectContext;

/**
 * <div class="extdoc" id="Common"> The {@link IProjectLoadRule} class provides a <code>JUnit</code> {@link TestRule}, which will load the passed {@link IProjectRef} before test
 * execution and close it afterwards. This can be used as a {@link ClassRule} or {@link Rule} and it could also be used with <code>Spock</code>.
 *
 * <pre>
 * <code class="Java" id="Usage of the IProjectLoadRule in a JUnit test">
 * 	public class ProjectLoadRuleTest {
    &#64;ClassRule
    static IProjectLoadRule rule = IProjectLoadRule.forProject(ScriptApi.scriptCode.projects.parameterizeProjectLoad{
        dpaFile "YourProject.dpa"
    })

    &#64;Test
    public void testcase() {
        //In this test the project was loaded and will be closed after the test
    }
 * </code>
 * </pre>
 *
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IProjectLoadRule extends TestRule {

    /**
     * Creates a new {@link IProjectLoadRule} for the passed projectRef.
     *
     * <p>
     * Note: The project is loaded lazily, when the test case is executed.
     * </p>
     *
     * @param projectRef The project to load.
     * @return the Rule.
     */
    @Nonnull
    @PublishedMethod
    static IProjectLoadRule forProject(@Nonnull IProjectRef projectRef) {
        return new ProjectLoadRule(projectRef);
    }

    /**
     * Returns the loaded Project.
     *
     * @return the project
     * @exception IllegalStateException if the project was not loaded.
     */
    @Nonnull
    @PublishedMethod
    IProject getProject();

    /**
     * Returns the underlying {@link IProjectContext} of the loaded Project.
     *
     * @return the projectContext
     * @exception IllegalStateException if the project was not loaded.
     */
    @Nonnull
    @PublishedMethod
    IProjectContext getProjectContext();
}
