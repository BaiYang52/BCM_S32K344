package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge.result;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="IDifference"><!--IDifference-->{@link IDifference} represents a difference within the {@link IMergeResult} API.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDifference {

    /**
     * <div class="extdoc" id="getIdentifier">The method {@link #getIdentifier()} is used to get the identifier of the CE represented by this {@link IDifference}.
     *
     * </div>
     *
     * @return the identifier of the CE represented by this {@link IDifference}.
     */
    @PublishedMethod
    String getIdentifier();

    /**
     * <div class="extdoc" id="getNotResolvableReason">The method {@link #getNotResolvableReason()} is used to get the reason (if available) why the {@link IDifference} is not
     * resolvable. If none is available {@code null} is returned.
     *
     * </div>
     *
     * @return the reason (if available) why the {@link IDifference} is not resolvable. If none is available {@code null} is returned.
     */
    @PublishedMethod
    String getNotResolvableReason();

}
