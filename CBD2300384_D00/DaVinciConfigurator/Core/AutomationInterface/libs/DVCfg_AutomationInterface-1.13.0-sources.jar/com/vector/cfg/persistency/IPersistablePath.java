package com.vector.cfg.persistency;

import java.nio.file.Path;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;

/**
 * Represents a Path and specifies if the path shall be stored absolute or relative.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ReworkThisAtNextBreakingChange("move this interface to c.v.c.persistency.base")
public interface IPersistablePath {

    /**
     * enables the relative path storage.
     */
    @PublishedMethod
    void storeRelative();

    /**
     * enables the absolute path storage.
     */
    @PublishedMethod
    void storeAbsolute();

    /**
     * @return the absolute path, the persistable path was created with.
     */
    @PublishedMethod
    Path toPath();
}
