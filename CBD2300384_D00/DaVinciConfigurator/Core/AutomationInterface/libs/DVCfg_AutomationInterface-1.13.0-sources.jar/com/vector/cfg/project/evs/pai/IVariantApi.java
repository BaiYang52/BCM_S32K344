package com.vector.cfg.project.evs.pai;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common">{@link IVariantApi} can be used to create and modify variants.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IVariantApi {

    /**
     * <div class="extdoc" id="getName">
     * <h5>Name</h5> {@link IVariantApi#getName()} returns the name of the variant.</div>
     *
     * @return the variant name
     */
    @PublishedMethod
    String getName();
}
