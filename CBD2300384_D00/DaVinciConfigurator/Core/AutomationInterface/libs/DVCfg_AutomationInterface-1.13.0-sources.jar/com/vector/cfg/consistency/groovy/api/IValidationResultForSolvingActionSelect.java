package com.vector.cfg.consistency.groovy.api;

import java.util.Collection;
import java.util.regex.Pattern;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ui.ISolvingActionUI;
import com.vector.cfg.consistency.ui.IValidationResultUI;

/**
 * A specialized interface of a validation-result for selecting one solving-action.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IValidationResultForSolvingActionSelect {

    /**
     * Gets the preferred solving action or null. See also {@link IValidationResultUI#getPreferredSolvingAction()}
     *
     * @return the preferred solving action or null
     */
    @PublishedMethod
    @Nullable
    ISolvingActionUI getPreferred();

    /**
     * Gets the solving action by group id or null. See also {@link IValidationResultUI#getSolvingActionByGroupId(int)}
     *
     * @param id the group id
     * @return the solving action or null
     */
    @PublishedMethod
    @Nullable
    ISolvingActionUI byGroupId(int id);

    /**
     * Gets the solving action that contains the passed string, or null. See also {@link String#contains(CharSequence)}
     *
     * @param s the string that has to be contained
     * @return the solving action or null
     * @throws IllegalStateException if multiple solving actions contain the passed string.
     */
    @PublishedMethod
    @Nullable
    ISolvingActionUI containsString(CharSequence s);

    /**
     * Gets the solving action that matches the passed regex, or null. See also {@link String#matches(String)}
     *
     * @param regex the regex
     * @return the solving action or null
     * @throws IllegalStateException if multiple solving actions match the passed regex.
     */
    @PublishedMethod
    @Nullable
    ISolvingActionUI matchRegex(String regex);

    /**
     * Gets the solving action that matches the passed regex {@link Pattern}, or null. This method is faster than {@link #matchRegex(String)} because the regex is already
     * compiled to a {@link Pattern}.
     *
     * @param regexPattern the pattern
     * @return the solving action or null
     * @throws IllegalStateException if multiple solving actions match the passed regex.
     */
    @PublishedMethod
    @Nullable
    ISolvingActionUI matchRegex(Pattern regexPattern);

    /**
     * This method returns all solving actions in a validator defined order.
     *
     * @return all solving actions
     */
    @PublishedMethod
    Collection<ISolvingActionUI> getSolvingActions();
}
