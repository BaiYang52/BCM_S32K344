package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * Indicates model inconsistencies.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelInconsistencyException extends ModelException {

    private static final long serialVersionUID = -4784335672833409664L;

    @KeepSecretFromPublishedApi
    public static MIObject checkMdfObjNonNull(MIObject mdfObject) {
        if (mdfObject == null) {
            throw new IllegalArgumentException("mdfObject is null");
        }
        return mdfObject;
    }

    @PublishedMethod
    public ModelInconsistencyException(String message) {
        super(message);
    }

    @PublishedMethod
    public ModelInconsistencyException(String message, Throwable ex) {
        super(message, ex);
    }

}
