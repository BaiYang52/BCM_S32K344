package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public class InvisibleVariantObjectFeatureException extends InvisibleVariantObjectException {

    /**
     * <code>serialVersionUID</code> describes.
     */
    private static final long serialVersionUID = -121065767391541667L;

    private String feature;

    /**
     * Constructor.
     */
    public InvisibleVariantObjectFeatureException(String msg, MIObject source, String feature) {
        this(msg, source, feature, null);
        this.feature = feature;
    }

    /**
     * Constructor.
     */
    public InvisibleVariantObjectFeatureException(String msg, MIObject source, String feature, Throwable cause) {
        super(msg, source, cause);
        this.feature = feature;
    }

    @Override
    public String getMessage() {
        String msg = super.getMessage();
        msg += " Feature: " + feature;
        return msg;
    }

}
