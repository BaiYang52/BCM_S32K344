package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.IClientServerDataMapping;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;
import com.vector.cfg.model.sysdesc.api.com.IOperationCommunicationElement;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPostBuildView;

/**
 * <div class="extdoc" id="IUnmappedComElementAndSignalResult"><!--Label:IUnmappedComElementAndSignalResult-->{@link IUnmappedComElementAndSignalResult} represents an
 * {@link ICommunicationElement} and an {@link IAbstractSignalInstance} which were previously mapped to each other by an {@link IDataMapping} and are unmapped now. <br>
 * In case of a SenderReceiverToSignalGroupMapping, it contains also the information about the child mappings. <br>
 * Contains also the variance information of the removed {@link IDataMapping}. </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUnmappedComElementAndSignalResult {

    /**
     * <p>
     * <div class="extdoc" id="getCommunicationElement"><!--Label:IUnmappedComElementAndSignalResult.getCommunicationElement-->{@link #getCommunicationElement()} is a getter for
     * the communication element which was unmapped from an {@link IAbstractSignalInstance} (can be accessed via {@link #getSignalInstance()}). <br>
     * <p>
     * In case of a SenderReceiverToSignalGroupMapping the previously mapped children can be retrieved via {@link #getChildCommunicationElements()}. <br>
     * In case of a ClientServerToSignalMapping this getter returns the previously mapped call communication element. <br>
     * </p>
     * </div>
     * </p>
     *
     * @return The {@link ICommunicationElement} which was previously mapped by an {@link IDataMapping} to the {@link #getSignalInstance()}.
     */
    @PublishedMethod
    ICommunicationElement getCommunicationElement();

    /**
     * <p>
     * <div class="extdoc" id="getSignalInstance"><!--Label:IUnmappedComElementAndSignalResult.getSignalInstance-->{@link #getSignalInstance()} is a getter for the
     * {@link IAbstractSignalInstance} which was unmapped from an {@link ICommunicationElement} (can be accessed via {@link #getCommunicationElement()}). <br>
     * In case of a SenderReceiverToSignalGroupMapping the previously mapped group signals can be retrieved via {@link #getGroupSignalInstances()}.</div>
     * </p>
     *
     * @return The {@link IAbstractSignalInstance} which was previously mapped by an {@link IDataMapping} to the {@link #getCommunicationElement()}.
     */
    @PublishedMethod
    IAbstractSignalInstance getSignalInstance();

    /**
     * <p>
     * <div class="extdoc" id= "getReturnSignalCommunicationElement"><!--Label:IUnmappedComElementAndSignalResult.getReturnSignalCommunicationElement-->
     * {@link #getReturnSignalCommunicationElement()} is the corresponding getter to {@link #getCommunicationElement()} for the previously mapped return signal communication
     * element. <br>
     * </div>
     * </p>
     *
     * @return The {@link ICommunicationElement} which was previously mapped by an {@link IClientServerDataMapping} to the {@link #getReturnSignalInstance()}. Returns null if
     * the removed data mapping was not an {@link IClientServerDataMapping}.
     */
    @PublishedMethod
    @Nullable
    IOperationCommunicationElement getReturnSignalCommunicationElement();

    /**
     * <p>
     * <div class="extdoc" id="getReturnSignalInstance"><!--Label:IUnmappedComElementAndSignalResult.getReturnSignalInstance--> {@link #getReturnSignalInstance()} is the
     * corresponding getter to {@link #getSignalInstance()} for the previously mapped return signal instance. <br>
     * </div>
     * </p>
     *
     * @return The {@link IAbstractSignalInstance} which was previously mapped by an {@link IClientServerDataMapping} to the {@link #getReturnCommunicationElement()} in the role
     * of the mapped return signal. Returns null if the removed data mapping was not an {@link IClientServerDataMapping}.
     */
    @PublishedMethod
    @Nullable
    IAbstractSignalInstance getReturnSignalInstance();

    /**
     * <p>
     * <div class="extdoc" id= "getChildCommunicationElements"><!--Label:IUnmappedComElementAndSignalResult.getChildCommunicationElements-->
     * {@link #getChildCommunicationElements()} is a getter for the child communication elements of {@link #getCommunicationElement()} which were unmapped from group signal
     * instances of {@link #getSignalInstance()}. <br>
     * <p>
     * The order of the communication element is relevant and matches the order of {@link #getGroupSignalInstances()}. So the first child communication element was mapped to the
     * first group signal, the second to the second group signal and so on.<br>
     * </p>
     * </div>
     * </p>
     *
     * @return The child {@link ICommunicationElement}s which were previously mapped by a complex {@link IDataMapping} to the {@link #getGroupSignalInstances()}. In case the
     * data mapping was not a SenderReceiverToSignalGroupMapping an empty list is returned.
     */
    @PublishedMethod
    List<ICommunicationElement> getChildCommunicationElements();

    /**
     * <p>
     * <div class="extdoc" id= "getGroupSignalInstances"><!--Label:IUnmappedComElementAndSignalResult.getGroupSignalInstances--> {@link #getGroupSignalInstances()} is a getter
     * for the group signal instances of {@link #getSignalInstance()} which were unmapped from child communication elements of {@link #getCommunicationElement()}. <br>
     * <p>
     * The order of the group signal instances is relevant and matches the order of {@link #getChildCommunicationElements()}. So the first child communication element was mapped
     * to the first group signal, the second to the second group signal and so on.<br>
     * </p>
     * </div>
     * </p>
     *
     * @return The group signal instances which were previously mapped by a complex {@link IDataMapping} to the {@link #getChildCommunicationElements()}. In case the data
     * mapping was not a SenderReceiverToSignalGroupMapping an empty list is returned.
     */
    @PublishedMethod
    List<IAbstractSignalInstance> getGroupSignalInstances();

    /**
     * <p>
     * <div class="extdoc" id="getPostBuildViewsOfMapping"><!--Label:IUnmappedComElementAndSignalResult.getPostBuildViewsOfMapping-->{@link #getPostBuildViewsOfMapping()} is a
     * getter for the variance information of the removed {@link IDataMapping}. It collects and return all {@link IPostBuildView}s for which the {@link IDataMapping} was
     * visible.<br>
     * </div>
     * <p>
     *
     * @return The {@link IPostBuildView}s for which the removed {@link IDataMapping} was visible. Returns a list containing the {@link IInvariantView} only, if the project
     * contains no variants.
     */
    @PublishedMethod
    List<IPostBuildView> getPostBuildViewsOfMapping();

}
