package com.vector.cfg.model.abstraction.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable;

/**
 * Model abstraction for an Identifiable. In AUTOSAR instances of an Identifiable can be referred to by their shortname and may contain other Identifiables.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IIdentifiable extends IModelAbstraction {

    @PublishedMethod
    @Override
    MIIdentifiable getMdfObject();

    /**
     *
     * @return The shortname of this {@link IIdentifiable}.
     */
    @PublishedMethod
    String getName();

    /**
     * Determines the full AUTOSAR path of the {@link IIdentifiable}.
     *
     * @return The AUTOSAR path (e.g. "/Package1/Package2/Name1/SubName2").
     */
    @PublishedMethod
    String getAutosarPath();

    /**
     * Returns the AUTOSAR path of the specified {@link IIdentifiable}.
     *
     * @return Absolute AUTOSAR path of the object and <b>never</b> <code>null</code>
     */
    @PublishedMethod
    AsrPath getAsrPath();
}
