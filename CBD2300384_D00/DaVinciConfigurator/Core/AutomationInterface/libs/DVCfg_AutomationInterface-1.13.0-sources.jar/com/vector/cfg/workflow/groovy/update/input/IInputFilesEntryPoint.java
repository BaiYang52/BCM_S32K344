package com.vector.cfg.workflow.groovy.update.input;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The Interface IInputFilesEntryPoint.
 *
 * This is the entry point for the modification of the list of input files and the corresponding settings.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IInputFilesEntryPoint {

    /**
     * modifies the list of input files and the corresponding settings.
     *
     * @param code the code {@link Closure} working with {@link IInputApi}.
     * @return the result of the {@link Closure}.
     */
    @PublishedMethod
    <T> T input(@VDelegatesToWithClosureParam(IInputApi.class) Closure<T> code);

    /**
     * modifies the list of input files and the corresponding settings.
     *
     * @return the {@link IInputApi}
     */
    @PublishedMethod
    IInputApi getInput();

    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IInputApi extends IHasInputFileCategories {

        /**
         * <b>Note: this method is not yet implemented.</b>
         *
         * @return
         */
        @PublishedMethod
        List<IVariant> getAvailableVariants();

        /**
         * <b>Note: this method is not yet implemented.</b>
         *
         * @param variant
         * @param code
         * @return
         */
        @PublishedMethod
        <T> T variant(IVariant variant, @VDelegatesToWithClosureParam(IVariantApi.class) Closure<T> code);

        /**
         * <b>Note: this method is not yet implemented.</b>
         *
         * @return
         */
        @PublishedMethod
        IVariant getVariant();
    }

    /**
     * <b>Note: this interface is not yet implemented.</b>
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IVariantApi extends IHasInputFileCategories {

    }

    /**
     * <b>Note: this interface is not yet implemented.</b>
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IVariant {

    }

    /**
     * This interface supplies the input file categories diagnostic, communication and projectStandardConfiguration.
     *
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IHasInputFileCategories {

        /**
         * modifies the list of diagnostic input files.
         *
         * @param code code {@link Closure} working with {@link IDiagnosticApi}
         * @return the result of the {@link Closure}
         */
        @PublishedMethod
        <T> T diagnostic(@VDelegatesToWithClosureParam(IDiagnosticApi.class) Closure<T> code);

        /**
         * modifies the list of diagnostic input files.
         *
         * @return the {@link IDiagnosticApi}
         */
        @PublishedMethod
        IDiagnosticApi getDiagnostic();

        /**
         * modifies the list of communication input files.
         *
         * @param code code {@link Closure} working with {@link ICommunicationApi}
         * @return the result of the {@link Closure}
         */
        @PublishedMethod
        <T> T communication(@VDelegatesToWithClosureParam(ICommunicationApi.class) Closure<T> code);

        /**
         * modifies the list of communication input files.
         *
         * @return the {@link ICommunicationApi}
         */
        @PublishedMethod
        ICommunicationApi getCommunication();

        /**
         * modifies the list of project standard configuration input files.
         *
         * @param code code {@link Closure} working with {@link IProjectStandardConfigurationApi}
         * @return the result of the {@link Closure}
         */
        @PublishedMethod
        <T> T projectStandardConfiguration(@VDelegatesToWithClosureParam(IProjectStandardConfigurationApi.class) Closure<T> code);

        /**
         * modifies the list of project standard configuration input files.
         *
         * @return the {@link IProjectStandardConfigurationApi}
         */
        @PublishedMethod
        IProjectStandardConfigurationApi getProjectStandardConfiguration();
    }
}
