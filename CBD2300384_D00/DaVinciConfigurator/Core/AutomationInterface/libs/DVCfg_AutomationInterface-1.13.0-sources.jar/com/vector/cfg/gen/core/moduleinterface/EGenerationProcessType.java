package com.vector.cfg.gen.core.moduleinterface;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.project.EEnvironmentTargetType;

/**
 * The Enum {@link EGenerationProcessType} identifies, which type the current active generation process is active. (E.g. {@link #Real}, {@link #Vtt})
 * <p>
 * See the service {@link IGenerationProcessStatusService} to retrieve the current state.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IGenerationProcessStatusService
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EGenerationProcessType {

    /**
     * The normal operation type.
     */
    REAL(EEnvironmentTargetType.REAL.getLiteralValue()) {
        @Override
        public boolean isReal() {
            return true;
        }
    },

    /**
     * The Generation will be execution a vVIRTUALtarget.
     */
    VTT(EEnvironmentTargetType.VIRTUAL.getLiteralValue()) {
        @Override
        public boolean isVtt() {
            return true;
        }
    },

    ;

    private final String description;

    EGenerationProcessType(String description) {
        this.description = description;

    }

    /**
     * Returns <code>true</code>, if the enum is {@link #REAL}.
     *
     * @return true, if is real platform
     */
    @PublishedMethod
    public boolean isReal() {
        return false;
    }

    /**
     * Returns <code>true</code>, if the enum is {@link #VTT}.
     *
     * @return true, if is vVIRTUALtarget
     */
    @PublishedMethod
    public boolean isVtt() {
        return false;
    }

    @KeepSecretFromPublishedApi
    public String getDescription() {
        return description;
    }

    @KeepSecretFromPublishedApi
    public static EGenerationProcessType valueOfByDescription(String description) {
        for (final EGenerationProcessType type : values()) {
            if (type.getDescription().equals(description)) {
                return type;
            }
        }
        throw new IllegalArgumentException();

    }

    @KeepSecretFromPublishedApi
    public static String[] valuesAsDescriptions() {
        final int length = values().length;
        final String[] descs = new String[length];
        for (int i = 0; i < length; i++) {
            descs[i] = values()[i].getDescription();
        }
        return descs;
    }

}