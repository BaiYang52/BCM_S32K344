package com.vector.cfg.gen.core.bswmdmigration.groovy;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IModelAccess;

/**
 * The {@link IMigrationRuleVerificationApi}} provide the means for verifying the correct result of a migration rule execution.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IMigrationRuleVerificationApi {

    /**
     * Returns the {@link IModelAccess}.
     *
     * @return the model access
     */
    @PublishedMethod
    IModelAccess getModelAccess();

}
