package com.vector.cfg.model.derived;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;

/**
 * {@link IRemovedDerivedContainerInfo} represents the stored information of the removed {@link MIContainer}, which was derived.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Immutable
public interface IRemovedDerivedContainerInfo {

    /**
     * The containers shortname.
     *
     * @return the shortname of the removed {@link MIContainer}
     * @see MIContainer#getName()
     */
    @PublishedMethod
    String getName();

    /**
     * The containers definition.
     *
     * @return the definition or the removed container
     */
    @PublishedMethod
    String getDefinition();

    /**
     * The containers definition as {@link DefRef}.
     *
     * @return the definition or the removed container
     */
    @PublishedMethod
    DefRef getDefRef();

    /**
     * Recreates the specified container using its derived value. Mandatory child objects will be created too and pre-configuration, recommended config and default values will
     * be applied. If this container is not a removed derived sub-container, this operation silently does nothing.
     * <p>
     * The behavior in variant projects depends on the variant context which is active when this method is being called:
     * <ul>
     * <li>In a single variant view, this method checks the following conditions:
     * <ul>
     * <li>Does the parent already have a child object with the specified shortname in another variant?</li>
     * <li>Does the derived counterpart (the InitialEcuC container) which is visible in the current view have less visibility as the specified parent?</li>
     * </ul>
     * <p>
     * If one of these conditions is <code>true</code>, the restored container must have a variation point to avoid duplicate shortnames (first condition) or more visibility as
     * the original derived container (second condition). The restore is therefore being executed using the variant specific mode. So the resulting container instance is visible
     * in the current view only.
     * </p>
     * <p>
     * If both conditions are <code>false</code>, the container instance is being restored without a variation point resulting in an ActiveEcuC container with the same
     * visibility as the parent. If the caller strictly requires variant specific behavior, it must switch to the variant specific change mode in advance.
     * </p>
     * </li>
     * <li>In the unfiltered view, this method checks the following conditions:
     * <ul>
     * <li>Does the parent already have a child object with the specified shortname?</li>
     * <li>Does one of derived counterparts (there are probably several variant InitialEcuC containers) have less visibility as the specified parent?</li>
     * </ul>
     * <p>
     * If one of these conditions is <code>true</code>, the restore is being executed in all variants, the parent is visible in, using the variant specific mode as described
     * above.
     * </p>
     * <p>
     * If both conditions are <code>false</code>, the container is being restored once for all variants, the parent is visible in. In either case, the result will be that the
     * restored container is available in all variants, the parent is visible in and were a derived container is available in the InitialEcuC.
     * </p>
     * </li>
     * </ul>
     * </p>
     *
     */
    @PublishedMethod
    void restore();
}
