package com.vector.cfg.util.text.mixedtext;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IFormatSpec {

    @PublishedField
    IFormatSpec DEFAULT_SPEC = FormatSpec.getInternedFormatSpec(true, true);

    @PublishedMethod
    boolean useQualifiedNames();

    @PublishedMethod
    boolean leaveCtrlCharacters();
}
