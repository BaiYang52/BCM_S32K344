package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;

/**
 * Represents an Output file. You have also to implement one of the following interfaces {@link IGeneratedOutputFile} or {@link IExternalOutputFile}
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractOutputFile
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IOutputFile extends IGeneratorPackageReferable {

    /**
     * Gets the filename of the OutputFile.
     *
     * @return
     */
    @PublishedMethod
    String getOutputFilename();

    /**
     * Gets file type specific setting and methods.
     *
     * @return The file type corresponding FileType.
     *
     * @see FileTypeSpecification
     * @see CFileTypeSpecification
     */
    @PublishedMethod
    FileTypeSpecification getFileType();

}
