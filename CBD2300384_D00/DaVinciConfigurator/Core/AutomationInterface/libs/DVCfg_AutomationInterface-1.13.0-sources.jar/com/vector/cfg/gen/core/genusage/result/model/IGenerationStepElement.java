package com.vector.cfg.gen.core.genusage.result.model;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.generationsteps.IGenerationStep;

/**
 * This interface represents an external generation step.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationStepElement extends IGenerationItem {

    /**
     * Gets the generation step.
     *
     * @return the generation step
     */
    @PublishedMethod
    IGenerationStep getGenerationStep();
}
