package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IRuntimeSystemApiEntryPoint} is the entry point for accessing the runtime system domain interfaces.
 * <div class="extdoc" id="IRuntimeSystemApiEntryPoint"><!--Label:IRuntimeSystemApiEntryPoint-->The runtime system domain API is specifically designed to support runtime system
 * related use cases. It is available from the {@code IDomainApi} (see <!--Ref:IDomainApi-->) in the form of the {@link IRuntimeSystemApi} interface.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IRuntimeSystemApiEntryPoint {

    /**
     * {@link #getRuntimeSystem()} allows accessing the {@link IRuntimeSystemApi} like a property.
     * <div class="extdoc" id="getRuntimeSystem"><!--Label:IRuntimeSystemApiEntryPoint.getRuntimeSystem-->{@link #getRuntimeSystem()} allows accessing the
     * {@link IRuntimeSystemApi} like a property.</div>
     *
     * @return the {@link IRuntimeSystemApi}
     */
    @PublishedMethod
    IRuntimeSystemApi getRuntimeSystem();

    /**
     * {@link #runtimeSystem(Closure)} allows accessing the {@link IRuntimeSystemApi} in a scope-like way.
     * <div class="extdoc" id="runtimeSystem"><!--Label:IRuntimeSystemApiEntryPoint.runtimeSystem-->{@link #runtimeSystem(Closure)} allows accessing the
     * {@link IRuntimeSystemApi} in a scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link IRuntimeSystemApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T runtimeSystem(@Nonnull @VDelegatesToWithClosureParam(IRuntimeSystemApi.class) Closure<T> code);

}
