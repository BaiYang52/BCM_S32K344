package com.vector.cfg.dom.com.groovy.can;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.com.groovy.api.CanConfigException;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.view.config.variant.IPostBuildPredefinedVariantView;

/**
 * <div class="extdoc" id="ICanPdu" data-target-doc="AutomationInterfaceDocumentation"><!--Label:ICanPdu-->An {@link ICanPdu} represents a Pdu of the CanIf module.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICanPdu extends IHasModelObject {

    /**
     * <div class="extdoc" id="disableFullCan"><!--Label:ICanPdu.disableFullCan-->{@link #disableFullCan()} disables the FullCAN feature for this {@link ICanPdu}. In other words
     * the corresponding FullCAN hardware object will be deleted and the references redirected to a suitable BasicCAN hardware object. <br>
     *
     * <p>
     * To enable the FullCAN feature please use {@link #enableFullCan()}.
     * </p>
     * </div>
     *
     * @exception CanConfigException if no hardware object can be found for this {@link ICanPdu} or relevant references are not changeable.
     * @exception IllegalStateException if the project contains post-build selectable variance and no {@link IPostBuildPredefinedVariantView} is activated.
     */
    @PublishedMethod
    void disableFullCan();

    /**
     * <div class="extdoc" id="enableFullCan"><!--Label:ICanPdu.enableFullCan-->{@link #enableFullCan()} enables the FullCAN feature for this {@link ICanPdu}. In other words a
     * corresponding FullCAN hardware object will be created and the references of the relevant objects redirected to it from the previously referenced BasicCAN hardware object.
     * <br>
     *
     * <p>
     * To disable the FullCAN feature please use {@link #disableFullCan()}. If the FullCAN feature is already enabled can be checked using {@link #isFullCanEnabled()}. This
     * might be useful to avoid multiple hardware objects for the same PDU, when using {@link #enableFullCan()} more than once on the same PDU.
     * </p>
     * </div>
     *
     * @exception CanConfigException if no hardware object can be found for this {@link ICanPdu} or relevant references are not changeable.
     * @exception IllegalStateException if the project contains post-build selectable variance and no {@link IPostBuildPredefinedVariantView} is activated.
     */
    @PublishedMethod
    void enableFullCan();

    /**
     * <div class="extdoc" id="setFullCanLocked"><!--Label:ICanPdu.setFullCanLocked-->{@link #setFullCanLocked(boolean)} switches whether the filter optimization algorithm is
     * allowed to change the configured CAN handle type (BasicCAN/FullCAN) or not.
     *
     * <p>
     * If locked the selected CAN handle type (FullCAN/BasicCAN) of the corresponding Rx-PDU is NOT touched and NOT changed by the filter optimization algorithm.
     * <p/>
     *
     * <p>
     * Tx {@link ICanPdu}s are ignored by this method, since the lock is only available for Rx {@link ICanPdu}s.
     * </p>
     * </div>
     *
     * @param setLocked True if the CAN handle type shall be locked for the filter optimization algorithm. False if the algorithm shall be allowed to change it.
     *
     * @exception IllegalStateException if the project contains post-build selectable variance and no {@link IPostBuildPredefinedVariantView} is activated.
     */
    @PublishedMethod
    void setFullCanLocked(boolean setLocked);

    /**
     * <div class="extdoc" id="isFullCanEnabled"><!--Label:ICanPdu.isFullCanEnabled-->{@link #isFullCanEnabled()} determines whether the configured CAN handle type is FullCAN or
     * BasicCAN .
     *
     * <p>
     * The CAN handle type can be changed between FullCAN and BasicCAN using {@link #enableFullCan()} and {@link #disableFullCan()} methods.
     * <p/>
     * </div>
     *
     * @return True if the CAN handle type for this {@link ICanPdu} is set to FullCAN and false if it is set to BasicCAN.
     *
     * @exception CanConfigException if no hardware object can be found for this {@link ICanPdu}.
     * @exception IllegalStateException if the project contains post-build selectable variance and no {@link IPostBuildPredefinedVariantView} is activated.
     */
    @PublishedMethod
    boolean isFullCanEnabled();

    /**
     * <div class="extdoc" id="isFullCanLocked"><!--Label:ICanPdu.isFullCanLocked-->{@link #isFullCanLocked()} determines whether the CAN handle type is locked for the filter
     * optimization algorithm. <br>
     * Note: Only Rx {@link ICanPdu}s can be locked, so returns always false for Tx {@link ICanPdu}s. </div>
     *
     * @return True if the CAN handle type for this {@link ICanPdu} is locked for the filter optimization algorithm, false otherwise.
     *
     * @exception IllegalStateException if the project contains post-build selectable variance and no {@link IPostBuildPredefinedVariantView} is activated.
     */
    @PublishedMethod
    boolean isFullCanLocked();

    /**
     * <div class="extdoc" id="getMdfObject"><!--Label:ICanPdu.getMdfObject-->
     * <h5>Accessing a CanPdu's MIContainer</h5>{@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link ICanPdu}.</div>
     *
     * @return the {@link MIContainer} represented by this {@link ICanPdu}
     */
    @Override
    @PublishedMethod
    MIContainer getMdfObject();

}
