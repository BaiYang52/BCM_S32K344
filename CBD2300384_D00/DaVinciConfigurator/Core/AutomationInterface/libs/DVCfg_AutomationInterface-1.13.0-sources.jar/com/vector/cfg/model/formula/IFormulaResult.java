package com.vector.cfg.model.formula;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Optional;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.formulalanguage.MIFormulaExpression;

/**
 * <div class="extdoc" id="Common">
 *
 * The {@link IFormulaResult} represents the evaluation result of a {@link MIFormulaExpression}. It contains the numeric value if the formula has been evaluated successfully or
 * the {@link ModelFormulaException} if an error happened while evaluating the expression.
 *
 * This interface has the following convenient methods:
 *
 * <ul>
 * <li>{@link #isEvaluated()}: Returns <code>True</code> if the expression has been evaluated successfully, or <code>False</code> if an error has occurred.</li>
 * <li>{@link #getValue()}: It is worthwhile to mention that formula expression always yields a numeric value. Thus, the numeric result of the evaluation will be mainly given
 * using this method.</li>
 * <li>{@link #getAsBoolean()}: If the provided formula expression is a condition, the result is expected to be boolean. Therefore, this method can be used to convert the
 * numeric result to boolean. Zero is considered <code>False</code>, and any other value is considered <code>True</code>.</li>
 * <li>{@link #getAsFloat()}: Returns the numeric value of the formula as double.</li>
 * <li>{@link #getAsBigDecimal()}: Returns the numeric value of the formula as BigDecimal.</li>
 * <li>{@link #getAsInteger()}: Returns the numeric value of the formula as integer:
 * <ul>
 * <li>First, if the origin value is of an integer type, it is returned as it is.</li>
 * <li>Second, if the origin value can be converted to integer without loss of any information, then it is converted and returned.</li>
 * <li>Otherwise, it throws {@link NumberFormatException} stating that 'The formula value is not an integer'.</li>
 * </ul>
 * </li>
 * <li>{@link #getError()}: Returns an {@link Optional} of {@link ModelFormulaException}. It will be empty if the formula has been evaluated successfully, or contains the error
 * that occurred.</li>
 * </ul>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IFormulaResult {

    /**
     * Returns the numeric result of formula evaluation.
     *
     * <p>
     * <b>Remark:</b> Please note that formula expressions always yield numeric value. You can convert it to other types using the other methods.
     * </p>
     *
     * @return numeric value
     * @throws ModelFormulaException if the formula has not been evaluated successfully.
     */
    @PublishedMethod
    Number getValue();

    /**
     * Gets the numeric result of the formula evaluation as boolean.
     *
     * <ul>
     * <li>Zero represents "False": That includes the integer values ("0", "-0") and the float values ("0.0", "-0.0").</li>
     * <li>Any value other than zero is considered "True".</li>
     * </ul>
     *
     * @return boolean value.
     * @throws ModelFormulaException if the formula has not been evaluated successfully.
     */
    @PublishedMethod
    boolean getAsBoolean();

    /**
     * Gets the numeric result of the formula evaluation as integer.
     *
     * <ul>
     * <li>First, if the origin value is of an integer type, it is returned as it is.</li>
     * <li>Second, if the origin value can be converted to integer without loss of any information, then it is converted and returned.</li>
     * <li>Otherwise, it throws NumberFormatException stating that 'The formula value is not an integer'.</li>
     * </ul>
     *
     * @return integer value.
     * @throws ModelFormulaException if the formula has not been evaluated successfully.
     * @throws NumberFormatException if the formula value is not a mathematical integer.
     */
    @PublishedMethod
    BigInteger getAsInteger();

    /**
     * Gets the numeric result of the formula evaluation as double.
     *
     * @return double value
     * @throws ModelFormulaException if the formula has not been evaluated successfully.
     */
    @PublishedMethod
    double getAsFloat();

    /**
     * Gets the numeric result of the formula evaluation as BigDecimal.
     *
     * @return BigDecimal.
     * @throws ModelFormulaException if the formula has not been evaluated successfully.
     */
    @PublishedMethod
    BigDecimal getAsBigDecimal();

    /**
     * Returns <code>true</code> the formula has been evaluated successfully.
     *
     * @return true if the formula expression has been evaluated successfully.
     */
    @PublishedMethod
    boolean isEvaluated();

    /**
     * Returns the formula evaluation's exception if the formula has not been evaluated successfully.
     *
     * @return exception if {@link #isEvaluated()} returned <code>false</code>.
     */
    @PublishedMethod
    Optional<ModelFormulaException> getError();
}
