package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigDecimal;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IPositionInTaskEntry;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="ITaskMapper"><!--Label:ITaskMapper-->{@link ITaskMapper} provides an Api to control and evaluate the task mapping.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskMapper {

    /**
     * <div class="extdoc" id="selectTask"><!--Label:ITaskMapper.selectTask-->{@link #selectTask(Closure)} allows to define predicates to select a task for the task mapping.</div>
     *
     * @param code The code to select a task.
     * @throws SelectionException if the selection is not narrowed down to exactly one task.
     */
    @PublishedMethod
    void selectTask(@Nonnull @VDelegatesToWithClosureParam(ITaskSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="filterTaskMappings"><!--Label:ITaskMapper.filterTaskMappings-->{@link #filterTaskMappings(Closure)} allows to filter the task mappings that should be
     * created. This might be especially helpful to narrow down the task mappings after selecting events or executable entities when using multi instantiation (e.g. to filter the
     * task mappings for only one instance of a multi instantiated component prototype).</div>
     *
     * @param code The code to filter task mappings.
     */
    @PublishedMethod
    void filterTaskMappings(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="selectExecutionOrderConstraints"><!--Label:ITaskMapper.selectExecutionOrderConstraints-->{@link #selectExecutionOrderConstraints(Closure)} allows to
     * define predicates to select execution order constraints that should be applied.</div>
     *
     * @param code The code to select execution order constraints.
     */
    @PublishedMethod
    void selectExecutionOrderConstraints(@Nonnull @VDelegatesToWithClosureParam(IExecutionOrderConstraintSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="order"><!--Label:ITaskMapper.order-->{@link #order(Closure)} allows to evaluate and change the order of the task mappings. The received
     * {@link IPositionInTaskEntry}s are already sorted respecting the defined successors by {@link #defineSuccessors(Closure)} code. If used, the {@link #queue()} option may
     * override the order defined by this {@link #order(Closure)} call.
     * <p>
     * It provides a possibility to order the already existing task mappings of the selected task and the new task mappings that should be created.
     * </p>
     * </div>
     *
     * @param code The code to define an order of the task mappings.
     */
    @PublishedMethod
    void order(
            @ClosureParams(value = FromString.class, options = "java.util.List<com.vector.cfg.model.sysdesc.api.taskmapping.IPositionInTaskEntry>") @Nonnull Closure<?> code);

    /**
     * <div class="extdoc" id="combineViaSymbol"><!--Label:ITaskMapper.combineViaSymbol-->{@link #combineViaSymbol(boolean)} determines whether the BswModuleEntities and the
     * RunnableEntities should be combined using their symbol. That means they will be mapped to the same position on the same task. It is enough to select only the RunnableEntity
     * or only the BswModuleEntity, when using this option both will be mapped. The default is true.
     * <p>
     * The condition is that the symbol of a RunnableEntity and the BswModuleEntry short name of a BswModuleEntity are equal.
     * </p>
     * </div>
     *
     * @param doCombine True if runnable and bsw module entities should be mapped together.
     */
    @PublishedMethod
    void combineViaSymbol(boolean doCombine);

    /**
     * <div class="extdoc" id="mapAllEventsOfRunnableEntity"><!--Label:ITaskMapper.mapAllEventsOfRunnableEntity-->{@link #mapAllEventsOfRunnableEntity(boolean, boolean)} is a
     * possibility to map all events of a RunnableEntity to the same position on a task. In case of the selection of events, the task mapping will be extended, by all events
     * (triggers) of runnable entities (functions) for which at least one event (trigger) is selected.
     * <p>
     * With help of the two boolean arguments, the behavior of ignoring already mapped events and ignoring events whose mapping is optional can be controlled.
     * </p>
     * </div>
     *
     * @param considerUnmappedOnly      If true, only unmapped events, if false all events will be added to the selection.
     * @param considerMappingIsOptional If true events whose mapping is optional will not be added, if false all events will be added to the selection.
     */
    @PublishedMethod
    void mapAllEventsOfRunnableEntity(boolean considerUnmappedOnly, boolean considerMappingIsOptional);

    /**
     * <div class="extdoc" id="queue"><!--Label:ITaskMapper.queue-->{@link #queue()} is an option that allows to keep the task mappings which are already mapped to the selected
     * task on the current position. The new task mappings will be placed in the defined order into existing gaps. That means they are mapped to the lowest free position. This
     * method may override the order defined in {@link #defineSuccessors(Closure)} and {@link #order(Closure)}.
     *
     * <p>
     * Example: The selected task 'Task1' has already a TaskMappingA at position 1 and a TaskMappingB at position 3. The task mappings TaskMappingC, TaskMappingD and TaskMappingE
     * (in that order) should be mapped to the same task using the {@link #queue()} option. The new task mappings will be assigned in the defined order to the next free position on
     * 'Task1'.<br>
     * So the result will be:<br>
     * 0 -> TaskMappingC (new1)<br>
     * 1 -> TaskMappingA (old)<br>
     * 2 -> TaskMappingD (new2)<br>
     * 3 -> TaskMappingB (old)<br>
     * 4 -> TaskMappingE (new3)<br>
     * <p>
     *
     * <p>
     * If the options {@link #mapAllEventsOfRunnableEntity(boolean, boolean)} or {@link #combineViaSymbol(boolean)} needs to combine an existing mapping with other mappings, the
     * combined task mapping is seen as a new mapping. Its position will be assigned according to the rules of a new mapping explained above. The old mapping which was not combined
     * will be removed. In other words combined task mappings are preferred over single task mappings.
     * </p>
     * </div>
     */
    @PublishedMethod
    void queue();

    /**
     * <div class="extdoc" id="setActivationOffset"><!--Label:ITaskMapper.setActivationOffset-->{@link #setActivationOffset(BigDecimal)} allows to set the activation offset at the
     * created task mappings. The offset will be set for all created task mappings to the given offsetInSeconds value.</div>
     *
     * @param offsetInSeconds An activation offset in seconds.
     */
    @PublishedMethod
    void setActivationOffset(BigDecimal offsetInSeconds);

    /**
     * <div class="extdoc" id="setOsSchedulePoint"><!--Label:ITaskMapper.setOsSchedulePoint-->{@link #setOsSchedulePoint(String)} allows to set the OsSchedulePoint at the created
     * task mappings. The schedule point will be set for all created task mappings to the given osSchedulePoint value.</div>
     *
     * @param osSchedulePoint The schedule point value to be set.
     */
    @PublishedMethod
    void setOsSchedulePoint(String osSchedulePoint);

    /**
     * <div class="extdoc" id="defineSuccessors"><!--Label:ITaskMapper.defineSuccessors-->{@link #defineSuccessors(Closure)} allows to specify the order of the selected task
     * mappings by defining successor relationships between the task mappings. The order defined by this method may still be overridden by {@link #order(Closure)} and
     * {@link #queue()} if used.</div>
     *
     * @param code
     * @throws SelectionException if the defined successors cause a cycle or cannot be sorted according to the defined order.
     */
    @PublishedMethod
    void defineSuccessors(@Nonnull @VDelegatesToWithClosureParam(ITaskMappingSuccessorDefinition.class) Closure<?> code);

    // -------------------------------------------------------------

    @KeepSecretFromPublishedApi
    Closure<?> getSelectTaskCode();

    @KeepSecretFromPublishedApi
    Closure<?> getFilterTaskMappingsCode();

    @KeepSecretFromPublishedApi
    Closure<?> getSelectEOCsCode();

    @KeepSecretFromPublishedApi
    Closure<?> getOrderCode();

    @KeepSecretFromPublishedApi
    boolean isCombineViaSymbol();

    @KeepSecretFromPublishedApi
    boolean isMapAllEventsOfRunnableEntity();

    @KeepSecretFromPublishedApi
    boolean isConsiderUnmappedOnly();

    @KeepSecretFromPublishedApi
    boolean isConsiderMappingIsOptional();

    @KeepSecretFromPublishedApi
    boolean isQueuedOption();

    @KeepSecretFromPublishedApi
    BigDecimal getActivationOffset();

    @KeepSecretFromPublishedApi
    String getOsSchedulePoint();

    @KeepSecretFromPublishedApi
    Closure<?> getDefineSuccessorsCode();
}
