package com.vector.cfg.workflow.diff.groovy.projectcompare.compare.result;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * The values of this enumeration describe the available difference types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EDifferenceType {

    /**
     * <code>ADDED</code> describes a difference whose model element has been added.
     */
    ADDED,

    /**
     * <code>MODIFIED</code> describes a difference whose model element has been modified.
     */
    MODIFIED,

    /**
     * <code>REMOVED</code> describes a difference whose model element has been removed.
     */
    REMOVED

}
