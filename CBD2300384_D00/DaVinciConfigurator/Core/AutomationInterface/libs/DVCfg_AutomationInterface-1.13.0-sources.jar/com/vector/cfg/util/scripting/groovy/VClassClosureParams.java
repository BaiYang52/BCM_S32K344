package com.vector.cfg.util.scripting.groovy;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.SimpleType;

/**
 * {@link VClassClosureParams} defines the parameters of the annotated {@link Closure}. The {@link Class} types specify the parameters of the closure.
 * {@link VClassClosureParams} provides type information for the Groovy type system and IDE support.
 *
 * <p>
 * The usage of {@link VClassClosureParams} is especially good with the {@link DelegatesTo} annotation and the usage of ClosureCalls class.
 * </p>
 *
 * <p>
 * Details: the {@link VClassClosureParams} is converted during PublishedApi compile time to {@link ClosureParams} with {@link SimpleType} values. This shall ease the usage of
 * the {@link ClosureParams} annotation that not string must encode the type information.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see Closure
 * @see ClosureParams
 * @see SimpleType
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.CLASS)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Documented
public @interface VClassClosureParams {

    /**
     * The array of types of the {@link Closure} parameters.
     *
     * @return the class[]
     */
    @PublishedMethod
    Class<?>[] value();

}
