package com.vector.cfg.util.scripting.groovy.extensions;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.codehaus.groovy.runtime.DefaultGroovyMethods;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.collections.CollectionUtil;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FirstParam;

/**
 * {@link VectorCollectionExtensions} defines new groovy methods which appear on normal {@link Iterable}s and {@link Collection}s.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@SuppressWarnings("rawtypes")
public final class VectorCollectionExtensions {

    private VectorCollectionExtensions() {

    }

    /**
     * Returns the single item from the Iterable.
     *
     * @param self a List
     * @return the single element of the iterable.
     * @throws NoSuchElementException if the Iterable is empty or contains more than one element.
     */
    @PublishedMethod
    @Nonnull
    public static <T> T getSingle(@Nonnull Iterable<T> self) {
        return single(self);
    }

    /**
     * Returns the single item from the Iterable.
     *
     * @param self a List
     * @return the single element of the iterable.
     * @throws NoSuchElementException if the Iterable is empty or contains more than one element.
     */
    @PublishedMethod
    @Nonnull
    public static <T> T single(@Nonnull Iterable<T> self) {
        return CollectionUtil.getSingle(self);
    }

    /**
     * Returns the single item from the Iterable.
     *
     * @param self a List
     * @return the single element of the iterable or <code>null</code>, if empty.
     * @throws NoSuchElementException if the Iterable contains more than one element.
     */
    @PublishedMethod
    @Nonnull
    public static <T> T getSingleOrNull(@Nonnull Iterable<T> self) {
        return singleOrNull(self);
    }

    /**
     * Returns the single item from the Iterable.
     *
     * @param self a List
     * @return the single element of the iterable or <code>null</code>, if empty.
     * @throws NoSuchElementException if the Iterable contains more than one element.
     */
    @PublishedMethod
    @Nullable
    public static <T> T singleOrNull(@Nonnull Iterable<T> self) {
        return CollectionUtil.getSingleOrNull(self);
    }

    /**
     * Returns the first item from the Iterable.
     *
     * <p>
     * The first element returned by the Iterable's iterator is returned. If the Iterable doesn't guarantee a defined order it may appear like a random element is returned.
     * </p>
     *
     * @param self a List
     * @return the first element of the iterable
     * @throws NoSuchElementException if the Iterable is empty and you try to access the first() item.
     */
    @PublishedMethod
    @Nullable
    public static <T> T getFirst(@Nonnull Iterable<T> self) {
        return DefaultGroovyMethods.first(self);
    }

    /**
     *
     *
     * @param self a List
     * @return the single element of the iterable
     */
    @PublishedMethod
    @Nullable
    public static <T> T getFirstOrNull(@Nonnull Iterable<T> self) {
        return firstOrNull(self);
    }

    /**
     * Returns the first item from the Iterable.
     *
     * <p>
     * The first element returned by the Iterable's iterator is returned. If the Iterable doesn't guarantee a defined order it may appear like a random element is returned.
     * </p>
     *
     * @param self a List
     * @return the first element of the iterable or <code>null</code>, if empty.
     */
    @PublishedMethod
    @Nullable
    public static <T> T firstOrNull(@Nonnull Iterable<T> self) {
        final Iterator<T> iterator = self.iterator();
        if (!iterator.hasNext()) {
            return null;
        }
        final T elem = iterator.next();
        return elem;
    }

    /**
     * Filters the passed {@link Set} matching the closure condition.
     *
     * @param self a Set
     * @param predicate a closure condition
     * @return a Set of matching values
     */
    @PublishedMethod
    public static <T> Set<T> filter(Set<T> self, @ClosureParams(FirstParam.FirstGenericType.class) Closure predicate) {
        return (Set<T>) filter((Collection<T>) self, predicate);
    }

    /**
     * Filters the passed {@link List} matching the closure condition.
     *
     * @param self a List
     * @param predicate a closure condition
     * @return a List of matching values
     */
    @PublishedMethod
    public static <T> List<T> filter(List<T> self, @ClosureParams(FirstParam.FirstGenericType.class) Closure predicate) {
        return (List<T>) filter((Collection<T>) self, predicate);
    }

    /**
     * Filters the passed {@link Collection} matching the closure condition.
     *
     * @param self a Collection
     * @param predicate a closure condition
     * @return a Collection of matching values
     */
    @PublishedMethod
    public static <T> Collection<T> filter(Collection<T> self, @ClosureParams(FirstParam.FirstGenericType.class) Closure predicate) {
        return DefaultGroovyMethods.findAll(self, predicate);
    }

}
