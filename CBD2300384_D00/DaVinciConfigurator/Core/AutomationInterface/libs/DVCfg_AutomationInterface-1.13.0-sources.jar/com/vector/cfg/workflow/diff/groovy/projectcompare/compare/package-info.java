/**
 * The project comparison provides an API for the comparison of two participating DaVinci projects.
 *
 * <div class="extdoc" id="Compare"><!--Compare-->The project comparison provides an API for the comparison of two DaVinci projects. </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.workflow.diff.groovy.projectcompare.compare;