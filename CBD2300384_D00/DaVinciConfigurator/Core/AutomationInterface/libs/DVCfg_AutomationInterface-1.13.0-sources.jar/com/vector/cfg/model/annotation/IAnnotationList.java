package com.vector.cfg.model.annotation;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * The {@link IAnnotationList} is the {@link IAnnotationAccessor} for {@link IAnnotation}s where multiple {@link IAnnotation}s can exist for one annotated element. So single
 * annotations, see class {@link IAnnotationOptional}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IAnnotationOptional
 * @see IAnnotationType
 * @see IAnnotation
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAnnotationList<T extends IAnnotation> extends IAnnotationAccessor<T>, List<T> {

    /**
     * {@inheritDoc}
     */
    @Override
    @Nonnull
    IAnnotationType<? extends IAnnotationList<T>, T> getType();

    /**
     * Creates a new user annotation and appends it to this {@link IAnnotation}. The new object is finally returned.
     *
     * <p>
     * Note: this method will also modify the underlying MDF model.
     * </p>
     * s
     *
     * @param label the label of the annotation
     * @return the created element
     * @see #addValueTo()
     */
    @Nonnull
    T createAndAdd();

    /*
     * Label API
     */
    /**
     * Creates a new user annotation and appends it to this {@link IAnnotation}. The new object is finally returned.
     *
     * <p>
     * Note: this method will also modify the underlying MDF model.
     * </p>
     * s
     *
     * @param label the label of the annotation
     * @return the created element
     * @see #addValueTo()
     */
    @Nonnull
    T createAndAdd(String label);
}
