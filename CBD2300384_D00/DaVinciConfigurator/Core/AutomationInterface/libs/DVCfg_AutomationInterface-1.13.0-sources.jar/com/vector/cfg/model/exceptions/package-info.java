/**
 * Common model related exception types and base class {@link com.vector.cfg.model.exceptions.ModelException}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.exceptions;