package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;

/**
 * <div class="extdoc" id="ISelectedCommunicationElement"><!--Label:ISelectedCommunicationElement-->{@link ISelectedCommunicationElement} represents a selection of exactly one
 * {@link ICommunicationElement} and provides further actions on it. For complex communication elements, also a subset of the child elements is represented.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISelectedCommunicationElement {

    /**
     * <p>
     * <div class="extdoc" id="mapTo"><!--Label:ISelectedCommunicationElement.mapTo-->{@link #mapTo(String...)} creates an {@link IDataMapping} for the
     * {@link ICommunicationElement} which is represented by this {@link ISelectedCommunicationElement}. The mapped signal is the given abstractSignalInstance.<br>
     * <p>
     * In case of a complex mapping first the system signal group has to be referenced. The child mappings are created considering the given order or in other words, the first
     * communication element is mapped to the first signal, the second element to the second signal and so on.<br>
     * For a client server to signal mapping, select the operation communication element and enter the paths to two serialized signals. Which signal is the call and which one
     * the return signal is determined by the direction of the signals.<br>
     * Hint: Use 'ECU Composition' or 'COMPOSITIONTYPE' as component name to select communication elements of delegation ports.<br>
     * </div>
     * </p>
     *
     * <p>
     * The {@link ISelectedCommunicationElement} will produce trace, info and warning logs. To see them, activate the
     * 'com.vector.cfg.dom.runtimesys.groovy.api.ISelectedCommunicationElement' logger with the appropriate log level.
     * </p>
     *
     * @param abstractSignalInstance The AUTOSAR path to the system signal. In case of a complex mapping the first reference should be the one to the system signal group,
     * followed by the references to the group signals.
     *
     * @exception SelectionException When creating the data mapping is not possible or a similar mapping does already exist. See Automation Interface simple API documentation
     * for more details about the checks.
     *
     * @return The created {@link IDataMapping}.
     */
    @PublishedMethod
    IDataMapping mapTo(@Nonnull String... abstractSignalInstance);

}
