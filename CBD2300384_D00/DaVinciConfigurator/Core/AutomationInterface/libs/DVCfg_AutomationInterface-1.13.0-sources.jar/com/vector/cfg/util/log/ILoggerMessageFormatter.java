package com.vector.cfg.util.log;

import java.text.MessageFormat;

import com.vector.annotations.obfuscation.KeepName;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * {@link ILoggerMessageFormatter} provides an interface for an OSGi service, which provides the implementation of the FormattingService, if available, otherwise
 * {@link MessageFormat} from java is used.
 *
 * <p>
 * {@link ChangePolicy#CLASS_DEPENDENCY}: It is class dependency, because the class com.vector.cfg.util.text.format.FormattingService is PublishedApi and implements the
 * interface, so the compiler needs this class. A user must not USE this interface in ANY kind!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@KeepName
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface ILoggerMessageFormatter {

    /**
     * Formats the passed message with the passed arguments, like an <code>IMixedText</code>.
     *
     * <p>
     * The used context in DEBUG, so the passed arguments are expanded with debug information. You should not display the returned string to an end user. Please use
     * {@link #formatEndUser(String, Object...)} instead.
     * </p>
     *
     * @param message the message
     * @param arguments the arguments
     * @return the formatted string
     */
    String formatDebug(String message, Object... arguments);

    /**
     * Formats the passed message with the passed arguments, like an <code>IMixedText</code>.
     *
     * <p>
     * The used context in USER, so the passed arguments are expanded without any debug information. You should display the returned string to an end user, instead of
     * {@link #formatDebug(String, Object...)}.
     * </p>
     *
     * @param message the message
     * @param arguments the arguments
     * @return the formatted string
     */
    String formatEndUser(String message, Object... arguments);

    /**
     * The Interface ILoggerMessageFormatterOSGiProvider.
     * <p>
     * {@link ChangePolicy#CLASS_DEPENDENCY}: It is class dependency, because the class com.vector.cfg.util.text.format.FormattingService is PublishedApi and implements the
     * interface, so the compiler needs this class. A user must not USE this interface in ANY kind!
     * </p>
     */
    @KeepName
    public interface ILoggerMessageFormatterOSGiProvider {
        ILoggerMessageFormatter get();
    }
}
