package com.vector.cfg.project.evs.pai;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="Common">The {@link IUpdateVariantApiEntryPoint} gives access to variant handling of projects.</div>
 * <p>
 * The table below shows possible configurations of variants. <br>
 * <br>
 * <table style="width: 71.0789%;" border="1">
 * <tbody>
 * <tr>
 * <td style="empty-cells: hide"></td>
 * <td><em>Variants &rarr;</em></td>
 * <td><b>Front</b></td>
 * <td><b>Back</b></td>
 * <td><b>Left</b></td>
 * </tr>
 * <tr>
 * <td><em>Criterions &darr;</em></td>
 * <td><em>Possible Values &darr;</em></td>
 * <td style="empty-cells: hide"></td>
 * <td style="empty-cells: hide"></td>
 * <td style="empty-cells: hide"></td>
 * </tr>
 * <tr>
 * <td>Communication</td>
 * <td>Com1, Com2</td>
 * <td><b>Com1</b></td>
 * <td><b>Com2</b></td>
 * <td><b>Com1</b></td>
 * </tr>
 * <tr>
 * <td>Diagnostic</td>
 * <td>Diag1, Diag2</td>
 * <td><b>Diag1</b></td>
 * <td><b>Diag1</b></td>
 * <td><b>Diag2</b></td>
 * </tr>
 * <tr>
 * <td>Criterion98</td>
 * <td>Crit98A, Crit98B</td>
 * <td><b>Crit98B</b></td>
 * <td><b>Crit98A</b></td>
 * <td><b>Crit98B</b></td>
 * </tr>
 * <tr>
 * <td>Criterion99</td>
 * <td>Crit99A, Crit99B</td>
 * <td><b>Crit99A</b></td>
 * <td><b>Crit99A</b></td>
 * <td><b>Crit99B</b></td>
 * </tr>
 * </tbody>
 * </table>
 * <br>
 * <br>
 * <br>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IUpdateVariantApiEntryPoint {

    /**
     * <div class="extdoc" id="variants"> Use the {@link IUpdateVariantApiEntryPoint#updateVariant(Object, Closure)} closure to define variants for the given project.</div>
     *
     * @param dpaFilePath The project dpa file path
     * @param code        providing the {@link IConfigureVariantsApi}
     */
    @PublishedMethod
    <T> T updateVariant(Object dpaFilePath, @VDelegatesToWithClosureParam(IPostBuildApi.class) Closure<T> code);

}
