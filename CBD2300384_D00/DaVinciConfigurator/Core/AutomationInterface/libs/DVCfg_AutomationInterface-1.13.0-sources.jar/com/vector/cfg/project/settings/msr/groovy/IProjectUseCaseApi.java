package com.vector.cfg.project.settings.msr.groovy;

import java.util.Collection;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.project.settings.msr.groovy.internal.UseCase;

/**
 *
 * <div class="extdoc" id="Common">{@link IProjectUseCaseApi} is the entry point for accessing and modifying the use cases and their values.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IProjectUseCaseApi {

    /**
     * Returns a list of available {@link UseCase}.
     *
     * <div class="extdoc" id="getAvailableUseCases">
     * <h5>Available UseCases</h5> The {@link #getAvailableUseCases()} returns an immutable list of all available {@link IUseCase}.</div>
     *
     * @return Immutable list of available {@link IUseCase}
     */
    @PublishedMethod
    Collection<IUseCase> getAvailableUseCases();

    /**
     * Returns a {@link UseCase}.
     *
     * <div class="extdoc" id="getUseCaseByName">
     * <h5>UseCase</h5> The {@link #getUseCaseByName(String)} returns a {@link IUseCase}. </div>
     *
     * @return {@link UseCase}
     */
    @PublishedMethod
    IUseCase getUseCaseByName(String name);

}