package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.IClientServerDataMapping;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataCommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;
import com.vector.cfg.model.sysdesc.api.com.IOperationCommunicationElement;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="ICommunicationElementSelection"><!--Label:ICommunicationElementSelection-->{@link ICommunicationElementSelection} represents a selection of
 * {@link ICommunicationElement}s and the possible operations on these communication elements.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationElementSelection {

    /**
     * <div class="extdoc" id="autoMapTo"><!--Label:ICommunicationElementSelection.autoMapTo-->{@link #autoMapTo(Closure)} tries to auto-map the selection of communication
     * elements according the data mapping assistant rules but offers more control for the auto-mapping: Inside the closure additional predicates for narrowing down the target
     * signal instances can be defined and code to evaluate and change the auto-mapper results can be provided. You do not have to expand the communication elements in the
     * previous selection step. They will be expanded after the root is mapped automatically as you know from the data mapping assistant.
     * <p>
     * {@link #autoMapTo(Closure)} will produce trace, info and warning logs. To see them, activate the
     * '{@link com.vector.cfg.dom.runtimesys.groovy.api.ICommunicationElementSelection}' logger with the appropriate log level.
     * </p>
     * </div>
     *
     * @param code The code to provide target predicates or evaluate matches.
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMapTo(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementAutoMapper.class) Closure<?> code);

    /**
     * <div class="extdoc" id="autoMap"><!--Label:ICommunicationElementSelection.autoMap-->{@link #autoMap()} tries to auto-map the selection of {@link ICommunicationElement}s
     * ({@link IDataCommunicationElement} or {@link IOperationCommunicationElement}) according the data mapping assistant default rules. Therefore the selection of possible
     * target signal instances is computed and tried to match to the selected communication elements. You do not have to expand the communication elements in the previous
     * selection step. They will be expanded after the root is mapped automatically as you know from the data mapping assistant.</div>
     *
     * @return A list of created data mappings.
     */
    @PublishedMethod
    <T extends IDataMapping> List<T> autoMap();

    /**
     * <div class="extdoc" id="terminateOwnerPorts"> {@link #terminateOwnerPorts()} terminates the {@link IComponentPort}s of all selected {@link ICommunicationElement}s. If one
     * of the selected ports is already terminated or connected to another component port, the port will be ignored.
     * <p>
     * The termination of component ports disables the validation of these ports. In other words, these ports are acknowledged as not connected yet. This should give a better
     * overview of the open ports, which still have to be connected or need a data mapping.
     * </p>
     * </div>
     *
     * @return A collection containing all component ports which were terminated by this call.
     */
    @PublishedMethod
    Collection<IComponentPort> terminateOwnerPorts();

    /**
     * <div class="extdoc" id="removePortTerminatorsForOwnerPorts"> {@link #removePortTerminatorsForOwnerPorts()} removes the port terminators of the {@link IComponentPort}s of
     * all selected {@link ICommunicationElement}s.
     * <p>
     * See {@link #terminateOwnerPorts()} for more information about the purpose of terminating ports.
     * </p>
     * </div>
     *
     * @return A collection containing all component ports whose terminators have been removed by this call.
     */
    @PublishedMethod
    Collection<IComponentPort> removePortTerminatorsForOwnerPorts();

    /**
     * <div class="extdoc" id="getCommunicationElements"> {@link #getCommunicationElements()} allows access to the single communication elements in the
     * {@link ICommunicationElementSelection}. Please make sure you are using the correct expansion mode, see {@link ICommunicationElementSelector#selectFullyExpanded()} and
     * {@link ICommunicationElementSelector#selectFullyExpandedButPrimitiveArraysAsLeafs()}. </div>
     *
     * @return The collection of selected communication elements.
     */
    @PublishedMethod
    <T extends ICommunicationElement> Collection<T> getCommunicationElements();

    /**
     * <div class="extdoc" id="unmap"><!--Label:ICommunicationElementSelection.unmap-->{@link #unmap()} unmaps the selected communication elements from all mapped system
     * signals. In case that not all data mappings of the selected communication elements shall be removed the mapped signal instances can be narrowed down using
     * {@link #unmapFrom(Closure)}. <br>
     *
     * <p>
     * For SenderReceiverToSignalGroupMappings (complex mappings) it is already enough to select one of the communication elements (for example the root element), all mappings
     * belonging to the complex mapping will be removed. In other words removing the root mapping also removes the child mappings, removing a child mapping also removes the root
     * mapping and the other child mappings of the same root.
     * </p>
     *
     * </div>
     *
     * @return A collection of {@link IUnmappedComElementAndSignalResult}s representing the {@link ICommunicationElement} and {@link IAbstractSignalInstance} of each removed
     * {@link IDataMapping}. <br>
     * For {@link IClientServerDataMapping}s the returned {@link IUnmappedComElementAndSignalResult} contains all details about the call signal mapping as well as the return
     * signal mapping. <br>
     * For SenderReceiverToSignalGroupMappings (complex data mappings) the returned {@link IUnmappedComElementAndSignalResult} contains also all details about the removed child
     * data mappings. <br>
     */
    @PublishedMethod
    Collection<IUnmappedComElementAndSignalResult> unmap();

    /**
     * <div class="extdoc" id="unmapFrom"><!--Label:ICommunicationElementSelection.unmapFrom-->{@link #unmapFrom()} unmaps the selected {@link ICommunicationElement}s of this
     * selection from the mapped {@link IAbstractSignalInstance}s. In opposite to {@link #unmap()} this method allows additional evaluation of the
     * {@link IAbstractSignalInstance}s for which the {@link IDataMapping}s to the selected communication elements will be removed. <br>
     *
     * <p>
     * For SenderReceiverToSignalGroupMappings (complex mappings) it is already enough to select one of the communication elements (for example the root element), all mappings
     * belonging to the complex mapping will be removed. In other words removing the root mapping also removes the child mappings, removing a child mapping also removes the root
     * mapping and the other child mappings of the same root.
     * </p>
     * </div>
     *
     * @return A collection of {@link IUnmappedComElementAndSignalResult}s representing the {@link ICommunicationElement} and {@link IAbstractSignalInstance} of each removed
     * {@link IDataMapping}. <br>
     * For {@link IClientServerDataMapping}s the returned {@link IUnmappedComElementAndSignalResult} contains all details about the call signal mapping as well as the return
     * signal mapping. <br>
     * For SenderReceiverToSignalGroupMappings (complex data mappings) the returned {@link IUnmappedComElementAndSignalResult} contains also all details about the removed child
     * data mappings. <br>
     */
    @PublishedMethod
    Collection<IUnmappedComElementAndSignalResult> unmapFrom(@Nonnull @VDelegatesToWithClosureParam(ICommunicationElementUnmapper.class) Closure<?> code);

}
