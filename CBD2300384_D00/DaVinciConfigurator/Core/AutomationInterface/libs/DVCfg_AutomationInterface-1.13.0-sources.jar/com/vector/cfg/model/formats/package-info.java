/**
 * Standard format classes for ModelObject and format helper classes.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.formats;