package com.vector.cfg.gen.core.moduleinterface;

import javax.annotation.concurrent.ThreadSafe;

import org.osgi.framework.Version;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageInitializationException;
import com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects.IDeployablePackageHasPackageAspects;
import com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects.IGeneratorPackageAspect;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.version.IVersion;

/**
 * <div class="extdoc" id="Common">
 *
 * <h5>GeneratorPackage</h5> Every Generator must have a class called <code>GeneratorPackage</code> which has to implement the interface {@link IGeneratorPackage}. The
 * <code>GeneratorPackage</code> is the entry point for the DaVinci Configurator Classic to the generator for all activities associated with the generation process.
 *
 * <p>
 * Normally you will subclass the class <code>AbstractGeneratorPackage</code> and implement the missing methods.
 * </p>
 *
 * </div>
 *
 *
 * <div class="extdoc" id="Validators">
 *
 * <h5>Validators</h5> An {@link IGeneratorPackage} could have 0 to * {@link IValidator}s. The ConsistencyDocumentation provides more details about {@link IValidator}s. You have
 * to register every {@link IValidator} in your {@link IGeneratorPackage}.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractGeneratorPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IGeneratorPackage extends IGeneratorPackageReferable, IDeployablePackage, IHasValidationOrigin, IDeployablePackageHasPackageAspects {

    /**
     * This CFG_CORE_FEATURE_VERSION_STRING is a compile time constant. So it is compiled into the Generators. The CURRENT_CFG_CORE_FEATURE_VERSION is an Object, so it hold the
     * "real" current version, which could be used by the generators.
     */
    @PublishedField(constantValueChangesAllowed = true)
    String CFG_CORE_FEATURE_VERSION_STRING = com.vector.cfg.core.ECoreFeatureVersion.CFG_CORE_FEATURE_VERSION_STRING;

    /** See CFG_CORE_FEATURE_VERSION_STRING above for more information! */
    @PublishedField
    Version CURRENT_CFG_CORE_FEATURE_VERSION = Version.parseVersion(CFG_CORE_FEATURE_VERSION_STRING);

    /**
     * Returns the AUTOSAR schema version the currently referenced module definition of this {@link IGeneratorPackage} DefRef.
     *
     * <p>
     * If no module definition is referenced or if no version is specified there, this method throws a <code>{@link GeneratorPackageInitializationException}</code> exception.
     * </p>
     *
     * @return The AUTOSAR schema version of the module definition xml file
     *
     * @exception GeneratorPackageInitializationException
     *                                                    <ul>
     *                                                    <li>If no module definition is referenced or if no version is specified there.</li>
     *                                                    </ul>
     */
    @PublishedMethod
    IVersion getArDefinitionSchemaVersion();

    /**
     * Gets the generator version of the GeneratorPackage.
     * <p>
     * Example:<br />
     * 1.02.08
     * </p>
     *
     * @return The generator version
     */
    @PublishedMethod
    String getGeneratorVersionString();

    /**
     * Gets the CFG5 core feature version.
     *
     * <p>
     * Example:<br />
     * 1.00.00
     * </p>
     *
     * @return The current CFG core feature version.
     */
    @Override
    @PublishedMethod
    String getCfgCoreFeatureVersionString();

    /**
     * Gets the Module shortname of the component, that is generated.
     *
     * @return ModuleShortName
     */
    @PublishedMethod
    String getMSN();

    /**
     * Gets the Module Definition Ref. E.g. /MICROSAR/Can_CanoeemuCanoe/Can
     *
     * @return Module Definition Ref of the Generator
     */
    @PublishedMethod
    DefRef getModuleDefinitionRef();

    /**
     * Returns the name of the generator displayed in various dialogs e.g. ProjectSetting, GenerateDialog, GenerationResult view, ...
     *
     * <p>
     * This should ba a short description name of the Generator, normally the MSN of the module, when this is unique! Otherwise a really short description.
     * <ul>
     * <li>Com</li>
     * <li>CanS12x</li>
     * <li>Rte ContractPhase</li>
     * <li>Rte</li>
     * <li>TpCdd</li>
     * </ul>
     *
     * <p>
     * See also: {@link IGeneratorPackage#getDescriptiveName()} for a more detailed description of a generator.
     * </p>
     *
     * @return GeneratorName
     */
    @Override
    @PublishedMethod
    String getGeneratorName();

    /**
     * Gets a DescriptiveName of the Generator.
     *
     * @return A Descriptive name of the generator
     */
    @PublishedMethod
    String getDescriptiveName();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    void initializePackage();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IProjectContext getProjectContext();

    /**
     * Sets the project context.
     *
     * <p>
     * This method must be called by the GeneratorCore-Framework before the {@link #initializePackage()} method can be called.
     * </p>
     *
     * @param projectContext the new project context
     */
    @Override
    @PublishedMethod
    void setProjectContext(IProjectContext projectContext);

    /**
     * Gets the registered {@link IGenerationProcessor GenerationProcessor}.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IGeneratorPackage} is already initialized.
     * </p>
     *
     * @return The GenerationProcessor
     */
    @PublishedMethod
    IGenerationProcessor getGenerationProcessor();

    /**
     * Retrieve a registered GenService by its class object.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IGeneratorPackage} is already initialized.
     * </p>
     *
     * @param <T>   the generic type of the service
     * @param clazz the class object of the Service.
     * @return the associated service.
     *
     * @exception IllegalStateException
     *                                  <ul>
     *                                  <li>if no service was registered with the clazz object.</li>
     *                                  </ul>
     */
    @Override
    @PublishedMethod
    <T> T getGenService(Class<T> clazz);

    /**
     * Retrieve a registered {@link IGeneratorPackageAspect} by its class object.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IGeneratorPackage} is already initialized.
     * </p>
     *
     * @param <T>   the generic type of the service
     * @param clazz the class object of the requested aspect.
     * @return the associated aspect or None, if the aspect does not exist.
     */
    @Override
    @PublishedMethod
    <T extends IGeneratorPackageAspect> Optional<T> getPackageAspect(Class<T> clazz);

}
