package com.vector.cfg.workflow.diff.groovy.projectcompare.compare;

import java.nio.file.Path;
import java.util.function.Predicate;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;
import com.vector.cfg.workflow.diff.groovy.projectcompare.compare.result.ICompareResult;

import groovy.lang.Closure;

/**
 * {@link IConfigureApi} is the entry point for auto-merge related settings.
 *
 * <div class="extdoc" id="compareCommon">To configure the comparison related settings the {@link IConfigureApi} is used. It allows to make detailed settings for the comparison.
 *
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IConfigureApi {

    /**
     * <div class="extdoc" id="compareDisableUuidsForObjectIdentification">
     * <h5>UUID object identification</h5> {@link #setDisableUuidsForObjectIdentification(Path)} disables or enables the UUID usage for the object identification during comparison.
     * In case of {@code true} the UUID usage will be disabled (this is the default behavior). If {@code false} the UUID will be used for object identification.
     *
     * </div>
     *
     * @param value when {@code true} the UUID usage will be disabled (default). If {@code false} the UUID usage will be enabled.
     */
    @PublishedMethod
    void setDisableUuidsForObjectIdentification(boolean value);

    /**
     * <div class="extdoc" id="compareProjectOther">
     * <h5>OTHER</h5> {@link #setProjectOther(Path)} is used to set the absolute path to project OTHER which is used for comparison with project MINE.
     *
     * </div>
     *
     * @param projectOther the project OTHER used for comparison.
     */
    @PublishedMethod
    void setProjectOther(Path projectOther);

    /**
     * <div class="extdoc" id="compareFilterPlatformFunction">The method {@link #filterPlatformFunction(String)} is used to extend the platform function filter by the given name of
     * the function.
     *
     * </div>
     *
     * @param functionName the name of the function definition to filter for.
     */
    @PublishedMethod
    void filterPlatformFunction(String functionName);

    /**
     * <div class="extdoc" id="compareSetCompareProjectSettings">
     * <h5>Project Settings</h5> {@link #setCompareProjectSettings(boolean)} activates or disables the comparison of project settings. {@code true} when project settings should be
     * compared. Otherwise {@code false}.
     *
     * </div>
     *
     * @param consider {@code true} to enable comparison of project settings. Otherwise {@code false}.
     */
    @PublishedMethod
    void setCompareProjectSettings(boolean consider);

    /**
     * <div class="extdoc" id="compareSetCompareEcuExtract">
     * <h5>ECU Extract of System Description</h5> {@link #setCompareEcuExtract(boolean)} activates or disables the comparison of the ECU Extract of System Description. {@code true}
     * when extract should be compared. Otherwise {@code false}.
     *
     * </div>
     *
     * @param consider {@code true} to enable comparison of the ECU Extract of System Description. Otherwise {@code false}.
     */
    @PublishedMethod
    void setCompareEcuExtract(boolean consider);

    /**
     * <div class="extdoc" id="compareModuleToDiff">
     * <h5>Module configurations to compare</h5> {@link #moduleToCompare(String)} adds the module configuration identified by the given short name to the collection of the modules to
     * be considered for the comparison. This will restrict the default selection behavior.
     *
     * </div>
     *
     * @param moduleShortName the short name of the module configuration to compare.
     */
    @PublishedMethod
    void moduleToCompare(String moduleShortName);

    /**
     * <div class="extdoc" id="compareEvaluateDiffResultDaVinciConfigurator">
     * <h5>DaVinci Configurator Classic comparison result</h5> {@link #evaluateDifferencesDaVinciConfigurator(Predicate)} specifies a {@link Predicate} to evaluate the comparison
     * result of the DaVinci Configurator Classic.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the comparison result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateDifferencesDaVinciConfigurator(Predicate<ICompareResult> resultPredicate);

    /**
     * <div class="extdoc" id="compareEvaluateDiffResultDaVinciConfigurator">
     * <h5>DaVinci Configurator Classic comparison result</h5> {@link #evaluateDifferencesDaVinciConfigurator(Predicate)} specifies a {@link Predicate} to evaluate the comparison
     * result of the DaVinci Configurator Classic.
     *
     * </div>
     *
     * @param resultPredicate the {@link Predicate} which evaluates the comparison result of the DaVinci Configurator Classic.
     */
    @PublishedMethod
    void evaluateDifferencesDaVinciConfigurator(@VDelegatesToWithClosureParam(ICompareResult.class) Closure<Boolean> resultPredicate);
}
