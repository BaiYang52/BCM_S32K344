package com.vector.cfg.model.formats;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.cfg.model.access.DefRef;

/**
 * {@link DefRef} mixed text formats.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class MixedTextFormatDefRef {

    /**
     * Only prints the last Shortname. Formats the DefRef.
     */
    @PublishedField
    public static final String DEFREF_FORMAT_LAST_SHORTNAME = "lastShortname";

    /**
     * Formats the DefRef without the DefRef text before.
     */
    @PublishedField
    public static final String DEFREF_FORMAT_SHORT = "short";

    /**
     * Formats the DefRef with the text DefinitionRef before.
     */
    @PublishedField
    public static final String DEFREF_FORMAT_NORMAL = "normal";

    private MixedTextFormatDefRef() {

    }
}
