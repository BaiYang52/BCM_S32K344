package com.vector.cfg.util.text.log;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.function.Consumer;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.core.runtime.IStatus;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ELogLevel;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;
import com.vector.davinci.util.io.ISafeAutoCloseable;

/**
 * <p>
 * The {@link IUserInteractionMessageService} provides an API to communicate directly with the user in multiple application scenarios like GUI, command line, AI. The following
 * modes of interaction are supported:
 * </p>
 * <h1>Reporting Messages</h1>
 * <p>
 * Use case: the application wants to inform the user about something but is not interested in getting an answer from the user.
 * </p>
 * <p>
 * See {@link #report(IMessage)} and linked javadoc on messages which do not require the users immediate attention.
 * </p>
 * <p>
 * Most reporting methods accept {@link Object}s as messages. These are translated into human readable texts in the following order:
 * <ul>
 * <li>{@link IMessage} (no support for {@link Array}s, {@link Iterable}s or {@link Iterator}s of {@link IMessage})</li>
 * <li>{@link IQuestion} (no support for {@link Array}s, {@link Iterable}s or {@link Iterator}s of {@link IQuestion})</li>
 * <li>{@link IDialog} (no support for {@link Array}s, {@link Iterable}s or {@link Iterator}s of {@link IDialog})</li>
 * <li>{@link IDetailedUserMessage}</li>
 * <li>{@link IUserMessage}</li>
 * <li>{@link IMixedText}</li>
 * <li>{@link Throwable}</li>
 * <li>{@link IStatus}</li>
 * <li>{@link IFormattable}</li>
 * <li>{@link Iterable}</li>
 * <li>{@link Iterator}</li>
 * <li>{@link Array}</li>
 * <li>Ask the FormattingService, if there is a custom formatter for the type.</li>
 * <li>{@link String}</li>
 * <li>{@link Object}</li>
 * </ul>
 * </p>
 * <h1>Asking Simple Questions</h1>
 * <p>
 * Use case: the application requires the user to make a decision on how to proceed. The application asks the user a question to which there is a fix set of answers. See
 * {@link #ask(IQuestion)} and linked javadoc on asking questions.
 * </p>
 * <p>
 * See {@link #okCancel(Boolean, Consumer)}, {@link #yesNo(Boolean, Consumer)} and {@link #answerFromUser(Consumer, String, String...)} convenience APIs for implementing the
 * most basic questions.
 * </p>
 * <h1>Engaging the User in a Dialog</h1>
 * <p>
 * Use case: the application requires complex feedback from the user. E.g. the user has to provide the parameterization of a complex operation. See {@link #query(IDialog)} and
 * linked javadoc on dialogs.
 * </p>
 *
 * <p>
 * This is an ApplicationService.
 * </p>
 *
 * <p>
 * This ApplicationService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IUserInteractionMessageService {

    /**
     * Reports an error to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void errorToUser(Throwable exception);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void errorToUser(Object message);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message   the message
     * @param exception the exception
     */
    @PublishedMethod
    void errorToUser(Object message, Throwable exception);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message   the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void errorToUser(String message, Object... arguments);

    /**
     * Reports a warning to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void warnToUser(Throwable exception);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void warnToUser(Object message);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message   the message
     * @param exception the exception
     */
    @PublishedMethod
    void warnToUser(Object message, Throwable exception);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message   the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void warnToUser(String message, Object... arguments);

    /**
     * Reports an info message to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void infoToUser(Throwable exception);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void infoToUser(Object message);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message   the message
     * @param exception the exception
     */
    @PublishedMethod
    void infoToUser(Object message, Throwable exception);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message   the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void infoToUser(String message, Object... arguments);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * @param level     the {@link ELogLevel} of the message.
     * @param exception the exception
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, Throwable exception);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param level   the {@link ELogLevel} of the message.
     * @param message the message
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, Object message);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param level     the {@link ELogLevel} of the message.
     * @param message   the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, String message, Object... arguments);

    /**
     * @param status if this is {@code null} or {@link IStatus#isOK()} nothing is reported. Otherwise the {@link IStatus} is reported with the {@link ELogLevel} indicated by its
     *               severity.
     */
    @KeepSecretFromPublishedApi
    void statusToUser(@Nullable IStatus status);

    /**
     * @param description the message to be reported to the user
     * @param status      if this is {@code null} or {@link IStatus#isOK()} nothing is reported. Otherwise the {@link IStatus} is used to provide the details of the reported
     *                    message.
     */
    @KeepSecretFromPublishedApi
    void statusToUser(String description, IStatus status);

    /**
     * This method blocks for an answer ("OK" or "Cancel") from the user.
     *
     * @param defaultAnswer may be {@code null} (no default answer), {@code true} (= "OK") or {@code false} (= "Cancel")
     * @param question      specify your question here. The questions will be augmented with standard "OK" and "Cancel" answers.
     * @return {@code true} if the user answers "OK", {@code false} otherwise
     */
    @KeepSecretFromPublishedApi
    boolean okCancel(@Nullable Boolean defaultAnswer, Consumer<? super IMsg<?>> question);

    /**
     * This method blocks for an answer ("Yes" or "No") from the user.
     *
     * @param defaultAnswer may be {@code null} (no default answer), {@code true} (= "Yes") or {@code false} (= "No")
     * @param question      specify your question here. The questions will be augmented with standard "Yes" and "No" answers.
     * @return {@code true} if the user answers "Yes", {@code false} otherwise
     */
    @KeepSecretFromPublishedApi
    boolean yesNo(@Nullable Boolean defaultAnswer, Consumer<? super IMsg<?>> question);

    /**
     * This method blocks for an answer from the user.
     *
     * @param question      specify your question here
     * @param defaultAnswer if non-{@code null} this is added as default answer (see {@link IQuestionApi#defaultAnswer(String, Runnable)}) to your question
     * @param answers       these answers are added as normal answers (choices for the user) to your question
     * @return the answer selected by the user. When there is a GUI the user may choose to close the dialog without selecting an answer. In this case {@code null} is returned.
     */
    @KeepSecretFromPublishedApi
    @Nullable
    String answerFromUser(Consumer<? super IMsg<?>> question, @Nullable String defaultAnswer, String... answers);

    /**
     * @param message the {@link IMessage} to be reported to the user
     * @return an {@link ISafeAutoCloseable} for revoking the reported message (revoking a message which has already been handled by the user has no effect)
     */
    @KeepSecretFromPublishedApi
    ISafeAutoCloseable report(IMessage message);

    /**
     * @param question the {@link IQuestion} to ask the user
     * @return an {@link ISafeAutoCloseable} for revoking the reported question (revoking a question which has already been handled by the user has no effect)
     */
    @KeepSecretFromPublishedApi
    ISafeAutoCloseable ask(IQuestion question);

    /**
     * @param dialog the {@link IDialog} to engage the user in
     * @return an {@link ISafeAutoCloseable} for revoking the reported dialog (revoking a dialog which has already been handled by the user has no effect)
     */
    @KeepSecretFromPublishedApi
    ISafeAutoCloseable query(IDialog dialog);

    /**
     * Reports a message and/or an exception with {@link ELogLevel} to the user. Messages are evaluated as described in the {@link IUserInteractionMessageService}.
     *
     * @param level     the {@link ELogLevel} of the message.
     * @param message   the message (may be {@code null} if an exception is given)
     * @param exception the exception (may be {@code null} if a message is given)
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, @Nullable Object message, @Nullable Throwable exception);

}
