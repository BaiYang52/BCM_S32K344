package com.vector.cfg.model.access;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * <div class="extdoc" id="Common">
 * <h2>IDeletedObjectsInfo</h2> {@link IDeletedObjectsInfo} objects are provided by the (internal) project service {@link IDeletedObjectsAccessProvider}. This service is
 * required because access to content of deleted objects is not possible after deletion. All get-method calls will throw an exception.
 * <p>
 * The {@link IDeletedObjectsInfo} is an API which provides some basic information about already deleted objects. It is intended to store some characteristics of model objects
 * at least to identify them after deletion.
 * </p>
 *
 * <h3>Provided information</h3>
 * <p>
 * The stored information about the deleted object covers:
 * </p>
 * <ul>
 * <li><code>getShortname()</code> returns the shortname of the object</li>
 * <li><code>getAutosarPath()</code> returns the AUTOSAR path of the object</li> <!--Latex:\ifClassicDoc-->
 * <li><code>getDefinition()</code> returns the definition of a parameter or container</li> <!--Latex:\fi-->
 * <li><code>getParentInfo()</code> returns an info object for the parent of the deleted object</li>
 * </ul>
 *
 * <h3>Clients</h3>
 * <p>
 * The IDeletedObjectsInfo are required for example by validation rules which must be able to validate a model change. These rules must be able to get the context of the object
 * deletion to validate the remaining objects.
 * </p>
 *
 * <p>
 * Validation rules can use the interface IRuleEvent to get the deleted info object:
 * </p>
 *
 * <pre>
 * void onModelEvent(IValidationResultSink results, IValidationEvents validationEvents) {
       final Collection<IRuleEvent> events = validationEvents.getEvents()

 *     ...
 *     for (IRuleEvent event : events) {
 *         IRuleEvent e = (IRuleEvent) event;
 *         IDeletedObjectsInfo sourceInfo = e.getSourceInfo();
 *         ...
 *     }
 *     ...
 * }
 * </pre>
 *
 * <h3>Lifetime of deleted objects info</h3> The related provider (internal) service IDeletedObjectsAccessProvider guarantees that these values are available as follows:
 * <ul>
 * <li>If the specified object exists, it returns the related model info object</li>
 * <li>If the specified object has been deleted within a currently running transaction (UOW) or the last committed transaction, it returns the related model info object</li>
 * <li>As soon as a new UOW has been started, it cannot be guaranteed anymore that the related info object is still available. If not <code>null</code> will be returned</li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IDeletedObjectsInfo {

    /**
     * The related model object.
     *
     * @return
     */
    @PublishedMethod
    MIObject getMDFObject();

    /**
     * Returns <code>true</code> if the related object has been deleted and <code>false</code> else.
     *
     * @return
     */
    @PublishedMethod
    boolean isRemoved();

    /**
     * Returns the model info of the next parent object which is is an instance of {@link MIReferrable} or a {@link MIHasDefinition} and <code>null</code> if no such object is
     * available.
     *
     * @return
     */
    @PublishedMethod
    IDeletedObjectsInfo getParentInfo();

    /**
     * Returns the model info of the next parent object. If the next parent is the AUTOSAR root object this method returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    IDeletedObjectsInfo getImmediateParentInfo();

    /**
     * Returns the shortname of the model object if available and <code>null</code> else.
     *
     * @return
     * @throws IllegalStateException if this object is not valid anymore
     */
    @PublishedMethod
    String getShortname();

    /**
     * Returns the AUTOSAR path of the model object if available and <code>null</code> else.
     *
     * @return
     * @throws IllegalStateException if this object is not valid anymore
     */
    @PublishedMethod
    AsrPath getAutosarPath();

    /**
     * The return value of this method depend on the type of the object returned by {@link #getMDFObject()}.
     * <ul>
     * <li>For instances of {@link MIHasDefinition}, this method never returns <code>null</code> but the returned DefRef object can be {@link DefRef#INVALID_DEFREF} if the
     * object doesn't have a valid definition</li>
     * <li>For all other types this method returns <code>null</code> since these objects can never have a definition</li>
     * </ul>
     *
     * @return
     * @throws IllegalStateException if this object is not valid anymore
     */
    @PublishedMethod
    DefRef getDefinition();

}
