package com.vector.cfg.project.evs.pai;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="Common">{@link IAutoModeApi} is the entry point for accessing the simple mode of creating variants.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IAutoModeApi {

    /**
     * {@link #getOrCreateVariant(String)} returns the existing variant {@link IVariantApi} or creates a new one if it is not already existing.
     *
     * <div class="extdoc" id="getOrCreateVariant">
     * <h5>Get or Create Variant</h5> {@link IAutoModeApi#getOrCreateVariant(String)} returns a new {@link IVariantApi} or an already existing one.
     *
     * </div>
     *
     * @param name the name
     * @return the {@link IVariantApi}
     */
    @PublishedMethod
    IVariantApi getOrCreateVariant(String name);

    /**
     * {@link #getAvailableVariants()} returns all available {@link IVariantApi}.
     *
     * <div class="extdoc" id="getAvailableVariants">
     * <h5>Available variants</h5> {@link IAutoModeApi#getAvailableVariants()} returns the available variants.</div>
     *
     * @return the available variants
     */
    @PublishedMethod
    List<IVariantApi> getAvailableVariants();

    /**
     * {@link #removeVariant(IVariantApi)} removes the variant.
     *
     * <div class="extdoc" id="removeVariant">
     * <h5>Remove variant</h5> {@link IAutoModeApi#removeVariant(IVariantApi)} removes the given variant.</div>
     *
     * @param variant the variant
     */
    @PublishedMethod
    void removeVariant(IVariantApi variant);

    /**
     * {@link #existsVariantByName(String)} checks if variant exists.
     *
     * <div class="extdoc" id="existsVariantByName">
     * <h5>Exist variant</h5> {@link IAutoModeApi#existsVariantByName(String)} checks if given variant exists.</div>
     *
     * @param name the name
     * @return true, if exists
     */
    @PublishedMethod
    boolean existsVariantByName(String name);

}
