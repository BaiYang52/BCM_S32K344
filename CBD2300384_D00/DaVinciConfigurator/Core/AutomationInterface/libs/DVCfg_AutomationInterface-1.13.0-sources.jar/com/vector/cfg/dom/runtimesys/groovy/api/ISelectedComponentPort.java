package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.component.IComponent;
import com.vector.cfg.model.sysdesc.api.connection.IConnector;
import com.vector.cfg.model.sysdesc.api.port.IComponentPort;

/**
 * <div class="extdoc" id="ISelectedComponentPort"><!--Label:ISelectedComponentPort-->{@link ISelectedComponentPort} represents a selection of exactly one {@link IComponentPort}
 * and provides further actions on it.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISelectedComponentPort {

    /**
     * <p>
     * <div class="extdoc" id="connectTo"><!--Label:ISelectedComponentPort.connectTo-->{@link #connectTo(String, String, Optional)} creates an {@link IConnector} between the
     * {@link IComponentPort} which is represented by this {@link ISelectedComponentPort} and the {@link IComponentPort} which is retrieved by the given component and port name.
     * It is possible to connect the component port to a delegation port by using 'COMPOSITIONTYPE' as componentName.</div>
     * </p>
     *
     * <p>
     * The {@link ISelectedComponentPort} will produce trace, info and warning logs. To see them, activate the 'com.vector.cfg.dom.runtimesys.groovy.api.ISelectedComponentPort'
     * logger with the appropriate log level.
     * </p>
     *
     * @param componentName Name of the {@link IComponent} to connect. For delegation ports use 'COMPOSITIONTYPE' or 'ECU Composition'.
     * @param portName Name of the port to connect.
     * @param portInterfaceMapping An {@link Optional} containing the AUTOSAR path to the port interface mapping or {@link Optional#empty()} if no port interface mapping is used
     * for the new connector.
     *
     * @exception SelectionException When the component ports cannot be connected. See Automation Interface Documentation for more details about the checks.
     *
     * @return The created {@link IConnector}.
     */
    @PublishedMethod
    IConnector connectTo(@Nonnull String componentName, @Nonnull String portName, @Nonnull Optional<String> portInterfaceMapping);

    /**
     * <div class="extdoc" id="terminate"> {@link #terminate()} simple API to terminate the selected {@link IComponentPort} if it is not already terminated or connected to
     * another component port. You can use {@link IComponentPort#isTerminated()} to check if a port is terminated and {@link IComponentPort#isConnected()} if a port is connected
     * to other ports.
     * <p>
     * The termination of component ports disables the validation of these ports. In other words, these ports are acknowledged as not connected yet. This should give a better
     * overview of the open ports, which still have to be connected or need a data mapping.
     * </p>
     * </div>
     *
     * @exception SelectionException When the component port cannot be terminated, because it is for example already connected, terminated or removed.
     *
     * @return Returns the selected component port.
     */
    @PublishedMethod
    IComponentPort terminate();

    /**
     * <div class="extdoc" id="removePortTerminator"> {@link #removePortTerminator()} simple API to remove the port terminator of the selected component port.
     * <p>
     * See {@link #terminate()} for more information about the purpose of terminating ports.
     * </p>
     * </div>
     *
     * @exception SelectionException When no port terminator for this port can be removed, because it is for example removed or just has no port terminator.
     *
     * @return Returns the selected component port.
     */
    @PublishedMethod
    IComponentPort removePortTerminator();

    @KeepSecretFromPublishedApi
    IComponentPort getComponentPort();
}
