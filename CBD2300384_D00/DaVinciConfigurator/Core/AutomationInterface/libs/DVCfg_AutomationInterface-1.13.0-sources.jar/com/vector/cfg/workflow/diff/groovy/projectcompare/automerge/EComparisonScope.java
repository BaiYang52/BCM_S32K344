package com.vector.cfg.workflow.diff.groovy.projectcompare.automerge;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * The values of this enumeration describe the available comparison scopes.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EComparisonScope {

    /**
     * <code>ECUC_ECUEX_ONLY</code> describes the scope in which only ECUC and Extract of System Description relevant data is compared.
     */
    ECUC_ECUEX_ONLY,

    /**
     * <code>ECUC_ECUEX_DEV_WS</code> describes the scope in which ECUC, Extract of System Description and DaVinci Developer Workspace relevant data is compared.
     */
    ECUC_ECUEX_DEV_WS

}
