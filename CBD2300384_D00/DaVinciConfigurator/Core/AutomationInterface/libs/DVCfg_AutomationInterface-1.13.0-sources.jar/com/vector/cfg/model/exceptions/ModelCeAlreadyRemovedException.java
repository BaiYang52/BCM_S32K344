package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * Thrown to indicate that a {@link MIObject} object like Container was already removed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelCeAlreadyRemovedException extends ModelInconsistencyException {

    private static final long serialVersionUID = -6250273989567268892L;

    private final MIObject mdfObject;

    /**
     * Constructor.
     *
     * @param mdfObject the MIObject which has no Definition
     * @param ex
     */
    @PublishedMethod
    public ModelCeAlreadyRemovedException(MIObject mdfObject, Throwable ex) {
        super("The element was already removed. ElementInfo: " + checkMdfObjNonNull(mdfObject).toString() + ".", ex);

        this.mdfObject = mdfObject;
    }

    @PublishedMethod
    public MIObject getCe() {
        return mdfObject;
    }
}
