package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.model.sysdesc.api.com.ICommunicationElement;
import com.vector.cfg.model.sysdesc.api.com.IDataMapping;

/**
 * <div class="extdoc" id="ISelectedCommunicationElements"><!--Label:ISelectedCommunicationElements-->{@link ISelectedCommunicationElements} represents a selection of
 * {@link ICommunicationElement}s and provides further actions on it. The selection can contain both complex (e.g. a record) as well as also simple communication elements.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISelectedCommunicationElements {

    /**
     * <p>
     * <div class="extdoc" id="mapTo"><!--Label:ISelectedCommunicationElements.mapTo-->{@link #mapTo(List)} maps the {@link ICommunicationElement}s which are represented by this
     * {@link ISelectedCommunicationElements} to the given {@link IAbstractSignalInstance}s via index matching. So the first communication element will be mapped to the first
     * abstract signal instance, the second to the second abstract signal instance and so on. <br>
     *
     * In case you want to ignore communication element and system signal pairs for which a mapping does already exist please use {@link #assureMappedTo(List)}. <br>
     *
     * If you want to map your communication elements to system signals using name matching please use
     * {@link IRuntimeSystemApi#selectCommunicationElements(groovy.lang.Closure)}.<br>
     * <p>
     *
     * If you want to create complex mappings (currently only SenderReceiverToSignalGroupMappings) the given abstractSignalInstances should contain the group signals right after
     * the parent signal group instances.<br>
     *
     * For a client server to signal mapping, select call and return signal instance directly after each other.<br>
     * </div>
     * </p>
     *
     * @param abstractSignalInstance The {@link IAbstractSignalInstance}s to be mapped to the communication elements. The order is relevant, the communication elements will be
     * matched to the abstract signal instances via index.
     *
     * @exception SelectionException When creating one of the data mappings is not possible, a similar mapping does already exist or there is something wrong with the order. See
     * Automation Interface simple API documentation for more details about the checks.
     *
     * @return The created {@link IDataMapping}s expanded. That means also the leaf data mappings.
     */
    @PublishedMethod
    List<IDataMapping> mapTo(@Nonnull List<IAbstractSignalInstance> abstractSignalInstances);

    /**
     * <p>
     * <div class="extdoc" id="assureMappedTo"><!--Label:ISelectedCommunicationElements.assureMappedTo-->{@link #assureMappedTo(List)} does the same as {@link #mapTo(List)} but
     * ignores communication element and abstract signal instance pairs for which a data mapping does already exist.
     * <p>
     *
     * If you want to create complex mappings (currently only SenderReceiverToSignalGroupMappings) the given abstractSignalInstances should contain the group signals right after
     * the parent signal group instances.<br>
     *
     * For a client server to signal mapping, select call and return signal instance directly after each other.<br>
     * </div>
     * </p>
     *
     * @param abstractSignalInstances The {@link IAbstractSignalInstance}s to be mapped to the communication elements. The order is relevant, the communication elements will be
     * matched to the abstract signal instances via index.
     *
     * @exception SelectionException When creating one of the data mappings is not possible, a similar mapping does already exist or there is something wrong with the order. See
     * Automation Interface simple API documentation for more details about the checks.
     *
     * @return The newly created {@link IDataMapping}s mapping communication element and abstract signal instance pairs which were not mapped to each other. Mappings are
     * returned expanded, so the returned list contains also leaf data mappings.
     */
    @PublishedMethod
    List<IDataMapping> assureMappedTo(@Nonnull List<IAbstractSignalInstance> abstractSignalInstances);
}
